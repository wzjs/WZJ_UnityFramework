---@field _Title string
---@field _Content string
---@field _CloseFunc table
---@field _CancleFunc table
---@field _SureFunc table
---@field _CancleName string
---@field _SureBtnName string
---@field _Tag string
---@field _pResItemId number
---@field _NeedAddBtn boolean

---@class DMDialogView
DMDialogView = class("DMDialogView")

---@return DMDialogView
function DMDialogView.Create(pLanguageKey,pConfirmFunc,pCancelFunc,pTitle)
    return DMDialogView.New(pLanguageKey,pConfirmFunc,pCancelFunc,pTitle)
end

function DMDialogView:ctor(pLanguageKey,pConfirmFunc,pCancelFunc,pTitle)
    self._Title = self:SetTitleByLanauageKey("DefaultDialogTitle")
    self._Content = ""
    local defalutCloseFunc = function()
        UICtrlManager.UIDialog:RevokeTop(nil,UICtrlManager.RevokeActionDefault)
    end
    local defaultCancleFunc = function()
        UICtrlManager.UIDialog:RevokeTop(nil,UICtrlManager.RevokeActionDefault)
    end
    local defaultSureFunc = function()
        UICtrlManager.UIDialog:RevokeTop(nil,UICtrlManager.RevokeActionDefault)
    end

    self._CloseFunc = defalutCloseFunc
    self._CancleFunc = defaultCancleFunc
    self._SureFunc = defaultSureFunc
    self._CancleName = Language.GetValue("DefaultDialogCancleBtnName")
    self._SureBtnName = Language.GetValue("DefaultDialogSureBtnName")
    self._Tag = ""
    self._pResItemId = 0
    self._pResItemId1 = 0
    self._NeedAddBtn = false
    self._NeedAddBtn1 = false
    self._SureBtnEnable = true
    self._CancleBtnEnable = true
    self._CloseBtnEnable = false
    self._SureBtnSpriteName = nil
    self._CancleBtnSpriteName = nil
    self._SureBtnAudioName = nil
    self._CancleBtnAudioName = nil
    self._needMaskClose = true
    self:SetContentByLanguageKey(pLanguageKey)
    self:SetSureFunc(pConfirmFunc)
    self:SetCancleFunc(pCancelFunc)
    self:SetTitle(pTitle)
end

function DMDialogView:SetSureBtnSpriteName(pSpriteName)
    self._SureBtnSpriteName = pSpriteName
end

---@param pSpriteName string
function DMDialogView:SetCancleBtnSpriteName(pSpriteName)
    self._CancleBtnSpriteName = pSpriteName
end

function DMDialogView:SetSureBtnAudioName(pAudioName)
    self._SureBtnAudioName = pAudioName
end

function DMDialogView:SetCancleBtnAudioName(pAudioName)
    self._CancleBtnAudioName = pAudioName
end

function DMDialogView:SetBtnsEnable(pSureEnable,pCancleEnable,pCloseEnable)
    self._SureBtnEnable = pSureEnable
    self._CancleBtnEnable = pCancleEnable
    self._CloseBtnEnable = pCloseEnable
end
function DMDialogView:SetMaskCloseEnable(pNeed)
    self._needMaskClose = pNeed
end
function DMDialogView:SetTag(pTag)
    if pTag ~= nil then
        self._Tag = pTag
    end
end
---@param pTitle string
function DMDialogView:SetTitle(pTitle)
    if pTitle ~= nil then
        self._Title = pTitle
    end
end
---@param pLanguageKey string
function DMDialogView:SetTitleByLanauageKey(pLanguageKey)
    self._Title = Language.GetValue(pLanguageKey)
end
---@param pLanguageKey string
function DMDialogView:SetContentByLanguageKey(pLanguageKey)
    self._Content = Language.GetValue(pLanguageKey)
end
---@param pContent string
function DMDialogView:SetContent(pContent)
    if pContent ~= nil then
        self._Content = pContent
    end
end

function DMDialogView:SetContentByCostItem(pCostItemId,pCostItemCount,pPreText,pSuffixText)
    local language = Language.GetValue("DefaultDialogCostContent")
    local itemIcon = VMThing.ItemIconName[pCostItemId]
    self._Content = StringExtension.StringFormat (language,{pPreText,"UI_Common_Item_Atlas",itemIcon,pCostItemCount,pSuffixText})
end

function DMDialogView:SetContentByCostItemEx(pCostItemId,pCostItemCount,pCostItemId1,pCostItemCount1,pPreText,pSuffixText)
    local language = Language.GetValue("WorkDialogCostContent")
    local itemIcon = VMThing.ItemIconName[pCostItemId]
    local itemIcon1 = VMThing.ItemIconName[pCostItemId1]
    self._Content = StringExtension.StringFormat (language,{pPreText,"UI_Common_Item_Atlas",itemIcon,pCostItemCount,"UI_Common_Item_Atlas",itemIcon1,pCostItemCount1,pSuffixText})
end

---@param pFunc fun()
---@param pBtnName string
function DMDialogView:SetCancleFunc(pFunc,pBtnName)
    if pFunc ~= nil then
        self._CancleFunc = pFunc
    end
    if pBtnName ~= nil then
        self._CancleName = pBtnName
    end
end
---@param pFunc fun()
---@param pBtnName string
function DMDialogView:SetSureFunc(pFunc,pBtnName)
    if pFunc ~= nil then
        self._SureFunc = pFunc
    end
    if pBtnName ~= nil then
        self._SureBtnName = pBtnName
    end
end
---@param pEnable boolean
---@param pFunc fun()
function DMDialogView:SetCloseFunc(pEnable,pFunc)
    if pFunc ~= nil then
        self._CloseFunc = pFunc
    end
    self._CloseBtnEnable = pEnable
end
---@param pItemId number
---@param pNeedAddBtn boolean
function DMDialogView:SetResBar(pItemId,pNeedAddBtn)
    self._pResItemId = pItemId
    if pNeedAddBtn == true then
        self._NeedAddBtn = pNeedAddBtn
    end
end

---@param pItemId number
---@param pNeedAddBtn boolean
function DMDialogView:SetResBar1(pItemId,pNeedAddBtn)
    self._pResItemId1 = pItemId
    if pNeedAddBtn == true then
        self._NeedAddBtn1 = pNeedAddBtn
    end
end

