---@class RMEventTriggerManager
RMEventTriggerManager = class("RMEventTriggerManager")
---@field _allEventTrigger RMEventTrigger[]
function RMEventTriggerManager:ctor()
    self._allEventTrigger = {}
    self._curTriggerId = 1
    self._allListenerTrigger = {}
    self._isTriggeringIds = {}
end
---@param pRMEventTrigger RMEventTrigger
function RMEventTriggerManager:AddEventListener(pRMEventTrigger)
    local eventTypes = pRMEventTrigger:GetNeedListenerEvnetTypes()
    if eventTypes ~= nil then
        for k,v in pairs(eventTypes) do
            if self._allListenerTrigger[v] == nil then
                self._allListenerTrigger[v] = {}
            end
            --Logger.LogError(" RMEventTriggerManager AddEventListener Type is : "..v)
            table.insert(self._allListenerTrigger[v],pRMEventTrigger:GetTriggerId())
        end
    end
end
---@param pRMEventTrigger RMEventTrigger
function RMEventTriggerManager:RemoveEventListener(pRMEventTrigger)
    local eventTypes = pRMEventTrigger:GetNeedListenerEvnetTypes()
    if eventTypes ~= nil then
        local triggerId = pRMEventTrigger:GetTriggerId()
        for k,v in pairs(eventTypes) do
            if self._allListenerTrigger[v] ~= nil then
                for m,n in pairs(self._allListenerTrigger[v]) do
                    if n == triggerId then
                        table.remove(self._allListenerTrigger[v],m)
                        break
                    end
                end
            end
        end
    end
end

---@return RMEventTrigger[]
function RMEventTriggerManager:GetAllTriggeringRMTris()
    --Logger.LogError("GetAllTriggeringRMTris")
    if self._isTriggeringIds ~= nil then
        local triggers = {}
        for k,v in pairs(self._isTriggeringIds) do
            --Logger.LogError("v"..v)
            if v ~= nil and v > 0 then
                local rmEventTrigger = self:GetEventTriggerById(v)
                if rmEventTrigger ~= nil then
                    table.insert(triggers,rmEventTrigger)
                end
            end
        end
        ---@param left RMEventTrigger
        ---@param right RMEventTrigger
        table.sort(triggers,function (left,right)
            if left:GetPriority() ~= right:GetPriority() then
                return left:GetPriority() > right:GetPriority()
            end
        end)
        return triggers
    end
    return nil
end
---@return RMEventTrigger
function RMEventTriggerManager:GetFirstTrigger()
    local triggers = self:GetAllTriggeringRMTris()
    if triggers ~= nil and #triggers > 0 then
        local triggerId = triggers[1]:GetTriggerId()
        --Logger.LogError("GetFirstTrigger triggerId is : "..triggerId)
        return triggers[1]
    end
    return nil
end

function RMEventTriggerManager:OnTriggerFinish(pTriggerId)
    --Logger.LogError("OnTriggerFinish TriggerId is : "..pTriggerId)
    self._isTriggeringIds[pTriggerId] = 0
    local rmEventTrigger = self:GetEventTriggerById(pTriggerId)
    if rmEventTrigger ~= nil then
        rmEventTrigger:OnFinish()
        local isCanTrigger = rmEventTrigger:IsCanTrigger()
        if not isCanTrigger then
            self:RemoveEventListener(rmEventTrigger)
        end
    end
end
function RMEventTriggerManager:BroadEvent(pEventType,pParam1,pParam2,pParam3)
    --Logger.LogError("RMEventTriggerManager BroadEvent pEventType is:"..pEventType.."pParam1 is"..pParam1.."pParam2 is:"..pParam2.."pParam3 is:"..pParam3)
    if self._allListenerTrigger[pEventType] ~= nil then
        --Logger.LogError("#self._allListenerTrigger[pEventType]"..#self._allListenerTrigger[pEventType])
        for i = 1,#self._allListenerTrigger[pEventType] do
            local triggerId = self._allListenerTrigger[pEventType][i]
           -- Logger.LogError("triggerId"..triggerId)
            local rmEventTrigger = self:GetEventTriggerById(triggerId)
            if rmEventTrigger ~= nil then
                local isTrigger = rmEventTrigger:OnGetEventListener(pEventType,pParam1,pParam2,pParam3)
                --Logger.LogError("isTrigger",isTrigger)
                --Logger.LogError(isTrigger)
                if isTrigger then
                    Logger.Log("triggerId id is :"..triggerId)
                    self._isTriggeringIds[triggerId] = triggerId
                else
                    self._isTriggeringIds[triggerId] = 0
                end
            end
        end
    end
end


---@return number
function RMEventTriggerManager:GetNewTriggerId()
    self._curTriggerId = self._curTriggerId + 1
    return self._curTriggerId - 1
end
---@return RMEventTrigger
function RMEventTriggerManager:GetEventTriggerById(pTriggerId)
    return self._allEventTrigger[pTriggerId]
end
---@param pRMEventTrigger RMEventTrigger
function RMEventTriggerManager:AddEventTrigger(pRMEventTrigger)
    if pRMEventTrigger == nil then return end
    local triggerId = self:GetNewTriggerId()
    --Logger.LogError("AddEventTrigger triggerId"..triggerId)
    pRMEventTrigger:SetTriggerId(triggerId)
    --Logger.LogError("AddEventTrigger _BindParam1"..pRMEventTrigger._BindParam1)
    --Logger.LogError("AddEventTrigger _BindParam2"..pRMEventTrigger._BindParam2)
    self._allEventTrigger[triggerId] = pRMEventTrigger
    self:AddEventListener(pRMEventTrigger)
    return triggerId
end
