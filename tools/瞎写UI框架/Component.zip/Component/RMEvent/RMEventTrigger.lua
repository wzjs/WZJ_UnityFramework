---@class RMEventTrigger
RMEventTrigger = class("RMEventTrigger")
---@field _EventConditions RMEventConditioner[]

RMEventTrigger.TriggerState_None = "None"
RMEventTrigger.TriggerState_UnTrigger = "UnTrigger"
RMEventTrigger.TriggerState_Triggering = "Triggering"

function RMEventTrigger:ctor()
    self._TriggerId = 0
    self._EventId = 0
    self._MaxTriggerCount = 1
    self._HaveTriggerCount = 0
    ---@type RMEventConditioner[]
    self._EventConditions = {}
    self._IsTrigger = false
    self._Priority = 1 --优先级

    self._BindParam1 = 0
    self._BindParam2 = 0
end
---@param pBindParam1 number
---@param pBindParam2 number
function RMEventTrigger:SetBindParams(pBindParam1,pBindParam2)
    --Logger.LogInfo("Set Bind Param  Trigger is :"..self._TriggerId.."pBindParam1 is :"..pBindParam1.."pBindParam2 is :"..pBindParam2)
    self._BindParam1 = pBindParam1
    self._BindParam2 = pBindParam2
end
function RMEventTrigger:GetBindParams()
    return self._BindParam1,self._BindParam2
end
---@return boolean
function RMEventTrigger:IsBattleTrigger()
    if self._EventConditions ~= nil and #self._EventConditions > 0 then
        for  i = 1,#self._EventConditions do
            if self._EventConditions[i]:IsBattleCondition() then
                return true
            end
        end
    end
    return false
end
---@return number
function RMEventTrigger:GetEventId()
    return self._EventId
end
---@return number
function RMEventTrigger:GetTriggerId()
    return self._TriggerId
end
---@return string[]
function RMEventTrigger:GetNeedListenerEvnetTypes()
    if self._EventConditions ~= nil then
        local eventTypes = {}
        for i = 1 ,#self._EventConditions do
            if self._EventConditions[i]:IsNeedListener() then
                local conditionType = self._EventConditions[i]:ConditionType()
                if conditionType ~= nil then
                    eventTypes[conditionType] = conditionType
                end
            end
        end
        return eventTypes
    end
    return nil
end
---@param pEventId number
function RMEventTrigger:SetEventId(pEventId)
    self._EventId = pEventId
end
function RMEventTrigger:SynchConf(pEventId,pEventData)
    --Logger.LogError("RMEventTrigger SynchConf pEventId "..pEventId)
    if pEventData == nil then return end
    self._EventId = pEventId
    self._Priority = pEventData.Priority
    self._MaxTriggerCount = pEventData.TriggerTimes
    self._HaveTriggerCount = 0
    self:SetTriggerConditions(pEventData.Conditions)
end
function RMEventTrigger:SetTriggerConditions(pConditions)
    if pConditions ~= nil then
        for i = 1 ,#pConditions do
            local conditionData = pConditions[i]
            local Trigger = conditionData.Trigger
            local type = conditionData.Type
            local Param1 = conditionData.Param1
            local Param2 = conditionData.Param2
            local Param3 = conditionData.Param3
            local rmEventConditioner = RMEventConditioner.Created(type,Param1,Param2,Param3,Trigger == 1)
            table.insert(self._EventConditions,rmEventConditioner)
        end
    end
end
---@return number
function RMEventTrigger:GetPriority()
    return self._Priority
end

---@param pTriggerId number
function RMEventTrigger:SetTriggerId(pTriggerId)
    self._TriggerId = pTriggerId
end
function RMEventTrigger:IsCanTrigger()
    if self._MaxTriggerCount == 0 then return true end
    return self._HaveTriggerCount <  self._MaxTriggerCount
end
---@param pEventType RMEventConditioner
function RMEventTrigger:GetConditionByEventType(pEventType)
    if self._EventConditions ~= nil and  #self._EventConditions > 0 then
        for i = 1 ,#self._EventConditions do
            if self._EventConditions[i]:ConditionType() == pEventType then
                return self._EventConditions[i]
            end
        end
    end
    return nil
end
function RMEventTrigger:OnGetEventListener(pEventType,pParam1,pParam2,pParam3)
   local rmEventConditioner = self:GetConditionByEventType(pEventType)
    if rmEventConditioner == nil then return false end
    local isPass =  rmEventConditioner:OnGetEventListener(pEventType,pParam1,pParam2,pParam3)
    --Logger.LogError("isPass")
    --Logger.LogError(isPass)
    rmEventConditioner:SetIsPass(isPass)
    local isTrigger = self:IsTrigger()
    self._IsTrigger = isTrigger
    --Logger.LogError("isTrigger")
    --Logger.LogError(isTrigger)
    return isTrigger
end
function RMEventTrigger:OnFinish()
    self._IsTrigger = false
    self._HaveTriggerCount = self._HaveTriggerCount + 1
end
function RMEventTrigger:IsTrigger()
    if self:IsCanTrigger() == false then
        return false
    end
    --Logger.LogError("bindParm1"..self._BindParam1.."bindparam2"..self._BindParam2)
    if self._EventConditions ~= nil then
        for k,v in pairs(self._EventConditions) do
            --Logger.LogError("v:GetIsPass()"..v:GetIsPass())
            if v:GetIsPass() == false then
                return false
            end
        end
    end
    return true
end



