---@class UIConst

---@class UIConst.CtrlState
---@field public Created number
---@field public PrePrepare number
---@field public PrePrepare_Finish number
---@field public LoadResource number
---@field public LoadResource_Finish number
---@field public SetPanelData number
---@field public PostPrepare number
---@field public PostPrepare_Finish number
---@field public ReadyEnter number
---@field public OnScreen number

---@class UIConst.PrevState
---@field public Active number
---@field public Disable number
---@field public Destroy number

---@class UIConst.CtrlManagerState
---@field public DeActive number
---@field public Restoring number
---@field public Active number
---@field public Performing number
---@field public Revoking number

UIConst = {}
-- UICtrlBase的状态
UIConst.CtrlState = {
    Created = 0,
    PrePrepare = 1,
    PrePrepare_Finish = 2,
    LoadResource = 3,
    LoadResource_Finish = 4,
    SetPanelData = 5,
    PostPrepare = 6,
    PostPrepare_Finish = 7,
    ReadyEnter = 8,
    OnScreen = 9,
}
-- UICtrlBase前置Ctrl的行为枚举
UIConst.PrevState = {
    Active = 0,
    Disable = 1,
    Destroy = 2
}
-- UICtrlManager的状态
UIConst.CtrlManagerState = {
    DeActive = 0,   --未激活
    Restoring = 1,  --恢复面板
    Active = 2,     --激活
    Performing = 3, --执行中
    Revoking = 4,   --撤销中
}

-----------------------------------------------------------------------------------
--- UI Depth 管理
UIConst.UIDepthLayer = 0
UIConst.UIDepthBossLayer = 200
UIConst.UIBattleLock = 400
UIConst.UIDepthUpBattle = 500

UIConst.UIDepthSuspend = 1000
UIConst.UINotice = 1500             -- 显示弹窗提示
UIConst.UIDepthMidDialog = 2000     -- 各种提示弹窗
UIConst.UIMideUp = 2050             -- 弹窗上层提示
UIConst.UIDepthGuideLayer = 2100    -- 新手引导层级
UIConst.UIDepthStoryLayer = 2200    -- 剧情层级
UIConst.UIDepthHorseLayer = 2300    -- 走马灯界面层级

UIConst.UIDepthTipLayer = 2500  --断开链接之类的弹窗
UIConst.UIDepthBackLayer = 2600 --UI黑色转场
UIConst.UIDepthLoading = 3000
UIConst.UIDepthBlocker = 4000
UIConst.UIDepthAlert = 4500
UIConst.UIClickEffet = 5000
UIConst.BattleUIDepth = -1

-- 每层panel的depth差值
UIConst.DepthDelta = 10

------------------------------------------------------------------------------------
UIConst.HierachyPathUI = "UI Root/Camera/Anchor/SubUI"
--UIConst.HierachyPathUI = "__RedmoonGlobals__/UIRootManager/2DUIRoot/Camera/Anchor/SubUI"
UIConst.BlockLayerName = "BlockerLayer"
UIConst.BattleUIRoot = "BattleUI"
UIConst.TipLayerName = "TipLayer"
UIConst.DontDestoryUIRoot = "__RedmoonGlobals__/UIRootManager/2DUIRoot/Camera/Anchor/SubUI"

UIConst = read_only(UIConst)