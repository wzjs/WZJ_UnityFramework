local super = require "Component/Viewer/RmUIBase"

ListViewRoot=class("ListViewRoot",super)
---@class ListViewRoot:RmUIBase
---@field private E_OnClickListUnit fun( number) 点击list单元


function ListViewRoot.Create(o)
    -- body
    return ListViewRoot.New(o)
end

function ListViewRoot:ctor(obj)
    -- body
    ListViewRoot.super.ctor(self,obj)
	self.E_OnClickListUnit = nil

end

function ListViewRoot:Awake()
    -- body
	---@type UnityEngine.GameObject
	self.goScrollView = BehaviourUtility.GetGameObject(self, "ScrollView")
	---@type UnityEngine.GameObject
	self.goGrid = BehaviourUtility.GetGameObject(self, "Grid")
	---@type UIEventListener
	self.elListItem = BehaviourUtility.GetComponent(self, "ListItem", "UIEventListener")
	---@type UISprite
	self.spListItem = BehaviourUtility.GetComponent(self, "ListItem", "UISprite")

end
function ListViewRoot:AddUnit()

	local go = UnityEngine.GameObject.Instantiate(self.spListItem.gameObject)
	GameObjectExtension.SetParent(go,self.goGrid.gameObject.transform, true)

	local goEvent = BehaviourUtility.GetComponentInGameObject(go,"UIEventListener")
	goEvent.gameObject:SetActive(true)
	goEvent.onClick = function()
		--Logger.Log("push unit")
		InvokeSafely(self.E_OnClickListUnit)
	end


end
function ListViewRoot:DoPrepare(  )
end

function ListViewRoot:DoShowOffScreen( )
    -- body
end

function ListViewRoot:DoShowOnScreen( )
    -- body
end

function ListViewRoot:PlayEnterEffects( callBack )
    callBack()
end

function ListViewRoot:PlayExitEffects( callBack )
    -- body
    callBack()
end

function ListViewRoot:DoDispose(  )
    -- body
end

function ListViewRoot:DoDestory()
end
