---@class UICtrlPolicyBase
UICtrlPolicyBase = class("UICtrlPolicyBase")

---@field _Ctrls table<UICtrlBase>
---@field _BaseDepth number
---@field private _State number UIConst.CtrlManagerState

function UICtrlPolicyBase:ctor(baseDepth)
    Assert.IsNumber(baseDepth)
    self._Ctrls = System.List(System.Object)()
    self._RestoreCtrls = System.List(System.Object)()
    self._RescoreCtrlPreStates = System.List(System.Object)()
    self._RescoreCtrlCurStates = System.List(System.Object)()

    self._State = UIConst.CtrlManagerState.DeActive
    self._BaseDepth = baseDepth
end

---@return UICtrlBase
function UICtrlPolicyBase:GetTopCtrl()
    if self._Ctrls:getCount() == 0 then
        return nil
    end
    local last = self._Ctrls:get(self._Ctrls:getCount() - 1)
    return last
end
---@return number 返回当前UICtrl数量
function UICtrlPolicyBase:GetCtrlsCount(  )
    return self._Ctrls:getCount()
end

---@return number 返回基础深度
function UICtrlPolicyBase:GetBaseDepth()
    return self._BaseDepth
end

---@param uiCtrl UICtrlBase
---@return boolean
function UICtrlPolicyBase:CheckHasActiveSameCtrl(uiCtrl)
    if self._Ctrls:getCount() == 0 then
        return false
    end
    for i=0, self._Ctrls:getCount()-1 do
        local item = self._Ctrls:get(i)
        if item._State >= UIConst.CtrlState.LoadResource and uiCtrl._Keyword == item._Keyword then
            return true
        end
    end
    return false
end

---@param keyword string
---@return number
function UICtrlPolicyBase:GetCtrlsCountByKeyWord(keyword)
    local num = 0
    if self._Ctrls:getCount() == 0 then
        return num
    end
    for i=0, self._Ctrls:getCount()-1 do
        local item = self._Ctrls:get(i)
        if item._State >= UIConst.CtrlState.LoadResource and keyword == item._Keyword then
            num = num + 1
        end
    end
    return num
end
function UICtrlPolicyBase:CheckHasActiveSameCtrlInStack(keyword)
    local num = 0
    if self._Ctrls:getCount() == 0 then
        return false
    end
    for i=0, self._Ctrls:getCount()-1 do
        local item = self._Ctrls:get(i)
        if item._State >= UIConst.CtrlState.LoadResource and keyword == item._Keyword then
            num = num + 1
        end
    end
    return num > 1
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyBase:Perform(uiCtrl, callback, performData)
    ThrowException("Not implement Perform()")
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyBase:RevokeTop(callback, performData)
    ThrowException("Not implement RevokeTop()")
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyBase:SaveAndRelease(callback, performData)

    ThrowException("Not implement SaveAndRelease()")
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyBase:Restore(callback, performData)

    ThrowException("Not implement Restore()")
end
-----------------------------------------------------------------------------------------------------------------
function UICtrlPolicyBase:ClearAllRestoreCtrls()
    self._RestoreCtrls:Clear()
    self._RescoreCtrlPreStates:Clear()
    self._RescoreCtrlCurStates:Clear()
end
---@param uiCtrl UICtrlBase
function UICtrlPolicyBase:SaveAndReleaseCtrl(uiCtrl)
    if uiCtrl ~= nil then
        self:PushRestoreCtrl(uiCtrl)
        self:Pop()
    end
end
function UICtrlPolicyBase:GetRestoreCtrlsCount()
    return self._RestoreCtrls:getCount()
end
---@param uictrl UICtrlBase
function UICtrlPolicyBase:PushRestoreCtrl(uictrl)
    self._RestoreCtrls:Add(uictrl)
    local preState = uictrl:GetPrevCtrlState()
    self._RescoreCtrlPreStates:Add(preState)
    self._RescoreCtrlCurStates:Add(uictrl._State)
end
---@return UICtrlBase
function UICtrlPolicyBase:PopRestoreCtrl()
    if self._RestoreCtrls:getCount() == 0 then return nil,nil end
    local lastCtrl = self._RestoreCtrls:get(self._RestoreCtrls:getCount() - 1)
    self._RestoreCtrls:RemoveAt(self._RestoreCtrls:getCount() - 1)

    local lastPreState = self._RescoreCtrlPreStates:get(self._RescoreCtrlPreStates:getCount() - 1)
    self._RescoreCtrlPreStates:RemoveAt(self._RescoreCtrlPreStates:getCount() - 1)

    local lastCurState = self._RescoreCtrlCurStates:get(self._RescoreCtrlCurStates:getCount() - 1)
    self._RescoreCtrlCurStates:RemoveAt(self._RescoreCtrlCurStates:getCount() - 1)

    return lastCtrl,lastPreState,lastCurState
end
---@return UICtrlBase
function UICtrlPolicyBase:PeekRestoreCtrl()
    local count = self._RestoreCtrls:getCount()
    if count == 0 then return nil end
    local result = self._RestoreCtrls:get(count - 1)
    local lastPreState = self._RescoreCtrlPreStates:get(count - 1)
    local lastCurState = self._RescoreCtrlCurStates:get(count - 1)

    return result,lastPreState,lastCurState
end

-----------------------------------------------------------------------------------------------------------------
---@param uictrl UICtrlBase
function UICtrlPolicyBase:Push(uictrl)
    self._Ctrls:Add(uictrl)
end

---@return UICtrlBase
function UICtrlPolicyBase:Pop()
    if self._Ctrls:getCount() == 0 then
        return nil
    end
    local last = self._Ctrls:get(self._Ctrls:getCount() - 1)
    self._Ctrls:RemoveAt(self._Ctrls:getCount() - 1)
    self:ShowCtrlStacks()
    return last
end

---@return UICtrlBase
function UICtrlPolicyBase:Peek()
    if self._State == UIConst.CtrlManagerState.DeActive then
        UICtrlUtility.LogError("Cannot peek, Current State is " .. self._State )
        return nil
    end
    local count = self._Ctrls:getCount()
    if count == 0 then
        return nil
    end
    local result = self._Ctrls:get(count-1)
    return result
end

---@param keyword string
---@return UICtrlBase
function UICtrlPolicyBase:PeekForSpecific(keyword)
    if self._State == UIConst.CtrlManagerState.DeActive then
        UICtrlUtility.LogError("Cannot peek, Current State is " .. self._State )
        return nil
    end
    local count = self._Ctrls:getCount()
    if count == 0 then
        return nil
    end
    for i=0, count-1 do
        if self._Ctrls:get(i)._Keyword == keyword then
            return self._Ctrls:get(i)
        end
    end
    return nil
end

function UICtrlPolicyBase:ShowCtrlStacks()
    local msg = "CtrlStacks: "
    if self._Ctrls:getCount() > 0 then
        for i=0, self._Ctrls:getCount()-1 do
            msg = msg .." ; "..self._Ctrls:get(i)._Keyword
        end
    end
    UICtrlUtility.LogInfo(msg)
end

---@param skipTopCount number
---@param skipBottomCount number
---@return table<UICtrlBase>
function UICtrlPolicyBase:GetStackList( skipTopCount,skipBottomCount )
    local result = {}
    skipTopCount = skipTopCount or 0
    skipBottomCount = skipBottomCount or 0
    local startIndex = 0 + skipBottomCount
    local endIndex = self._Ctrls:getCount() - 1 - skipTopCount
    if startIndex > endIndex then
        return result
    else
        for i = endIndex, startIndex, -1 do
            table.insert(result, self._Ctrls:get(i))
        end
    end
    return result
end
----------------------------------------------------------------------------------------------------------------------------

return UICtrlPolicyBase