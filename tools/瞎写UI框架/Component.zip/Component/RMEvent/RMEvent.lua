---@class RMEvent
RMEvent = class("RMEvent")

function RMEvent:ctor()
    self._BindTaskId = 0 --绑定的任务Id
    self._EventId = 0
    ---@type RMEventTrigger
    self._EventTrigger = RMEventTrigger.New()
    ---@type RMEventResult[]
    self._AllEventResult = {}
    self._StoryId = 0
    ---@type number
    self._ObjectId = nil    --  部件的id
    ---@type table
    self._ObjectCreatPars = {}--生成部件的附带参数
    self._Position = nil
    self._FinishCall = nil

    ---@type DMThing[]
    self._RewardThings = {}
    ---@type boolean
    self._HavePick = false -- 是否奖励已经领取
    self._IsShow = true --奖励是否需要展示
end
---@return boolean
function RMEvent:IsShow()
    return self._IsShow
end
---@return number
function RMEvent:SetBindTaskId()
    return self._BindTaskId
end
---@param pPick boolean
function RMEvent:SetHavePick(pPick)
    self._HavePick = pPick
end
---@return boolean
function RMEvent:IsHaveReward()
    return self._RewardThings ~= nil and #self._RewardThings > 0
end
---@return table
function RMEvent:GetObjectCreatPars()
    return self._ObjectCreatPars
end
---@return number
function RMEvent:GetObjectId()
    return self._ObjectId
end
---@return boolean
function RMEvent:HaveObjectEvent()
    return self._ObjectId > 0
end
---@return boolean
function RMEvent:UIPositionMatch(pUIMainId,pUISubId,pParam3)
    if self._Position ~= nil then
        if pParam3 ~= nil then
            if pParam3 ~= self._Position.Interface3 then
                return false
            end
        end
        return self._Position.Interface1 == pUIMainId and (self._Position.Interface2 == nil or
                self._Position.Interface2 == 0 or self._Position.Interface2 == pUISubId)
    end
    return false
end

---@return boolean
function RMEvent:IsHavePosition()
    return self._Position ~= nil
end
function RMEvent:SetFinishCall(pFinishCall)
    self._FinishCall = pFinishCall
end
---@return boolean
function RMEvent:IsConditionEventType(pEventType)
    return self._EventTrigger:GetConditionByEventType(pEventType) ~= nil
end

function RMEvent:SynchConf(pEventId,pEventData)
    if pEventData == nil then return end
    self._EventId = pEventId
    self._StoryId = pEventData.Story
    self._ObjectId = pEventData.ObjectId
    self._ObjectCreatPars = pEventData.ObjectCreatType
    self._Position = pEventData.Position
    self._EventTrigger:SynchConf(pEventId,pEventData)
    self._IsShow = pEventData.IsShow

    if pEventData.EventResults ~= nil and #pEventData.EventResults > 0 then
        --Logger.LogInfo(#pEventData.EventResults)
        for i = 1 ,#pEventData.EventResults do
            local eventResult = pEventData.EventResults[i]
            local rmEventResult = RMEventResult.Create(pEventId,eventResult.Group,eventResult.Type,eventResult.Param1,eventResult.Param2,eventResult.Param3)
            table.insert(self._AllEventResult,rmEventResult)
        end
    end

    if pEventData.Rewards ~= nil then
        for i = 1 ,#pEventData.Rewards do
            local rewardData = pEventData.Rewards[i]
            local dmThing = DMThing.New()
            dmThing:SetDMThingByRewrdConf(rewardData.Type,rewardData.Id,rewardData.Count,nil)
            table.insert(self._RewardThings,dmThing)
        end
    end
end
---@return boolean
function RMEvent:IsTrigger()
    return self._EventTrigger:IsTrigger()
end

---@return boolean
function RMEvent:IsBattleEvent()
    return self._EventTrigger:IsBattleTrigger()
end
---@return number
function RMEvent:GetStoryId()
    return  self._StoryId
end
---@return boolean
function RMEvent:IsCanTrigger()
   return self._EventTrigger:IsCanTrigger()
end
---@return number
function RMEvent:GetTriggerId()
    return self._EventTrigger:GetTriggerId()
end
---@return number
function RMEvent:GetEventId()
    return self._EventId
end
---@return RMEventResult[]
function RMEvent:GetSelectRmResult(pSelectIndex)
    if self._AllEventResult ~= nil and #self._AllEventResult > 0 then
        local allSelectResult = {}
        for i = 1 ,#self._AllEventResult do
            local rmEventResult = self._AllEventResult[i]
            if rmEventResult:IsSelectResult(pSelectIndex) then
                table.insert(allSelectResult,rmEventResult)
            end
        end
        return allSelectResult
    end
    return nil
end

---@param pEventResults RMEventResult[]
---@param pCurRunIndex number
---@param pCallBack fun()
function RMEvent:RunAllResult(pEventResults,pCurRunIndex,pCallBack)
    Logger.LogInfo("#pEventResults"..#pEventResults.."pCurRunIndex"..pCurRunIndex)
    if pEventResults == nil or #pEventResults < 1 then
        InvokeSafely(pCallBack)
        return
    end
    if pCurRunIndex > #pEventResults then
        InvokeSafely(pCallBack)
        return
    end
    local runResult = pEventResults[pCurRunIndex]
    runResult:RunEventResult(function ()
        self:RunAllResult(pEventResults,pCurRunIndex + 1,pCallBack)
    end,self._IsShow)
end

function RMEvent:OnFinish(pSelectIndex,pCallBack)
    Logger.LogInfo("RMEvent OnFinish EventId is :".. self:GetEventId().."pSelectIndex is :"..pSelectIndex)
    local runResults = self:GetSelectRmResult(pSelectIndex)

    if runResults ~= nil and #runResults > 0 then
        self:RunAllResult(runResults,1,function ()
            InvokeSafely(pCallBack)
            InvokeSafely(self._FinishCall,self._EventId)
        end)
    else
        InvokeSafely(pCallBack)
        InvokeSafely(self._FinishCall,self._EventId)
    end
    if self:IsHaveReward() and self._HavePick == false then
        PlayerEventOp.SendPickMessage("Event",self:GetEventId(),nil)
    end
end
function RMEvent:Clear()
    self:DestroyObjectEvent()
end
function RMEvent:DestroyObjectEvent()
    if self:HaveObjectEvent() then
        PlayerEventOp.DestroyObject(self)
    end
end
function RMEvent:GetRMEventTrigger()
    return self._EventTrigger
end
--添加界面的部件
function RMEvent:StartRunObjectEvent()
    Logger.LogInfo("RMEvent StartRunObjectEvent >>>>>>> ")
    if self:HaveObjectEvent() then
        PlayerEventOp.CreatObject(self)
    end
end




