---@class DMCommonView
DMCommonView = class("DMCommonView")

---@return DMDialogView
function DMCommonView.Create(pBgName,pBagPos)
    return DMCommonView.New()
end

function DMCommonView:ctor()
    self._BgTxuter =""
    self._pos = Vector3.zero
    self._heigt = 100
    self._weight = 100
    self._titlText = ""
    self._closePos = Vector3.zero
end

