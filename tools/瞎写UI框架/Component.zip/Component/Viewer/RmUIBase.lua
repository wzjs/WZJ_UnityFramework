--[[ UI State Machine:
                                                                 EnterScreen()
          Prepare()           ShowOffScreen()                |-----------------|
Created ---------> Prepared ------------> OffScreen ----------    Animating    ---------> OnScreen
          Dispose()                                          |-----------------|
                                                                 ExitScreen()
子类界面继承该脚本扩展
]]--

---@field public gameObject GameObject
---@field public transform Transform
---@field public OnShowOnScreenCall function
---@field private _UIEventPackager RmUIEventPackager

local super = require "Foundation/Behaviour/LuaMonoBehaviour"
---@class RmUIBase : LuaMonoBehaviour
RmUIBase = class("RmUIBase", super)

local logger = Logger.Create("RmUIBase")
local showLog = false

---@type table<number>
RmUIBase.UIState = {}
RmUIBase.UIState.Created = 0
RmUIBase.UIState.Prepared = 1
RmUIBase.UIState.OffScreen = 2
RmUIBase.UIState.Animating = 3
RmUIBase.UIState.OnScreen = 4

RmUIBase._internalState = RmUIBase.UIState.Created

function RmUIBase:ctor( obj )
    RmUIBase.super.ctor(self,obj)
    self._internalState = RmUIBase.UIState.Created
    -----@type UnityEngine.GameObject
    --local go = obj
    -----@type RmLuaBehaviour
    --local luaLns = go:GetComponent("RmLuaBehaviour")
    --local luaFile = luaLns.LuaFileString
    --Logger.LogError("luaFile",luaFile)
end
------------- Tools ----------------

---@param pPathKey string
---@param pSendKey string
---@param pLanuageKey string
---@return CommonBtn
function RmUIBase:SetCommonBtnByPath(pPathKey,pSendKey,pLanuageKey)
    local lbvCommonBtnTable = BehaviourUtility.GetComponent(self, pPathKey, "RmLuaBehaviour")
    if lbvCommonBtnTable ~= nil then
        local lbvCommonBtn = lbvCommonBtnTable:GetLuaIns()
        lbvCommonBtn:SetCommonBtn(pLanuageKey,function () self:SendMessage(pSendKey) end)
        return lbvCommonBtn
    end
    return nil
end

------------- Interface Start -------------
function RmUIBase:DoPrepare( )
end

function RmUIBase:DoShowOffScreen( )
end

function RmUIBase:DoShowOnScreen( )

end

function RmUIBase:PlayEnterEffects( callBack )
    callBack()
end

function RmUIBase:PlayExitEffects( callBack )
    callBack()
end

function RmUIBase:DoDispose(  )
end

function RmUIBase:DoDestory(  )
end

------------- Interface End -------------

function RmUIBase:Prepare( )
    if self._internalState >= RmUIBase.UIState.Prepared then
        return
    end
    self:_internal_set_active_(false)
    self:DoPrepare()
    self._internalState = RmUIBase.UIState.Prepared
end

function RmUIBase:ShowOffScreen( )
    -- body
    if self._internalState >= RmUIBase.UIState.OffScreen then
        return
    end
    --Debugger.Log("-----------------RmUIBase:ShowOffScreen-----------------")
    self:Prepare()
    self:DoShowOffScreen()
    --self.gameObject:SetActive(true)
    self:_internal_set_active_(true)
    --Debugger.Log("-----------------RmUIBase:ShowOffScreen  Prepare-----------------")
    self._internalState = RmUIBase.UIState.OffScreen
end

function RmUIBase:GetComponentByPath(pPath,type_string,showlog)
    return BehaviourUtility.GetComponentByPath(self,pPath,type_string,showlog)
end

---@param onEntered fun()
---@param playEffects boolean
---@param blockScreen boolean
function RmUIBase:EnterScreen( onEntered,playEffects,blockScreen )
    playEffects = playEffects == nil and true or playEffects
    blockScreen = blockScreen == nil and true or blockScreen
    blockScreen = playEffects and blockScreen

    if self._internalState >= RmUIBase.UIState.Animating then
        InvokeSafely(onEntered)
        return
    end

    self:ShowOffScreen()
    -- body
    self._internalState = RmUIBase.UIState.Animating

    if blockScreen then
        --show block
        if showLog then logger:LogErrorEx("++++++++++    Block") end
        UIUtility.SetScreenBlock(true, "RmUIBaseEnter")
    end
    -- log(">>>>>>>>>>>>>>RmUIBase:EnterScreen ",self.gameObject.name)
    self:InternalEnterScreen(onEntered,playEffects,blockScreen)
end

---@param onEntered fun()
---@param playEffects boolean
---@param blockScreen boolean
function RmUIBase:InternalEnterScreen( onEntered,playEffects,blockScreen)
    playEffects = playEffects == nil and true or playEffects
    blockScreen = blockScreen == nil and true or blockScreen
    blockScreen = playEffects and blockScreen
    if playEffects then
        self:PlayEnterEffects(function( )
            -- body
            self:DoShowOnScreen()
            self._internalState = RmUIBase.UIState.OnScreen
            InvokeSafely(onEntered)
            if blockScreen then
                --show lock
                if showLog then logger:LogErrorEx("----------    Unblock") end
                UIUtility.SetScreenBlock(false, "RmUIBaseEnter")
            end
        end)
    else
        self:DoShowOnScreen()
        self._internalState = RmUIBase.UIState.OnScreen
        InvokeSafely(onEntered)
        if blockScreen then
            --show lock
            if showLog then logger:LogErrorEx("----------    Unblock") end
            UIUtility.SetScreenBlock(false, "RmUIBaseEnter")
        end
    end
end

---@param onExited fun()
---@param playEffects boolean
---@param blockScreen boolean
function RmUIBase:ExitScreen( onExited,playEffects,blockScreen )
    playEffects = playEffects == nil and true or playEffects
    blockScreen = blockScreen == nil and true or blockScreen
    blockScreen = playEffects and blockScreen
    if self._internalState <= RmUIBase.UIState.Animating then
        InvokeSafely(onExited)
        return
    end
    self._internalState = RmUIBase.UIState.Animating
    -- playEffects = true
    if playEffects then
        if blockScreen then
            --show block
            if showLog then logger:LogErrorEx("++++++++++    Block") end
            UIUtility.SetScreenBlock(true, "Exit Effects")
        end
        local onEndExistEffect = function()
            self._internalState = RmUIBase.UIState.OffScreen
            --self.gameObject:SetActive(false)
            self:_internal_set_active_(false)
            self._internalState = RmUIBase.UIState.Prepared
            InvokeSafely(onExited)
            if blockScreen then
                --hide block
                if showLog then logger:LogErrorEx("----------    Unblock") end
                UIUtility.SetScreenBlock(false, "Exit Effects")
            end
        end
        self:PlayAnimationBinderByKey(LuaMonoBehaviour.ExistAniKey,function ()
            onEndExistEffect()
        end)
    else
        self._internalState = RmUIBase.UIState.OffScreen
        self:_internal_set_active_(false)
        self._internalState = RmUIBase.UIState.Prepared
        InvokeSafely(onExited)
    end
end

---@param onDisposed fun()
---@param playEffects boolean
---@param blockScreen boolean
function RmUIBase:Dispose( onDisposed,playEffects,blockScreen )
    -- body
    --Logger.LogError("RmUIBase Dispose")
    playEffects = playEffects == nil and true or playEffects
    blockScreen = blockScreen == nil and true or blockScreen
    blockScreen = playEffects and blockScreen
    if self._internalState <= RmUIBase.UIState.Created then
        InvokeSafely(onDisposed)
        return
    end
    self:ExitScreen(function( )
        self:DoDispose()
        self._internalState = RmUIBase.UIState.Created
        InvokeSafely(onDisposed)
    end,playEffects,blockScreen)
end

function RmUIBase:OnDestroy(  )
    self:DoDestory()
    self.gameObject = nil
    self.transform = nil
    self._UIEventPackager = nil
    self.AnimationBinder = nil
    self.ScriptData = {}
    self.ScriptValue = {}
    self.AnimationBinder = nil
    self.AnimationBinderOut = nil
    self.animationBinders = nil
    self:DoDispose()
    --self:Destroy(function ()
    --    --_G[self.class.__cname] = nil
    --    self = nil
    --end,false,false)
end

function RmUIBase:DisposeImmediately()
    self:Dispose(nil, false, false)
end

function RmUIBase:Destroy(callBack,playEffects,blockScreen)
    self:Dispose(function( )
        --UnityEngine.Object.Destroy(self.gameObject)
        InvokeSafely(callBack)
    end,playEffects,blockScreen)
end

function RmUIBase:_internal_set_active_(bActive,pNeedHide)
    local needHide = pNeedHide or false
    if bActive then
        self.transform.localPosition = Vector3 (0, 0, 0)
        LuaHelper.RefreshGOAnchors(self.gameObject,needHide)
    else
        if not GameObjectExtension.IsNil(self.gameObject) then
            LuaHelper.RefreshGOAnchors(self.gameObject,needHide)
            self.transform.localPosition = Vector3 (9999,9999,0)
        end
    end
    --self.gameObject:SetActive(bActive)
end

return RmUIBase