EventConditioner = {}

EventConditioner.ConditionType_None = "None"--无
EventConditioner.ConditionType_OnTaskGet = "OnTaskGet"-- 接取某个任务  任务id
EventConditioner.ConditionType_OnTaskFinish = "OnTaskFinish"-- 完成某个任务 任务id
EventConditioner.ConditionType_OnEventFinish = "OnEventFinish"--完成某个事件 事件id
EventConditioner.ConditionType_OnStageFirstPass = "OnStageFirstPass"--首次通过某一关 关卡id
EventConditioner.ConditionType_OnBuildingCreatFinish = "OnBuildingCreatFinish"--建筑建造完成 建筑id
EventConditioner.ConditionType_OnBuildingLevelUpFinish = "OnBuildingLevelUpFinish"--建筑升级完成 建筑id 建筑等级
EventConditioner.ConditionType_OwnThingGreaterOrEqual = "OwnThingGreaterOrEqual"-- 拥有物品≥一定数量（魔物、道具、装备）--物品类型 物品id 物品数量
EventConditioner.ConditionType_OwnThingLess = "OwnThingLess" --拥有物品<一定数量（魔物、道具、装备）--物品类型 物品id 物品数量
EventConditioner.ConditionType_OnPlayerLevelReach = "OnPlayerLevelReach" --玩家达到某个等级 等级
EventConditioner.ConditionType_OnNpcDialog = "OnNpcDialog"--与xx对话 npcid 任务id

EventConditioner.ConditionType_OnBattleSettleClose = "OnBattleSettleClose"-- 战斗结束后结算面板关闭后触发 关卡id
EventConditioner.ConditionType_OnBattleEnd = "OnBattleEnd"-- 战斗结束后触发
EventConditioner.ConditionType_OnBattleRoundNum = "OnBattleRoundNum"-- 战斗回合触发

EventConditioner.ConditionType_OnEnterDuplicate = "OnEnterDuplicate"-- 进入第N章第N关（通过触发次数字段来判定触发几次）
EventConditioner.ConditionType_OnBattleWaveFinish = "OnBattleWaveFinish"-- 某一关某一波完成后（弹珠前）
EventConditioner.ConditionType_OnBattleWaveStart = "OnBattleWaveStart"-- 某一关某一波开始前（弹珠完成后）
EventConditioner.ConditionType_OwnTargetIdHero = "OwnTargetIdHero"--携带指定的魔物
EventConditioner.ConditionType_OwnTargetIdLord = "OwnTargetIdLord"--携带指定魔王
EventConditioner.ConditionType_OnChapterDPReach = "OnChapterDPReach"--章节dp点达到X（dp点增加时）
EventConditioner.ConditionType_OnGetForeground = "OnGetForeground" -- 当某个界面切到前台的时候
EventConditioner.ConditionType_StatgeIsPass = "StatgeIsPass" -- 某一关通关
EventConditioner.ConditionType_StatgeIsNotPass = "StatgeIsNotPass" -- 某一关未通关
EventConditioner.ConditionType_ChapterIsPass = "_ChapterIsPass" --某一章节通关
EventConditioner.ConditionType_OnOneUIForward = "OnOneUIForward" --当有某个界面切到前台的时候
EventConditioner.ConditionType_OnBattle_SkillEnd = "OnBattle_SkillEnd" --某个英雄释放完奥义

EventConditioner.ConditionType_Battle_CardReady = "CardReady" --战斗卡牌可以释放
EventConditioner.ConditionType_Battle_LoadFinish = "Battle_LoadFinish" --进入战场，敌我双方加载完毕后
EventConditioner.ConditionType_Battle_AngerGreaterOrEqual = "Battle_AngerGreaterOrEqual" --战斗中，怒氣值的数量≥配置值时
EventConditioner.ConditionType_OnBattle_HeroDead = "OnBattle_HeroDead"--当我方任意一个魔王死亡的时候
EventConditioner.ConditionType_OnBattle_CanSkill = "OnBattle_CanSkill"--当某个英雄可以释放技能
EventConditioner.ConditionType_OnGuideFinish = "OnGuideFinish"--当个教学模块完成的时候
EventConditioner.ConditionType_GuideNotFinish = "GuideNotFinish"--教学模块未完成

EventConditioner.ConditionType_ChapterRewardCanPick = "ChapterRewardCanPick"--当某一章节可以领取战绩时候
EventConditioner.ConditionType_HeroCanStarUp = "HeroCanStarUp"--某魔物可升星
EventConditioner.ConditionType_IsHaveFreeHero = "IsHaveFreeHero"--背包中存在未上阵的英雄
EventConditioner.ConditionType_LordWareEquip = "LordWareEquip"--领主穿戴装备
EventConditioner.ConditionType_LordDontWareEquip = "LordDontWareEquip"--领主未穿戴装备

EventConditioner.ConditionType_BuildingLevel = "BuildingLevel"--建筑等级达到
EventConditioner.ConditionType_Battle_OnCardCanCombine = "OnCardCanCombine"--有任意遗物可合成时
EventConditioner.ConditionType_Battle_OnGetLordCard = "OnGetLordCard"--有领主卡牌获得
EventConditioner.ConditionType_Battle_OnBossDie = "OnBossDie"--有Boss死亡
EventConditioner.ConditionType_MapChapterIslock = "ChapterIslock"--地图章节未解锁

EventConditioner.ConditionType_Battle_OnDIYEvent = "OnDIYEvent"--游戏自定义事件触发点

EventConditioner.DIYEvent = {}
EventConditioner.DIYEvent.HeroGainFinish = 1          -- 英雄获得动画完成
EventConditioner.DIYEvent.ChapterUnlockFinish = 2     -- 章节动画解锁完成
EventConditioner.DIYEvent.BranchUnlockFinish = 3      -- 支线解锁动画完成
EventConditioner.DIYEvent.BattleSettleFinish = 4      -- 战斗结算动画完成
EventConditioner.DIYEvent.NewFunctionFinish = 5          -- 新功能界面关闭
EventConditioner.DIYEvent.LoadingUIFinish = 6                   -- Loading界面完全结束
EventConditioner.DIYEvent.NewFunctionAniFinish = 7              -- 新功能界面动画完成
EventConditioner.DIYEvent.OnNormalBattleFailed = 8              --普通关卡战斗失败
EventConditioner.DIYEvent.OnStatusClose = 9                     --位阶提升界面关闭
EventConditioner.DIYEvent.OnBattleStartAnimEnd = 10             --战斗開場动画结束
EventConditioner.DIYEvent.OnMazeMainOpen = 11                   --迷宫主界面打开
EventConditioner.DIYEvent.OnBuildOpOpen = 12                    --建筑操作界面打开
EventConditioner.DIYEvent.OnMainTownOpen = 13                   --当小镇界面打开的时候
EventConditioner.DIYEvent.OnFetterGiftOpen = 14                 --当羁绊赠礼界面打开的时候
EventConditioner.DIYEvent.OnRestaurantRoomOpen = 15           --当堪探进改造弹窗界面打开的时候
EventConditioner.DIYEvent.OnCommonRewadCanClose = 16          --当恭喜界面动画完成结束（点击一下就关闭的时候）
EventConditioner.DIYEvent.BattleSettleWinFinish = 17          --普通战斗胜利结算动画完成（点击一下就关闭的时候）
EventConditioner.DIYEvent.UIMapNewMoonUnlockAnimFinish = 18   --大地图迷宫解锁动画完成
EventConditioner.DIYEvent.OnPlayerNewNameEnd = 19             --玩家名字取完
EventConditioner.DIYEvent.MazeFirstReach = 20                 --玩家首次到达某个节点
EventConditioner.DIYEvent.MazeBoxEnter = 21                   --宝箱房进入
EventConditioner.DIYEvent.UIMapChapterAnim = 22                  --第一次进入大地图章节
EventConditioner.DIYEvent.MazeLoseFinish = 23                  --迷宫输了回到入口界面
EventConditioner.DIYEvent.BattleBossAnim = 24                  --boss动画展示完毕

EventConditioner.ConditionTypes = {}
EventConditioner.ConditionTypes[0] = EventConditioner.ConditionType_None
EventConditioner.ConditionTypes[1] = EventConditioner.ConditionType_OnTaskGet
EventConditioner.ConditionTypes[2] = EventConditioner.ConditionType_OnTaskFinish
EventConditioner.ConditionTypes[3] = EventConditioner.ConditionType_OnEventFinish
EventConditioner.ConditionTypes[4] = EventConditioner.ConditionType_OnStageFirstPass
EventConditioner.ConditionTypes[5] = EventConditioner.ConditionType_OnBuildingCreatFinish
EventConditioner.ConditionTypes[6] = EventConditioner.ConditionType_OnBuildingLevelUpFinish
EventConditioner.ConditionTypes[7] = EventConditioner.ConditionType_OwnThingGreaterOrEqual
EventConditioner.ConditionTypes[8] = EventConditioner.ConditionType_OwnThingLess
EventConditioner.ConditionTypes[9] = EventConditioner.ConditionType_OnPlayerLevelReach
EventConditioner.ConditionTypes[10] = EventConditioner.ConditionType_OnNpcDialog
EventConditioner.ConditionTypes[11] = EventConditioner.ConditionType_OnBattleSettleClose
EventConditioner.ConditionTypes[12] = EventConditioner.ConditionType_OnEnterDuplicate
EventConditioner.ConditionTypes[13] = EventConditioner.ConditionType_OnBattleWaveFinish
EventConditioner.ConditionTypes[14] = EventConditioner.ConditionType_OnBattleWaveStart
EventConditioner.ConditionTypes[15] = EventConditioner.ConditionType_OwnTargetIdHero
EventConditioner.ConditionTypes[16] = EventConditioner.ConditionType_OwnTargetIdLord
EventConditioner.ConditionTypes[17] = EventConditioner.ConditionType_OnChapterDPReach
EventConditioner.ConditionTypes[20] = EventConditioner.ConditionType_OnGetForeground
EventConditioner.ConditionTypes[21] = EventConditioner.ConditionType_StatgeIsPass
EventConditioner.ConditionTypes[22] = EventConditioner.ConditionType_ChapterIsPass
EventConditioner.ConditionTypes[23] = EventConditioner.ConditionType_OnOneUIForward
EventConditioner.ConditionTypes[24] = EventConditioner.ConditionType_OnBattle_SkillEnd
EventConditioner.ConditionTypes[25] = EventConditioner.ConditionType_StatgeIsNotPass
EventConditioner.ConditionTypes[26] = EventConditioner.ConditionType_GuideNotFinish
EventConditioner.ConditionTypes[27] = EventConditioner.ConditionType_OnBattleEnd
EventConditioner.ConditionTypes[28] = EventConditioner.ConditionType_OnBattleRoundNum
EventConditioner.ConditionTypes[29] = EventConditioner.ConditionType_LordDontWareEquip
EventConditioner.ConditionTypes[30] = EventConditioner.ConditionType_MapChapterIslock

EventConditioner.ConditionTypes[101] = EventConditioner.ConditionType_Battle_CardReady
EventConditioner.ConditionTypes[102] = EventConditioner.ConditionType_Battle_LoadFinish
EventConditioner.ConditionTypes[103] = EventConditioner.ConditionType_Battle_AngerGreaterOrEqual
EventConditioner.ConditionTypes[104] = EventConditioner.ConditionType_OnBattle_HeroDead
EventConditioner.ConditionTypes[105] = EventConditioner.ConditionType_OnBattle_CanSkill
EventConditioner.ConditionTypes[106] = EventConditioner.ConditionType_OnGuideFinish
EventConditioner.ConditionTypes[107] = EventConditioner.ConditionType_ChapterRewardCanPick
EventConditioner.ConditionTypes[108] = EventConditioner.ConditionType_HeroCanStarUp
EventConditioner.ConditionTypes[109] = EventConditioner.ConditionType_IsHaveFreeHero
EventConditioner.ConditionTypes[110] = EventConditioner.ConditionType_LordWareEquip
EventConditioner.ConditionTypes[111] = EventConditioner.ConditionType_BuildingLevel
EventConditioner.ConditionTypes[112] = EventConditioner.ConditionType_Battle_OnCardCanCombine
EventConditioner.ConditionTypes[113] = EventConditioner.ConditionType_Battle_OnGetLordCard
EventConditioner.ConditionTypes[114] = EventConditioner.ConditionType_Battle_OnBossDie
EventConditioner.ConditionTypes[999] = EventConditioner.ConditionType_Battle_OnDIYEvent


EventConditioner.Funcs = {}
EventConditioner.Funcs[EventConditioner.ConditionType_Battle_OnGetLordCard] = function() return true end
EventConditioner.Funcs[EventConditioner.ConditionType_OnTaskGet] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnTaskFinish] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnEventFinish] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnStageFirstPass] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBuildingCreatFinish] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBuildingLevelUpFinish] = function(pP1,pSP1,pP2,pSP2)
    return pP1 == pSP1 and pP2 == pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OwnThingGreaterOrEqual] = function(pP1,pSP1,pP2,pSP2,pP3,pSP3)
    return  pP2 == pSP2 and pP3 >= pSP3
end
EventConditioner.Funcs[EventConditioner.ConditionType_OwnThingLess] = function(pP1,pSP1,pP2,pSP2,pP3,pSP3)
    return  pP2 == pSP2 and pP3 < pSP3
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnPlayerLevelReach] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnNpcDialog] = function(pP1,pSP1,pP2,pSP2)
    return pP1 == pSP1 and pP2 == pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattleSettleClose] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattleEnd] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattleRoundNum] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnEnterDuplicate] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattleWaveFinish] = function(pP1,pSP1,pP2,pSP2)
    return pP1 == pSP1 and pP2 == pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattleWaveStart] = function(pP1,pSP1,pP2,pSP2)
    return pP1 == pSP1 and pP2 == pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OwnTargetIdHero] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OwnTargetIdLord] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnChapterDPReach] = function(pP1,pSP1,pP2,pSP2)
    return pP1 == pSP1 and pP2 >= pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnGetForeground] = function(pP1,pSP1,pP2,pSP2,pP3,pSP3)
    if pSP3 ~= 0  and pSP3 ~= pP3 then return false end
    return pP1 == pSP1 and pP2 == pSP2
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnOneUIForward] = function(pP1,pSP1) return true end
EventConditioner.Funcs[EventConditioner.ConditionType_ChapterIsPass] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_Battle_CardReady] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_Battle_LoadFinish] = function(pP1,pSP1) return true end
EventConditioner.Funcs[EventConditioner.ConditionType_Battle_AngerGreaterOrEqual] = function(pP1,pSP1) return pP1 >= pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattle_HeroDead] = function(pP1,pSP1) return true end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattle_CanSkill] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_HeroCanStarUp] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_OnGuideFinish] = function(pP1,pSP1)
    return  Me.GetDMGuildeManager():IsFinishGuide(pSP1)
end
EventConditioner.Funcs[EventConditioner.ConditionType_OnBattle_SkillEnd] = function(pP1,pSP1) return  pP1 == pSP1 end

EventConditioner.Funcs[EventConditioner.ConditionType_LordWareEquip] = function(pP1,pSP1)
    local dmLord = Me.GetPlayerAllInfo():GetPlayerBag():GetLordBag():GetLordById(pP1)
    if dmLord ~= nil then
        return dmLord:IsCanWareEquipByPos(pSP1) == false
        --return dmLord:GetEquipByPos(pSP1) ~= nil
    end
    return false
end

EventConditioner.Funcs[EventConditioner.ConditionType_LordDontWareEquip] = function(pP1,pSP1)
    local dmLord = Me.GetPlayerAllInfo():GetPlayerBag():GetLordBag():GetLordById(pP1)
    if dmLord ~= nil then
        return dmLord:IsEmptyEquipByPos(pSP1)
    end
    return false
end

EventConditioner.Funcs[EventConditioner.ConditionType_Battle_OnBossDie] = function(pP1,pSP1) return pP1 == pSP1 end
EventConditioner.Funcs[EventConditioner.ConditionType_Battle_OnDIYEvent] = function(pP1,pSP1,pP2,pSP2)
    if pSP2 ~= 0 and pSP2 ~= nil then
        if pSP1 == pP1 and pP2 == pSP2 then
            return true
        end
        return false
    else
        return pSP1 == pP1
    end
end
