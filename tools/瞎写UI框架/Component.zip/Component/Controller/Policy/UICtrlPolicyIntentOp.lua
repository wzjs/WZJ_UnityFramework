UICtrlPolicyIntentOp = {}

---@param isBlock boolean
---@param message string
---@param performData UICtrlPerformData
local function InternalSetScreenBlocker(isBlock, message, performData)
    if performData._UseBlock then
        UIUtility.SetScreenBlock(isBlock, message)
    end
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_Finish(callback, uiCtrl, performData, policy)
    InvokeSafely(callback)
    EventManager:BroadEvent("UICtrlPolicyIntentOp.Perform_Finish",nil, uiCtrl._Keyword)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_InitAndOpenPanel(callback, uiCtrl, performData, policy, invokeFinish)
    --- Set Data
    local topCtrl = policy:Peek()
    uiCtrl._PrevCtrl = topCtrl
    if  topCtrl ~= nil then
        topCtrl._NextCtrl = uiCtrl
    end
    policy:Push(uiCtrl)
    if performData._DepthReduce == true then
        NGUITools.PanelDepthAdd(uiCtrl._Panel, -uiCtrl._PanelDepthSeaLevel)
    else
        NGUITools.PanelDepthAdd(uiCtrl._Panel, uiCtrl._PanelDepthSeaLevel)
    end

    if uiCtrl:GetScript() ~= nil then
        --- 调用事件
        uiCtrl:OnGetForeground()
    end

    InternalSetScreenBlocker(true,"InitAndOpenUICtrl", performData)
    UICtrlBaseOp.EnterScreenUICtrl(uiCtrl,performData._PlayEnterEffect,function()
        if performData._DepthReduce == true then
            NGUITools.PanelDepthAdd(uiCtrl._Panel, uiCtrl._PanelDepthSeaLevel*2)
        end
        InternalSetScreenBlocker(false,"InitAndOpenUICtrl", performData)
        if invokeFinish then
            Perform_Finish(callback, uiCtrl, performData, policy)
        else
            InvokeSafely(callback)
        end

    end)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_AfterPostPrepare(callback, uiCtrl, performData, policy)
    --Logger.LogError("UICtrlPolicyIntentOp Perform_AfterPostPrepare 》》》")
    ---@type UICtrlBase
    local ctrlToExit = nil
    if performData._PrevCtrlState ~= UIConst.PrevState.Active then
        ctrlToExit = policy:Peek()
    end
    --- 调整当前面板的Depth
    uiCtrl._PanelDepthSeaLevel =  UICtrlUtility.CalculateDepth(policy._Ctrls) + policy:GetBaseDepth()
    uiCtrl:SetPrevCtrlState(performData._PrevCtrlState)
    if performData._PrevCtrlState == UIConst.PrevState.Active or ctrlToExit == nil then
        local ctrlToBackground = policy:Peek()
        if ctrlToBackground ~= nil then
            ctrlToBackground:OnGetBackground()
        end
        Perform_InitAndOpenPanel(callback, uiCtrl, performData, policy, true)
    elseif performData._PrevCtrlState == UIConst.PrevState.Disable then
        if not ctrlToExit:IsStateActive() then
            Perform_InitAndOpenPanel(callback, uiCtrl, performData, policy, true)
            return
        end
        --- 隐藏掉2层之前的Ctrls
        local stackList = policy:GetStackList(1)
        for _, ctrl in pairs(stackList)do
            if ctrl:IsStateActive() then
                UICtrlBaseOp.ExitScreenUICtrl(ctrl, false)
            end
        end
        local ulc = UntilLastCall.Create(function()
            --UICtrlBaseOp.ExitScreenUICtrl(ctrlToExit, false, function()
            --    Perform_Finish(callback, uiCtrl, performData, policy )
            --end)
            Perform_Finish(callback, uiCtrl, performData, policy )
        end,2,"Perform_InitAndOpenPanel")

        Perform_InitAndOpenPanel(function()
            --ctrlToExit:OnGetBackground()
            --UICtrlBaseOp.ExitScreenUICtrl(ctrlToExit, performData._PlayExitEffect, function()
            --    ulc:Invoke()
            --end)
            ctrlToExit:OnGetBackground()
            ulc:Invoke()
        end, uiCtrl, performData, policy, false)

        UICtrlBaseOp.ExitScreenUICtrl(ctrlToExit, performData._PlayExitEffect, function()
            ulc:Invoke()
        end)

    elseif performData._PrevCtrlState == UIConst.PrevState.Destroy then
        if not ctrlToExit:IsStateActive() then
            Perform_InitAndOpenPanel(callback, uiCtrl, performData, policy, true)
            return
        end

        --- 摧毁掉2层之前的Ctrls
        local stackList = policy:GetStackList(1)
        for _, ctrl in pairs(stackList)do
            if ctrl:IsStateActive() then
                UICtrlBaseOp.HideAndDestroyUICtrl(ctrl, false)
            end
        end
        --- Ctrl进场
        local ulc = UntilLastCall.Create(function()
            Perform_Finish(callback, uiCtrl, performData, policy )
        end,2,"Perform_Finish")
        Perform_InitAndOpenPanel(function()
            ctrlToExit:OnGetBackground()
            ulc:Invoke()
        end, uiCtrl, performData, policy,false)
        UICtrlBaseOp.HideAndDestroyUICtrl(ctrlToExit, performData._PlayExitEffect, function()
            ulc:Invoke()
        end)
    else
        ThrowException("Unexpected PrevCtrlState " .. performData._PrevCtrlState)
    end
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_AfterLoadResource(callback, uiCtrl, performData, policy)
    --Logger.LogError("UICtrlPolicyIntentOp Perform_AfterLoadResource 》》》")
    InternalSetScreenBlocker(true,"PostPrepareUICtrl", performData)
    UICtrlBaseOp.PostPrepareUICtrl(uiCtrl, function()
        InternalSetScreenBlocker(false,"PostPrepareUICtrl", performData)
        Perform_AfterPostPrepare(callback, uiCtrl, performData, policy)
    end)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_AfterPrePrepare_Success(callback, uiCtrl, performData, policy)
    EventManager:BroadEvent("UICtrlPolicyIntentOp.EventIntentPerform",nil, uiCtrl._Keyword)
    ---@type UICtrlBase
    local lastCtrl = policy:Peek()
    if lastCtrl ~= nil then
        lastCtrl:ReadyBackground()
    end
    --- 旧逻辑中此处需要判定GetPanel是否为空，新逻辑中保证删除panel的时候必须将Ctrl状态设置回PrePrepare_Finish状态
    InternalSetScreenBlocker(true,"LoadResourceUICtrl", performData)
    UICtrlBaseOp.LoadResourceUICtrl(uiCtrl, function()
        --Logger.LogError("UICtrlPolicyIntentOp Perform_AfterPrePrepare_Success 》》》")
        InternalSetScreenBlocker(false,"LoadResourceUICtrl", performData)
        Perform_AfterLoadResource(callback, uiCtrl, performData, policy)
    end,nil,performData)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform(callback, uiCtrl, performData,policy)
    Assert.NotNil(performData, "Perform Data cannot be nil")
    Assert.NotNil(uiCtrl, "UICtrl cannot be nil")
    InternalSetScreenBlocker(true,"PrePrepareUICtrl", performData)
    UICtrlBaseOp.PrePrepareUICtrl(uiCtrl, function()
        InternalSetScreenBlocker(false,"PrePrepareUICtrl", performData)
        Perform_AfterPrePrepare_Success(callback, uiCtrl, performData, policy)
    end,function ()
        InternalSetScreenBlocker(false,"PrePrepareUICtrl", performData)
        InvokeSafely(callback)
    end,performData)
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
function UICtrlPolicyIntentOp.Perform(uiCtrl, callback, performData, policy)
    Perform(callback, uiCtrl, performData, policy)
end

-----------------------------------------------------------------------------------------------------

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke_CloseAndDestroyPanel(callback, uiCtrl, performData, policy)
    uiCtrl:OnGetBackground()
    local popCtrl = policy:Pop()
    --- Pop的Ctrl一定是当前uiCtrl
    Assert.True(popCtrl == uiCtrl)
    uiCtrl._NextCtrl = nil
    uiCtrl._PrevCtrl = nil
    local peekCtrl = policy:Peek()
    if peekCtrl ~= nil then
        peekCtrl._NextCtrl = nil
    end
    UICtrlBaseOp.DestroyUICtrl(uiCtrl, performData._PlayExitEffect, function()
        callback()
    end)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke_Finish(callback, uiCtrl, performData, policy)
    --Logger.LogError("Revoke_Finish >>>>")
    if performData._ReleaseMemory then
        --LuaHelper.DeferFrames(2,function ()
        --    --UIUtility.ReleaseMemory()
        --    --LuaHelper.UnLoadAB()
        --end)
        InvokeSafely(callback)
    else
        InvokeSafely(callback)
    end

    EventManager:BroadEvent("UICtrlPolicyIntentOp.Revoke_Finish",nil, uiCtrl._Keyword)
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke_AfterPostPrepare(callback, uiCtrl, performData, policy,pTopCount)

    local ulc = UntilLastCall.Create(function()
        Revoke_Finish(callback, uiCtrl, performData, policy,pTopCount)
    end,2,"Revoke_Finish")
    --- Dispose Panel
    Revoke_CloseAndDestroyPanel(function()
       -- Logger.LogError("Revoke_CloseAndDestroyPanel >>>>")
        ulc:Invoke()
    end , uiCtrl, performData, policy)

    --- Enter Screen
    ---@type UICtrlBase
    local ctrlToEnter = nil
    if performData._RestorePrevPanel then
        ctrlToEnter = policy:Peek()
    end

    if ctrlToEnter~= nil then
        ---@type UICtrlBase
        local readyCtrl = ctrlToEnter
        while readyCtrl:GetPrevCtrlState() == UIConst.PrevState.Active do
            readyCtrl = readyCtrl._PrevCtrl
            if readyCtrl == nil then
                break
            end
            --所有进场的panel都已经调整过了，所以回退的时候不应该调整
            UICtrlBaseOp.EnterScreenUICtrl(readyCtrl, false)
            --此时未到前台，所以不用调用OnGetToForeground()
        end
        UICtrlBaseOp.EnterScreenUICtrl(ctrlToEnter, performData._PlayEnterEffect, function()
            if pTopCount == nil then
                ctrlToEnter:OnGetForeground()
            end
            ulc:Invoke()
        end)
    else
        ulc:Invoke()
    end
end

---@param ctrlToLoad UICtrlBase[]
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke_AfterLoadResource(ctrlToLoad, callback, uiCtrl, performData, policy,pTopCount)
    if #ctrlToLoad == 0 then
        Revoke_AfterPostPrepare(callback, uiCtrl, performData, policy,pTopCount)
    else
        local ulc = UntilLastCall.Create(function()
            Revoke_AfterPostPrepare(callback, uiCtrl, performData, policy,pTopCount)
        end, #ctrlToLoad,"Revoke_AfterPostPrepare")

        for _,v in pairs(ctrlToLoad) do
            UICtrlBaseOp.PostPrepareUICtrl(v, function()
                ulc:Invoke()
            end)
        end
    end
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke(callback, uiCtrl, performData, policy,pTopCount)
    --Logger.Log("Revoke1")
    if uiCtrl == nil then
        --Logger.Log("Revoke2")
        InvokeSafely(callback)
        return
    end
    if policy:Peek() ~= uiCtrl then
        --Logger.Log("Revoke3")
        return
    end
    if uiCtrl ~= nil then
        --Logger.Log("Revoke4")
        uiCtrl:ReadyBackground()
    end
    --- 获取所有待加载Ctrls
    ---@type UICtrlBase[]
    local ctrlToLoad = {}
    ---@type UICtrlBase
    local ctrl = nil
    local pickCtrl = policy:Peek()
    if pickCtrl ~= nil then
        ctrl = pickCtrl._PrevCtrl
    end
    local isbreak = false
    if performData._RestorePrevPanel then
        while ctrl ~= nil and isbreak == false do
            if ctrl:IsStateDestroy() then
                table.insert(ctrlToLoad, ctrl)
            end
            if ctrl._State < UIConst.CtrlState.LoadResource then
                UICtrlUtility.LogError("Unexpected state is less than LoadResource, Keyword = " .. ctrl._Keyword)
            end
            if ctrl:GetPrevCtrlState() == UIConst.PrevState.Disable or ctrl:GetPrevCtrlState() == UIConst.PrevState.Destroy then
                isbreak = true
            end
            ctrl = ctrl._PrevCtrl
        end
    end

    --Logger.Log("Revoke5")
    --- 开始加载
    if (#ctrlToLoad) == 0 then
        --Logger.Log("Revoke6")
        Revoke_AfterLoadResource(ctrlToLoad, callback, uiCtrl, performData, policy,pTopCount)
    else
        --Logger.Log("Revoke7")
        local ulc = UntilLastCall.Create(function()
            --Logger.Log("Revoke8")
            Revoke_AfterLoadResource(ctrlToLoad, callback, uiCtrl, performData, policy,pTopCount)
        end, #ctrlToLoad,"Revoke_AfterLoadResource")
        --Logger.Log("Revoke9")
        for _, v in pairs(ctrlToLoad) do
            UICtrlBaseOp.LoadResourceUICtrl(v, function()
                NGUITools.PanelDepthAdd(v._Panel, v._PanelDepthSeaLevel)
                --Logger.Log("Revoke10")
                ulc:Invoke()
            end,nil,performData)
            --Logger.Log("Revoke11")
        end
        --Logger.Log("Revoke12")
    end
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
function UICtrlPolicyIntentOp.RevokeTop(uiCtrl, callback, performData, policy,pTopCount)
    --Logger.LogError(uiCtrl._Keyword.."pTopCount"..pTopCount)
    if performData == nil then
        performData = UICtrlManager.PerformActionDefault
    end
    Revoke(callback, uiCtrl, performData, policy,pTopCount)
end
---===================================================================================================
---@param pCallBack fun()
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
function UICtrlPolicyIntentOp.RevokeToBottom(pCallBack,performData,policy)
    local count = 0
    count = policy:GetCtrlsCount()
    if count <= 1 then
        InvokeSafely(pCallBack)
    elseif count == 2 then
        UICtrlPolicyIntentOp.RevokeTop(policy:Peek(), pCallBack , performData, policy)
    else
        local revokePerformData = UICtrlManager.RevokeActionNoEffect
        UICtrlPolicyIntentOp.RevokeCountCtrls(count - 2,revokePerformData,policy,function ()
            UICtrlPolicyIntentOp.RevokeTop(policy:Peek(), pCallBack , performData, policy)
        end)
    end
end
function UICtrlPolicyIntentOp.RevokeAllCtrls(pCallBack,performData,policy)
    local count = 0
    count = policy:GetCtrlsCount()
    if count < 1 then
        InvokeSafely(pCallBack)
    else
        local revokePerformData = UICtrlManager.RevokeActionNoEffect
        UICtrlPolicyIntentOp.RevokeCountCtrls(count,revokePerformData,policy,function ()
            InvokeSafely(pCallBack)
        end)
    end
end
---@param pCount number
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
---@param pCallBack fun()
function UICtrlPolicyIntentOp.RevokeCountCtrls(pCount,performData,policy,pCallBack)
    if pCount < 1 then
        InvokeSafely(pCallBack)
    else
        UICtrlPolicyIntentOp.RevokeTop(policy:Peek(), function ()
            UICtrlPolicyIntentOp.RevokeCountCtrls(pCount - 1,performData,policy,pCallBack)
        end , performData, policy,pCount)
    end
end
---====================================================================================================
--- SaveAndRelease   保存并且销毁所有面板

---@param pCount number
---@param policy UICtrlPolicyBase
---@param pCallBack fun()
local function SaveAndReleaseCountCtrls(pCount,policy,pCallBack)
    if policy ~= nil then
        if pCount > 0 then
            local topCtrl = policy:Peek()
            if topCtrl ~= nil then
                policy:SaveAndReleaseCtrl(topCtrl)
                --Logger.LogError("SaveAndReleaseCountCtrls topCtrl State is : "..topCtrl:GetState())
                UICtrlBaseOp.DestroyUICtrl(topCtrl,false,function ()
                    SaveAndReleaseCountCtrls(pCount - 1,policy,pCallBack)
                end)
            else
                InvokeSafely(pCallBack)
            end
        else
            InvokeSafely(pCallBack)
        end
    else
        InvokeSafely(pCallBack)
    end
end
---@param policy UICtrlPolicyBase
---@param pCallBack fun()
function UICtrlPolicyIntentOp.SaveAndRelease(policy,pCallBack)
    if policy ~= nil then
        policy:ClearAllRestoreCtrls()
        local ctrlsCount = policy:GetCtrlsCount()
        if ctrlsCount > 0 then
            SaveAndReleaseCountCtrls(ctrlsCount,policy,pCallBack)
        else
            InvokeSafely(pCallBack)
        end
    else
        InvokeSafely(pCallBack)
    end
end
---@param pCount number
---@param policy UICtrlPolicyBase
---@param pCallBack fun()
---@param pPreCtrlState UICtrlBase
local function restoreCountCtrls(pCount,policy,pCallBack,pPreCtrlState)
    if policy ~= nil then
        if pCount > 0 then
            local topCtrl,preState,curState = policy:PeekRestoreCtrl()
            Logger.Log("topCtrl: ",topCtrl._Keyword)
            Logger.Log("preState: "..preState)
            Logger.Log("curState: "..curState)
            if topCtrl ~= nil then
                ---@type UICtrlPerformData
                local performData = UICtrlManager.RestoreActionDefault
                if preState ~= nil then
                    --Logger.LogError("pPreCtrl State is : "..pPreCtrlState)
                    if preState == UIConst.PrevState.Destroy then
                        performData = UICtrlManager.RestoreActionDestroyPrev
                    elseif preState == UIConst.PrevState.Disable then
                        performData = UICtrlManager.RestoreActionDisablePrev
                    end
                end
                performData._NeedResload = curState ~= UIConst.CtrlState.LoadResource
                UICtrlPolicyIntentOp.Perform(topCtrl,function ()
                    policy:PopRestoreCtrl()
                    restoreCountCtrls(pCount -1,policy,pCallBack,preState)
                end,performData,policy)
            else
                restoreCountCtrls(pCount -1,policy,pCallBack,nil)
            end
        else
            InvokeSafely(pCallBack)
        end
    else
        InvokeSafely(pCallBack)
    end
end
---@param policy UICtrlPolicyBase
---@param pCallBack fun()
function UICtrlPolicyIntentOp.Restore(policy,pCallBack)
    if policy ~= nil then
        local storeCtrlsCount = policy:GetRestoreCtrlsCount()
        --Logger.LogError(" UICtrlPolicyIntentOp Restore storeCtrlsCount is :"..storeCtrlsCount)
        if storeCtrlsCount > 0 then
            restoreCountCtrls(storeCtrlsCount,policy,pCallBack,nil)
        else
            InvokeSafely(pCallBack)
        end
    else
        InvokeSafely(pCallBack)
    end
end


