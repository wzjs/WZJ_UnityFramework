---@class ScreenLoading
ScreenLoading = {}
ScreenLoading.LoadCtrl = {}
ScreenLoading.LoadCtrl[1] = "Logic.UI.UICtrls.Common.UI_LoadingOneCtrl"
ScreenLoading.LoadCtrl[2] = "Logic.UI.UICtrls.Common.UI_LoadingTwoCtrl"
ScreenLoading.LoadCtrl[3] = "Logic.UI.UICtrls.Common.UI_LoadingThreeCtrl"
ScreenLoading.LoadCtrl[4] = "Logic.UI.UICtrls.Common.UI_LoadingFourCtrl"
ScreenLoading.LoadCtrl[5] = "Logic.UI.UICtrls.Common.UI_LoadingFiveCtrl"
ScreenLoading.LoadCtrl[6] = "Logic.UI.UICtrls.Common.UI_LoadingSixCtrl"
--ScreenLoading.LoadCtrl[7] = "Logic.UI.UICtrls.Common.UI_LoadingSevenCtrl"
--ScreenLoading.LoadCtrl[8] = "Logic.UI.UICtrls.Common.UI_LoadingEightCtrl"

---@type UI_LoadingOneCtrl
ScreenLoading.loadingOne = nil
---@type UI_LoadingTwoCtrl
ScreenLoading.loadingTwo = nil

--打开载入界面
function ScreenLoading.OpenLoadingView(callback)
    ScreenBlocker.SetScreenBlock(true,"OpenScreenLoading")
    --Logger.LogError("OpenLoadingView>>>")
    ScreenLoading.onRandomLoading(callback)

    local appTab = {}
    appTab.key = "OpenScreenLoading"
    appTab.value = os.time()
    SDKProxy.sdkAppDump:OnSetAppDumpBind(appTab)
end

--关闭载入界面
function ScreenLoading.CloseLoadingView(callback)
    EventManager:BroadEvent(EventTypeEnum.Event_AppDump_UnBind,self,"CloseScreenLoading")
    local performData = UICtrlManager.RevokeActionDefault
    UICtrlManager.UILoading:RevokeTop(function()
        ScreenBlocker.SetScreenBlock(false,"OpenScreenLoading")
        InvokeSafely(callback)
        Me.BroadTaskEvent(EventConditioner.ConditionType_Battle_OnDIYEvent,EventConditioner.DIYEvent.LoadingUIFinish)
    end ,performData)
end

---@return number
function ScreenLoading.GetPreRandomLoading()
    return ScreenLoading.playIndex
end
function ScreenLoading.SetPreRandomLoading(pPlayIndex)
    --ScreenLoading.playIndex = pPlayIndex
end
function ScreenLoading.PreRandomLoading() --预先随机
    local maxRandom = #ScreenLoading.LoadCtrl
    local playIndex = RandomOp.Random(1,maxRandom)
    ScreenLoading.playIndex = playIndex
    return playIndex
end

--随机播放loading界面
function ScreenLoading.onRandomLoading(callback)
    local playIndex = 1
    if ScreenLoading.playIndex ~= nil then
        playIndex = ScreenLoading.playIndex
    else
        local maxRandom = #ScreenLoading.LoadCtrl
        playIndex = RandomOp.Random(1,maxRandom)
    end
    ScreenLoading.OnLoadIndex(playIndex,callback)

end

function ScreenLoading.OnLoadIndex(playIndex,callback)
    if ScreenLoading.LoadCtrl[playIndex] == nil then
        playIndex = 1
    end
    ---@type UI_LoadingOneCtrl
    local ctrl = (require(ScreenLoading.LoadCtrl[playIndex]).Create())
    UICtrlManager.UILoading:Perform(ctrl, function()
        InvokeSafely(callback)
    end, UICtrlManager.PerformActionDefault)
end

function ScreenLoading.OpenPvpLoadingView( PFormationItem , EFormationItem , pDMEnemySunmmyInfo , pDMPlayerSunmmyInfo,callback)
    -- Logger.LogError("OpenLoadingView")
    ---@type UI_PVP_Ladder_LoadingCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.pvp.PVPLadder.UI_PVP_Ladder_LoadingCtrl").Create())
    uiCtrlBase:SetData(PFormationItem , EFormationItem , pDMEnemySunmmyInfo , pDMPlayerSunmmyInfo)
    local performData = UICtrlManager.PerformActionDefault
    UICtrlManager.UILoading:Perform(uiCtrlBase,callback,performData)
end
--关闭载入界面
function ScreenLoading.ClosePvpLoadingView(callback)
    EventManager:BroadEvent(EventTypeEnum.Event_AppDump_UnBind,self,"CloseLoadingView")

    local performData = UICtrlManager.RevokeActionDefault
    UICtrlManager.UILoading:RevokeTop(callback,performData)
end

