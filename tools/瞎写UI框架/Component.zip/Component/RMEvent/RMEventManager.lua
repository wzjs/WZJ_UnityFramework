---@class RMEventManager
RMEventManager = class("RMEventManager")
---@field _AllEvents RMEvent[]
function RMEventManager:ctor()
    ---@type RMEvent[]
    self._AllEvents = {}
    self._EventTriggerManager = RMEventTriggerManager.New()
    ---@return RMEvent
    self._TriggerEvent = nil
end

function RMEventManager:BroadEvent(pEventType,pParam1,pParam2,pParam3)
    --Logger.LogInfo("RMEventManager BroadEvent pEventType is "..pEventType.."pParam1 is : "..pParam1.."pParam2 is : "..pParam2.."pParam3 is :"..pParam3)
    self._EventTriggerManager:BroadEvent(pEventType,pParam1,pParam2,pParam3)
    if pEventType == EventConditioner.ConditionType_OnGetForeground then
        --Logger.LogInfo("ConditionType_OnGetForeground pParam1"..pParam1.."pParam2"..pParam2.."pParam3"..pParam3)
        self:RunObjectByMainAndSubId(pParam1,pParam2,pParam3)
    end
    self:RunAllTriggerEvent()
end

function RMEventManager:RunObjectByMainAndSubId(pMainId,pSubId,pParam3)
    if pMainId ~= nil then
        for k,v in pairs(self._AllEvents) do
            if v:UIPositionMatch(pMainId,pSubId,pParam3) then
                v:StartRunObjectEvent()
            end
        end
    end
end

function RMEventManager:RunObject(pKeyWord)
    --Logger.LogInfo("RMEventManager RunObject pKeyWord is : "..pKeyWord)
    local mainId,subId = DMFuncModelType.GetFuncModelByStringKey(pKeyWord)
    self:RunObjectByMainAndSubId(mainId,subId)
end
---@return RMEvent
function RMEventManager:GetRuningEvent()
    return self._TriggerEvent
end
function RMEventManager:RunAllTriggerEvent()
    if  self._TriggerEvent ~= nil then return end
    self._TriggerEvent = self:GetFirstTriggerEvent()
    if self._TriggerEvent ~= nil then
        RMEventOp.OpenStoryDialog(self._TriggerEvent)
    end
end
---@return RMEvent
function RMEventManager:GetFirstTriggerEvent()
    local rmTrigger = self._EventTriggerManager:GetFirstTrigger()
    if rmTrigger ~= nil then
        local eventId = rmTrigger:GetEventId()
        return self:GetRMEvent(eventId)
    end
    return nil
end

---@param pEventId number
function RMEventManager:OnEventFinish(pEventId,pSelectIndex,pCallBack)
    Logger.LogInfo("RMEventManager OnEventFinish pEventId is:   "..pEventId)
    local pRMEvent = self:GetRMEvent(pEventId)
    if pRMEvent ~= nil then
        local triggerId = pRMEvent:GetTriggerId()
        Logger.LogInfo("RMEventManager OnEventFinish triggerId is:   "..triggerId)
        if triggerId > 0 then self._EventTriggerManager:OnTriggerFinish(triggerId) end
        pRMEvent:OnFinish(pSelectIndex,function ()
            self._TriggerEvent = nil
            InvokeSafely(pCallBack)
            Me.BroadTaskEvent(EventConditioner.ConditionType_OnEventFinish,pEventId)
            self:RunAllTriggerEvent()
        end)
    else
        self._TriggerEvent = nil
        InvokeSafely(pCallBack)
        self:RunAllTriggerEvent()
    end
end

---@param pEventId number
function RMEventManager:RemoveEvent(pEventId)
    local rmEvent = self:GetRMEvent(pEventId)
    if rmEvent ~= nil then
        rmEvent:Clear()
        self._AllEvents[pEventId] = nil
    end
end

---@return RMEvent
function RMEventManager:GetRMEvent(pEventId)
    return  self._AllEvents[pEventId]
end
---@return RMEvent
function RMEventManager:AddRMEvent(pEventId)
    local template = Redmoon.Project.Config.EventTemplateManager.getInstance():GetItemTemplate(pEventId)
    if template ~= nil then
        local rmEvent = RMEvent.New()
        local eventId = template.Id
        rmEvent:SynchConf(eventId,template)
        self._AllEvents[eventId] = rmEvent
        local rmEventTrigger = rmEvent:GetRMEventTrigger()
        self._EventTriggerManager:AddEventTrigger(rmEventTrigger)
        if UICtrlManager.UILayer:GetRestoreCtrlsCount() < 1 then
            if Me == nil then return end
            local ctrlBase = UICtrlManager.UILayer:GetTopCtrl()
            if ctrlBase ~= nil then
                local mainId,subId = DMFuncModelType.GetFuncModelByStringKey(self._Keyword)
                self:RunObjectByMainAndSubId(mainId,subId,ctrlBase:CtrlEventKey())
            end
        end
        return rmEvent
    else
        Logger.LogInfo("RMEventManager AddRMEvent EventTemplateManager is nil plz check eventId is :"..pEventId)
    end
    return nil
end

  