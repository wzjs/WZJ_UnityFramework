UICtrlUtility = {}

local showLog = false
UICtrlUtility.Logger = Logger.Create("Controller")

---@param message string
function UICtrlUtility.LogInfo(message)
    if showLog then
        UICtrlUtility.Logger:LogEx(message)
    end
end

---@param message string
function UICtrlUtility.LogError(message)
    --UICtrlUtility.Logger:LogErrorEx(message)
end

---@param list System.List
---@return number
function UICtrlUtility.CalculateDepth(list)
    local curPanelDepth = 0
    if list:getCount() > 0 then
        for i=0, list:getCount()-1 do
            curPanelDepth = curPanelDepth + UIConst.DepthDelta
        end
    end
    return curPanelDepth
end

---@param list System.List
---@return number
function UICtrlUtility.NewCalculateDepth(list)
    local curPanelDepth = 0
    if #list > 0 then
        for i=1,#list do
            curPanelDepth = curPanelDepth + UIConst.DepthDelta
        end
    end
    return curPanelDepth
end
