---@class RMEventConditioner
RMEventConditioner = class("RMEventConditioner")

function RMEventConditioner.Created(pConditionIndex,pParam1,pParam2,pParam3,pNeedListener)
    --Logger.LogError("RMEventConditioner Created pConditionIndex is： "..pConditionIndex.."pParam1 is："..pParam1.."pParam2 is："..pParam2.."pParam3 is："..pParam3.."pNeedListener is :"..pNeedListener)
    local conditioner = RMEventConditioner.New()
    conditioner._ConditionType = EventConditioner.ConditionTypes[pConditionIndex]
    conditioner._Param1 = pParam1
    conditioner._Param2 = pParam2
    conditioner._Param3 = pParam3
    conditioner._NeedListener = pNeedListener == nil and true or pNeedListener
    return conditioner
end

function RMEventConditioner:ctor()
    self._ConditionType = EventConditioner.ConditionTypes[0]
    self._Param1 = 0
    self._Param2 = 0
    self._Param3 = 0
    self._NeedListener = true
    self._IsPass = false
end
---@return number
function RMEventConditioner:GetParam1()
    return  self._Param1
end
---@return number
function RMEventConditioner:GetParam2()
    return  self._Param2
end
---@return number
function RMEventConditioner:GetParam3()
    return  self._Param3
end
---@return string
function RMEventConditioner:ConditionType()
    return self._ConditionType
end
---@return boolean
function RMEventConditioner:IsBattleCondition()
    return self._ConditionType == EventConditioner.ConditionTypes[11] or
            self._ConditionType == EventConditioner.ConditionTypes[13] or
            self._ConditionType == EventConditioner.ConditionTypes[14]
end
---@return boolean
function RMEventConditioner:IsNeedListener()
   return   self._NeedListener
end
---@param pIsPass boolean
function RMEventConditioner:SetIsPass(pIsPass)
    self._IsPass = pIsPass
end
---@return boolean
function RMEventConditioner:GetIsPass()
    if self._ConditionType == EventConditioner.ConditionType_OnGuideFinish then
        local isFinishGuide = Me.GetDMGuildeManager():IsFinishGuide(self._Param1)
        --Logger.LogError("RMEventConditioner ConditionType_OnGuideFinish isFinishGuide is ",isFinishGuide)
        --Logger.LogError("RMEventConditioner ConditionType_OnGuideFinish self._IsPass is ",self._IsPass)
        return isFinishGuide or self._IsPass
    elseif self._ConditionType == EventConditioner.ConditionType_GuideNotFinish then
        local isFinishGuide = Me.GetDMGuildeManager():IsFinishGuide(self._Param1)
        return not isFinishGuide
    elseif self._ConditionType == EventConditioner.ConditionType_LordWareEquip then
        ---@type DMLord
        local dmLord = Me.GetPlayerAllInfo():GetPlayerBag():GetLordBag():GetLordById(DMGuideOp.CurLordId)
        if dmLord ~= nil and dmLord:GetEquipByPos(self._Param1) ~= nil then
            return true
        end
        return self._IsPass
    elseif self._ConditionType == EventConditioner.ConditionType_OnGetForeground then
        local ctrlBase = UICtrlManager.UILayer:GetTopCtrl()
        if ctrlBase ~= nil then
            local mainId,subId = DMFuncModelType.GetFuncModelByStringKey(ctrlBase:GetKeyWord())
            local ctrlEventKey = ctrlBase:CtrlEventKey()
            --Logger.LogError("mainId"..mainId.."subId"..subId.."ctrlEventKey"..ctrlEventKey)
            if mainId == self._Param1 and subId == self._Param2 then
                if self._Param3 ~= 0  then
                    if  self._Param3 == ctrlEventKey then
                        return true
                    end
                else
                    return true
                end
            end
        end
        return self._IsPass
    end
    if self:IsNeedListener() == false then
        if self._ConditionType == EventConditioner.ConditionType_OwnThingGreaterOrEqual then
            --Logger.LogError("RMEventConditioner ConditionType_OwnThingGreaterOrEqual Param1 is :"..self._Param1.."Param2 is :"..self._Param2.."Param3 is :"..self._Param3)
            local count = Me.GetPlayerAllInfo():GetPlayerBag():GetDMThingCount(self._Param1,self._Param2)
            --Logger.LogError("count"..count)
            return count >= self._Param3
        elseif self._ConditionType == EventConditioner.ConditionType_OwnThingLess then
            local count = Me.GetItemCount(self._Param2)
            return count < self._Param3
        elseif self._ConditionType == EventConditioner.ConditionType_StatgeIsPass then
            --Logger.LogError("RMEventConditioner ConditionType_StatgeIsPass Param1 is :"..self._Param1.."Param2 is :"..self._Param2.."Param3 is :"..self._Param3)
            local type = DMDuplicate.DuplicateTypes[self._Param1]
            local dmDuplicate = Me.GetPlayerAllInfo():GetDMMap():GetDMDuplicate(type,self._Param2)
            if type == DMDuplicate.Type_Challenge then
                local chapterId = dmDuplicate:GetChapterId()
                local dmChapter = Me.GetPlayerAllInfo():GetDMMap():GetDMChapter(chapterId)
                local maxFloor = dmChapter:GetMazeLayer()
                Logger.LogError("maxFloor"..maxFloor)
                return maxFloor >= 9
            end
            return dmDuplicate ~= nil and (dmDuplicate:Score() >= self._Param3)
        elseif self._ConditionType == EventConditioner.ConditionType_StatgeIsNotPass then
            local type = DMDuplicate.DuplicateTypes[self._Param1]
            local dmDuplicate = Me.GetPlayerAllInfo():GetDMMap():GetDMDuplicate(type,self._Param2)
            if type == DMDuplicate.Type_Challenge then
                local chapterId = dmDuplicate:GetChapterId()
                local dmChapter = Me.GetPlayerAllInfo():GetDMMap():GetDMChapter(chapterId)
                local maxFloor = dmChapter:GetMazeLayer()
                Logger.LogError("maxFloor"..maxFloor)
                return maxFloor < 9
            end
            return dmDuplicate ~= nil and (dmDuplicate:Score() < 1)
        elseif self._ConditionType == EventConditioner.ConditionType_ChapterIsPass then
            local dmChapter = Me.GetPlayerAllInfo():GetDMMap():GetDMChapter(self._Param1)
            local duplicateId ,pass = dmChapter:GetChapterState()
            --Logger.LogError("duplicateId"..duplicateId)
            --Logger.LogError("pass"..pass)
            return pass
        elseif self._ConditionType == EventConditioner.ConditionType_OnEventFinish then
            local isFinish = Me.IsEventFinish(self._Param1)
            return isFinish
        elseif self._ConditionType == EventConditioner.ConditionType_IsHaveFreeHero then
            local isHaveFreeHero = Me.GetPlayerAllInfo():GetPlayerBag():GetHeroBag():IsHaveFreeHero()
            --Logger.LogError("RMEventConditioner ConditionType_IsHaveFreeHero isHaveFreeHero",isHaveFreeHero)
            return isHaveFreeHero
        elseif self._ConditionType == EventConditioner.ConditionType_BuildingLevel then
            ---@type DMTownBuilding
            local dmTownBuilding = Me.GetPlayerAllInfo():GetDMTown():GetTownBuilding(self._Param1)
            return dmTownBuilding ~= nil and dmTownBuilding:GetLevel() >= self._Param2
        elseif self._ConditionType == EventConditioner.ConditionType_Battle_OnCardCanCombine then
            if BattleMgr ~= nil then
                 return  BattleMgr.FieldData.EquipBag:IsCanCompound()
            end
            return false
        elseif self._ConditionType == EventConditioner.ConditionType_OnBattle_CanSkill then
            if BattleMgr ~= nil then
                return  BattleMgr.HeroManager:HaveFillAngerHero(self:GetParam1())
            end
            return false
        elseif self._ConditionType == EventConditioner.ConditionType_MapChapterIslock then
            local lockChapterId = Me.GetDMPlayerPrefs():GetPlayerPrefInt(DMPlayerPrefs.UIMapCurChapter,1)
            return lockChapterId < self._Param1
        end
    end
    return self._IsPass
end

function RMEventConditioner:OnGetEventListener(pConditionType,pParam1,pParam2,pParam3)
    --Logger.LogError("pConditionType :"..pConditionType.."pParam1 :"..pParam1.."pParam2 :"..pParam2.."pParam3 :"..pParam3)
    if pConditionType ~= self._ConditionType then return false end
    local func = EventConditioner.Funcs[pConditionType]
    if func ~= nil then
       local result = func(pParam1,self._Param1,pParam2,self._Param2,pParam3,self._Param3)
        if result ~= nil then
            return result
        else
            return false
        end
    else
        return false
    end
end