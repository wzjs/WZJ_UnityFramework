StateMachineStateBase = class ("StateMachineStateBase")
---@class StateMachineStateBase
---@field private Diagram StateMachineDiagramBase

function StateMachineStateBase:ctor( obj )

end

---@param parentDiagran StateMachineDiagramBase
function StateMachineStateBase:_InitStateMachine(parentDiagran)
    self.Diagram = parentDiagran
end

---@param eventName string
function StateMachineStateBase:CallEvent(eventName)
    self.Diagram:Event(eventName)
end

function StateMachineStateBase:SetVariable(var_name, val)
    self.Diagram[var_name] = val
end

function StateMachineStateBase:GetVariable(var_name, val)
    return self.Diagram[var_name]
end

function StateMachineStateBase:OnEnter()
end

function StateMachineStateBase:OnExit()
end

function StateMachineStateBase:OnUpdate()

end

return StateMachineStateBase