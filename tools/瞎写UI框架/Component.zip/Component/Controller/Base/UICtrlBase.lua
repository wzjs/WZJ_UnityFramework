
---@field public _State number UIConst.CtrlState 内部状态机
---@field public _PrevCtrlState  number UIConst.PrevState 前置Control状态
---@field public _Keyword boolean 是否使用屏幕遮照
---@field public _Data any 数据
---@field public _Panel UnityEngine.GameObject 面板对象
---@field public _UIEventPackager RmUIEventPackager UI事件
---
---@field private _PanelDepthSeaLevel number
---@field private _Locked boolean
---@field private _PrevCtrl UICtrlBase
---@field private _NextCtrl UICtrlBase
---@field private _IsPrePrepareSuccess boolean

---@class UICtrlBase
UICtrlBase = class("UICtrlBase")

--[[ UICtrl life cycle
1. EnterScreen 流程
                                                                                                                     DoGetForeground()
                          PrePrepare(cb)            LoadResource(cb)            SetPanelData()           PostPrepare(cb)   |                EnterScreen(cb)
  Created -----> PrePrepare -----------> LoadResource -------------> SetPanelData -----------> PostPrepare -----------------+---> ReadyEnter ------------> OnScreen
         Dispose()                                   ReleaseResource()         ClearPanelData()

2. PrevState = UIConst.PrevState.Active 方式进入到后台
          DoGetBackground()
  OnScreen ----------------> OnScreen

3.PrevState = UIConst.PrevState.Disable 方式进入到后台
            DoGetBackground()
  ReadyEnter <------------ OnScreen
             ExitScreen(cb)

4. PrevState = UIConst.PrevState.Destroy 方式进入到后台
                                             ClearPanelData()                                                     DoGetBackground()
        | <---------------------  | <---------------------   ExitScreen(cb)  ----------------------------------------> |
   LoadResource <------------- SetPanelData <----------- PostPrepare <-------------------- ReadyEnter <------------ OnScreen


设计初衷:
1. PrePrepare阶段: 处理界面是否能打开的阶段，包含逻辑举例: 网络请求是否成功，逻辑判定是否可开启该界面
2. LoadResource阶段: 网络请求资源阶段
3. SetPanelData: 设置面板数据事件
4. PostPrepare阶段: 处理生成完面板之后的逻辑，举例：网络请求图片资源，异步加载资源
5. DoGetForeground: 切至前台事件，每次切换到前台都会调用该方法，建议刷新数据操作在此方法内
6. DoGetBackground: 切至前台事件，每次切换到前台都会调用该方法，建议刷新数据操作在此方法内
]]--

function UICtrlBase.Create()
    return UICtrlBase.New()
end

function UICtrlBase:ctor()
    -- public field
    self._Keyword = "Unknown"
    self._State = UIConst.CtrlState.Created
    self._Data = nil
    self._PrevCtrlStateE = UIConst.PrevState.Active
    self._Panel = nil
    -- internal field
    self._PanelDepthSeaLevel = 0
    self._Locked = false
    self._PrevCtrl = nil
    self._NextCtrl = nil
    self._IsPrePrepareSuccess = nil -- nil:未判定  true:成功 false:失败

end
---@return number
function UICtrlBase:CtrlEventKey()
    return nil
end
---@return string
function UICtrlBase:GetKeyWord()
    return self._Keyword
end
---@param callback fun()
function UICtrlBase:LoadResource( callback )
    --ThrowException("Not implement LoadResource method.")
    callback()
end

---@param callback fun(isSuccess:boolean)
function UICtrlBase:PrePrepare( callback )
    callback( true)
end

---@param callback fun()
function UICtrlBase:PostPrepare(callback)
    callback()
end

---@param data any
function UICtrlBase:SetPanelData(data)

end

function UICtrlBase:ClearPanelData()
    if  self._UIEventPackager ~= nil then
        --Logger.LogError("ClearPanelData")
        --self._UIEventPackager:CleanEventMap()
        --self._UIEventPackager = nil
    end
end

function UICtrlBase:ReleaseResource()
end

function UICtrlBase:DoDispose()
    if LuaHelper.GetGamePlatform() == "Editor" then
        local packet = package.loaded
        for k,_ in pairs(packet) do
            if string.match(k,self._Keyword) then
                packet[k] = nil
            end
        end
    end
end

---@param callback fun()
---@param playEffect boolean
function UICtrlBase:EnterScreen(callback, playEffect)
    callback()
end

---@param callback fun()
---@param playEffect boolean
function UICtrlBase:ExitScreen(callback, playEffect)
    callback()
end

function UICtrlBase:ReadyBackground()

end

function UICtrlBase:OnGetForeground()
    --Logger.LogError("OnGetForeground self._Keyword"..self._Keyword)
    --EventManager:BroadEvent(EventTypeEnum.Event_OnGetForeground,self,self._Keyword)
    UICtrlManager.BroadTaskEvent(self._Keyword)
end

function UICtrlBase:OnGetBackground()
    --Logger.LogError("self._Keyword"..self._Keyword)
    EventManager:BroadEvent(EventTypeEnum.Event_OnGetBackground,self,self._Keyword)
end

---@return UnityEngine.GameObject
function UICtrlBase:GetViewObject()
    --IceUIPanelCollector
    local go = UIPanelCollector.TryGetGameObject(self._Keyword)
    if GameObjectExtension.IsNil(go) then
        return nil
    end
    return go
end

---@return any
function UICtrlBase:GetScript()
    if GameObjectExtension.IsNil(self._Panel) then return nil end
    local behaviour = self._Panel:GetComponent("RmLuaBehaviour")
    behaviour:Awake()
    return behaviour.LuaTableIns
end

function UICtrlBase:SetPrevCtrlState(pPrevCtrlStateE)
    --Logger.LogError("SetPrevCtrlState  _Keyword is  :"..self._Keyword)
    --Logger.LogError("SetPrevCtrlState pPrevCtrlStateE is :"..pPrevCtrlStateE)
    self._PrevCtrlStateE = pPrevCtrlStateE
end
function UICtrlBase:GetPrevCtrlState()
    return self._PrevCtrlStateE
end
function UICtrlBase:GetState()
    return self._State
end
function UICtrlBase:IsStateActive()
    return self._State == UIConst.CtrlState.OnScreen
end

function UICtrlBase:IsStateDisable()
    return self._State < UIConst.CtrlState.OnScreen and self._State >= UIConst.CtrlState.ReadyEnter
end

function UICtrlBase:IsStateDestroy()
    return self._State < UIConst.CtrlState.SetPanelData and self._State >= UIConst.CtrlState.LoadResource
end

return UICtrlBase