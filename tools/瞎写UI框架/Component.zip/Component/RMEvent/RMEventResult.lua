---@class RMEventResult
RMEventResult = class("RMEventResult")

RMEventResult.Type_None = "None" -- 无
RMEventResult.Type_GetNewTask = "GetNewTask"--推送任务 任务id
RMEventResult.Type_FinishTask = "FinishTask"-- 交付任务 任务id 0:标记任务结束，玩家可去酒馆领奖 --1:直接领奖，任务奖励直接发放
RMEventResult.Type_ShowHideStage = "ShowHideStage"-- 出现隐藏关卡 隐藏关卡id
RMEventResult.Type_GetNewItem = "GetNewItem" -- 获得物品 物品类型 物品id 物品数量
RMEventResult.Type_DeteleItem = "DeteleItem"-- 提交（失去）物品 物品类型 物品id 物品数量
RMEventResult.Type_AddMonsterBuff = "AddMonsterBuff"-- 给战中怪物增加buff buff id 怪物id：指定魔物 1：表示所有怪物
RMEventResult.Type_AddHeroBuff = "AddHeroBuff"-- 给战中我方魔物增加buff buff id 魔物id：指定魔物 1:表示所有魔物
RMEventResult.Type_ExchangeMonster = "ExchangeMonster"-- 替换怪物（和trigger13,14共同使用） 关卡id -1
RMEventResult.Type_DeteleEvent = "DeteleEvent"--删除事件 事件id
RMEventResult.Type_GetNewEvent = "GetNewEvent" -- 增加事件 事件id
RMEventResult.Type_ExtEvent = "ExtEvent"-- 特殊事件 1：树叶开始飘叶子2：xxxxx3：xxxxx


RMEventResult.Types = {}
RMEventResult.Types[0] = RMEventResult.Type_None
RMEventResult.Types[1] = RMEventResult.Type_GetNewTask
RMEventResult.Types[2] = RMEventResult.Type_FinishTask
RMEventResult.Types[3] = RMEventResult.Type_DeteleItem
RMEventResult.Types[4] = RMEventResult.Type_AddMonsterBuff
RMEventResult.Types[5] = RMEventResult.Type_AddHeroBuff
RMEventResult.Types[6] = RMEventResult.Type_ExchangeMonster
RMEventResult.Types[7] = RMEventResult.Type_DeteleEvent
RMEventResult.Types[8] = RMEventResult.Type_GetNewEvent
RMEventResult.Types[9] = RMEventResult.Type_ExtEvent
RMEventResult.Types[10] = RMEventResult.Type_GetNewItem

function RMEventResult.Create(pEventId,pGroup,pType,pParam1,pParam2,pParam3)
    local rmEventResult = RMEventResult.New()
    --Logger.LogError("RMEventResult Create ..pEventId is :"..pEventId.."pGroup is :"..pGroup.."pType is "..pType)
    rmEventResult._EventId = pEventId
    rmEventResult._Group = pGroup
    rmEventResult._Type = RMEventResult.Types[pType]
    rmEventResult._Param1 = pParam1
    rmEventResult._Param2 = pParam2
    rmEventResult._Param3 = pParam3
    return rmEventResult
end
---@return boolean
function RMEventResult:IsSelectResult(pSelectIndex)
    return self._Group == 0 or self._Group == pSelectIndex
end
function RMEventResult:ctor()
    self._Type = RMEventResult.Types[0]
    self._Group = 0
    self._EventId = 0
    self._Param1 = 0
    self._Param2 = 0
    self._Param3 = 0
end
function RMEventResult:RunEventResult(pCallBack,pIsShow)
    Logger.LogInfo("RMEventResult RunEventResult _Type is : "..self._Type)
    if self._Type == RMEventResult.Type_GetNewTask then
        PlayerEventOp.AddNewTask(self._Param1,pCallBack)
    elseif self._Type == RMEventResult.Type_FinishTask then
        PlayerEventOp.FinishTask(self._Param1,self._Param2,pCallBack)
    elseif self._Type  == RMEventResult.Type_DeteleItem then
        PlayerEventOp.SendPickMessage("Event",self._EventId,pCallBack,pIsShow)
    elseif self._Type  == RMEventResult.Type_DeteleEvent then
        PlayerEventOp.DeleteEvent(self._Param1,pCallBack)
    elseif self._Type  == RMEventResult.Type_GetNewEvent then
        PlayerEventOp.AddEvent(self._Param1,pCallBack)
    elseif self._Type  == RMEventResult.Type_GetNewItem then
        --PlayerEventOp.SendPickMessage("Event",self._EventId,pCallBack,pIsShow)
        InvokeSafely(pCallBack)
    else
        InvokeSafely(pCallBack)
    end
end
