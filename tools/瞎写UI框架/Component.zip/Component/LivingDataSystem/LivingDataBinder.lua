---@class LivingDataBinder
LivingDataBinder = class("LivingDataBinder")

function LivingDataBinder.Created(pEventKey)
    return  LivingDataBinder.New(pEventKey)
end

local function private_AddLivingDataListener(self)
    EventManager:RegistEvent(self.__ListenerEventKey,self.OnDataChange,self)
end

local function local_RemoveLivingDataListener(self)
    EventManager:RemoveEvent(self.__ListenerEventKey,self.OnDataChange,self)
end

function LivingDataBinder:ctor(pEventKey)
    self.__ListenerEventKey = pEventKey
    self.__EventRouter = EventRouter.Create(self.__ListenerEventKey)
    private_AddLivingDataListener(self)
end

function LivingDataBinder:OnDataChange(pValue)
    self.__EventRouter:BroadEvent( self.__BindEventKey,self,pValue)
end
---@param pEventKey string
function LivingDataBinder:BindLivingData(pEventKey,pFnc,pObject)
    self.__BindEventKey = pEventKey
    self:RegistEvent(pFnc, pObject)
end
---@param pFnc fun()
function LivingDataBinder:RegistEvent(pFnc,pObject)
    self.__EventRouter:RegistEvent(self.__BindEventKey,pFnc,pObject)
end
---@param pFnc fun()
function LivingDataBinder:RemoveEvent(pEventKey,pFnc,pObject)
    self.__EventRouter:RemoveEvent(pEventKey,pFnc,pObject)
end

function LivingDataBinder:Clear()
    local_RemoveLivingDataListener(self)
    self.__EventRouter:ClearAllRegist()
end




