local super = require "Component/Viewer/RmUIBase"
require("Component/Viewer/UIComponent/ListViewRoot")
TabViewer=class("TabViewer",super)
---@class TabViewer:RmUIBase
---@field private E_OnIndexChanged fun(number, number) Index改变事件
---@field private number E_Default fun(number) Index默认值

function TabViewer.Create(o)
    -- body
    return TabViewer.New(o)
end

function TabViewer:ctor(obj)
    -- body
    TabViewer.super.ctor(self,obj)
	self.tabIndex = 1;
	self.E_OnIndexChanged = nil
	self.E_Default = nil
end

function TabViewer:Awake()
    -- body
	---@type UnityEngine.GameObject
	self.gobtn_tab = BehaviourUtility.GetGameObject(self, "btn_tab")
	self.cautionBtn = BehaviourUtility.GetComponent(self, "cationBtn", "UIEventListener")
	---@type UIEventListener
	---self.eltab_unit1 = BehaviourUtility.GetComponent(self, "tab1", "UIEventListener")
	---@type UIEventListener
	---self.eltab_unit2 = BehaviourUtility.GetComponent(self, "tab2", "UIEventListener")
	---@type UIEventListener
	---self.eltab_unit3 = BehaviourUtility.GetComponent(self, "tab3", "UIEventListener")
	---@type UIEventListener
	---self.eltab_unit4 = BehaviourUtility.GetComponent(self, "tab4", "UIEventListener")
	for i=1,10 do
		self["eltab_unit"..i] = BehaviourUtility.GetComponent(self, "tab" .. i, "UIEventListener", false)
		if self["eltab_unit"..i] == nil then
			break
		end
	end
	self.Count = i-1

	---@type UnityEngine.GameObject
	self.goUI_panel = BehaviourUtility.GetGameObject(self, "UI_panel")
	---@type UnityEngine.GameObject
	self.gopanel_root = BehaviourUtility.GetGameObject(self, "panel_root")

	---@type UnityEngine.GameObject
	--self.panel_unit1 = BehaviourUtility.GetGameObject(self, "panel1")
	---@type UnityEngine.GameObject
	--self.panel_unit2 = BehaviourUtility.GetGameObject(self, "panel2")
	---@type UnityEngine.GameObject
	--self.panel_unit3 = BehaviourUtility.GetGameObject(self, "panel3")
	---@type UnityEngine.GameObject
	--self.panel_unit4 = BehaviourUtility.GetGameObject(self, "panel4")
	for i=1,10 do
		self["panel_unit"..i] = BehaviourUtility.GetGameObject(self, "panel" .. i, false)
		if self["panel_unit"..i] == nil then
			break
		end
	end

end
function TabViewer:DoPrepare(  )
	local btn_group = BehaviourUtility.GetComponentInGameObject(self.gobtn_tab,"IceUIBtnGroup",false)
	btn_group.OnLuaButtonSelected_Index = function(OldIndex,NewIndex)
		self:SetType(NewIndex+1)
		InvokeSafely(self.E_OnIndexChanged, OldIndex, NewIndex)
	end

	InvokeSafely(self.E_Default,self.tabIndex)
	self:SetType(self.tabIndex)
	self.cautionBtn.onClick = function()
		local obj =  UnityEngine.Resources.Load("MonsterPrefab/ListViewRoot")
		local go = UnityEngine.GameObject.Instantiate(obj)
		GameObjectExtension.SetParent(go,self.gameObject.transform.parent, true)
		--SetTransParentLocalZero(go.transform, self.gameObject.transform)
		self.gameObject:SetActive(false)
		local ListView = BehaviourUtility.GetComponentInGameObject(go,"RmLuaBehaviour").LuaTableIns
		for i = 1,10 do
			ListView:AddUnit()
		end
		--ConfirmPanel:ShowConfirmPanel("内容")
		Logger.Log("ListView")
	end
end

function TabViewer:DoShowOffScreen( )
    -- body
end

function TabViewer:DoShowOnScreen( )
    -- body
end

function TabViewer:PlayEnterEffects( callBack )
    callBack()
end

function TabViewer:PlayExitEffects( callBack )
    -- body
    callBack()
end

function TabViewer:DoDispose(  )
    -- body
end

function TabViewer:DoDestory()
end

function TabViewer:SetType(index)
	Logger.Log("index = "..index)
	self.tabIndex = index
	---@type IceUIBtnGroup
	local btnGroup = BehaviourUtility.GetComponentInGameObject(self.gobtn_tab,"IceUIBtnGroup",false)
	btnGroup:SelectButton(index-1,false)
	for i =1,10 do
		if self["panel_unit"..i] == nil then
		else
			if i ==index then
				self["panel_unit"..i].gameObject:SetActive(true)
			else
				self["panel_unit"..i].gameObject:SetActive(false)
			end

		end
	end
end

return TabViewer