ScreenDebugMessage = {}
---@class ScreenDebugMessage 屏幕Debug信息方法
function ScreenDebugMessage.Info(message)
    -- TODO.
end

function ScreenDebugMessage.Error(message)
    -- TODO.
end