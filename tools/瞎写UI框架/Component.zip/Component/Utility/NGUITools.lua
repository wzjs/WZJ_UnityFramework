NGUITools = {}

---@public 调整Panel深度
---@param go UnityEngine.GameObject
---@param depth number
function NGUITools.PanelDepthAdd(go, depth)
    if go == nil then return end
    --Assert.GameObjectExist(go)
    local panels = go:GetComponentsInChildren(typeof(UIPanel), true)
    if #panels > 0 then
        for i= 0,  #panels - 1 do
            local panel = panels:get(i)
            panel.depth = panel.depth + depth
        end
    end
end
---@public 调整一个物体的为另外一个为物体为基准深度
---@param pGO UnityEngine.GameObject
---@param pParentGO UnityEngine.GameObject
function NGUITools.PanelDepthAddParentGO(pGO,pParentGO)
    if pParentGO ~= nil then
        ---@type UIPanel
        local panel = pParentGO:GetComponent("UIPanel")
        if panel ~= nil then
            NGUITools.PanelDepthAdd(pGO, panel.depth)
        end
    end
end
---@param pUIPanel UIPanel
---@param pOffsetX number
---@param pOffsetY number
function NGUITools.PanelMoveOffet(pUIPanel,pOffsetX,pOffsetY)
    local curPos = pUIPanel.gameObject.transform.localPosition
    local curX = curPos.x
    local curY = curPos.y
    local curOffet = pUIPanel.clipOffset
    local curOffsetX = curOffet.x
    local curOffsetY = curOffet.y
    local newPos = Vector3.New(curX + pOffsetX,curY - pOffsetY,0 )
    --Logger.LogError("newPos",newPos)
    pUIPanel.gameObject.transform.localPosition = newPos
    pUIPanel.clipOffset = Vector2.New(curOffsetX - pOffsetX,curOffsetY + pOffsetY )
end