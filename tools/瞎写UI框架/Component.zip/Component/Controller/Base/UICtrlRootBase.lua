local super = require("Component.Controller.Base.UICtrlBase")
---@class UICtrlRooBase:UICtrlBase
UICtrlRooBase = class ("UICtrlRooBase", super)
---@field protected _ResType string
---@field protected _ResName string
---@field protected _LoadOnDontUIRoot boolean

function UICtrlRooBase:ctor(...)
    UICtrlRooBase.super.ctor(self,...)
    --Logger.LogError("self._Keyword",self._Keyword)
    self._UIEventPackager = RmUIEventPackager.Created( self._Keyword) -- ui事件
end
---@param pEventKey string
---@param pEventAction fun()
function UICtrlRooBase:AddEvent(pEventKey,pEventAction)
    if self._UIEventPackager ~= nil and  pEventKey ~= nil and  pEventAction ~= nil then
        self._UIEventPackager:AddEvent(pEventKey,pEventAction)
    end
end
function UICtrlRooBase:OnResLoadFinish(go,callback)
    --Logger.Log("UICtrlRooBase LoadResource >>>3 : "..self._ResName)
    --Logger.LogError("UICtrlRooBase LoadResource >>>4")
    if GameObjectExtension.IsNil(go) then
        --Logger.LogError("UICtrlRooBase LoadResource >>>5")
        Logger.LogError("UICtrlBase:LoadResource failed, object not be found, ResType = " .. self._ResType .. ", ResName = " .. self._ResName)
        callback()
        return
    end
    --Logger.LogError("UICtrlRooBase LoadResource >>>6")
    ---@type UnityEngine.GameObject
    UIPanelCollector.RegistPanel(self._Keyword, go,self._LoadOnDontUIRoot)
    --Logger.Log("UICtrlRooBase LoadResource >>>3")
    self._Panel = go
    --- 检查资源
    local panel = go:GetComponent(typeof(UIPanel))
    --Logger.Log("UICtrlRooBase LoadResource >>>4")
    --Logger.LogError("UICtrlRooBase LoadResource >>>7")
    if panel == nil then
        UICtrlUtility.LogError("Ctrl: " .. self._Keyword .. " not contains UIPanel component, automatically add a panel")
        panel = go:AddComponent(typeof(UIPanel))
        --Logger.Log("UICtrlRooBase LoadResource >>>5")
    end
    local behaviour = go:GetComponent(typeof(RmLuaBehaviour))
    --Logger.Log("UICtrlRooBase LoadResource >>>6")
    if behaviour == nil then
        ThrowException("Ctrl: " .. self._Keyword .. " not contains RmLuaBehaviour component")
    end
    --Logger.LogError("UICtrlRooBase LoadResource >>>8")
    --Logger.Log("UICtrlRooBase LoadResource >>>7")
    behaviour:Awake()
    ---@type RmUIBase
    local luaTable = behaviour:GetLuaIns()
    --Logger.Log("UICtrlRooBase LoadResource >>>8")
    if luaTable ~= nil then
        --Logger.Log("UICtrlRooBase LoadResource >>>11")
        luaTable:Prepare()
        luaTable:LoadUIEventPackager(self._UIEventPackager)
        --Logger.Log("UICtrlRooBase LoadResource >>>12")
    end
    --Logger.Log("UICtrlRooBase LoadResource >>>10")
    --Logger.LogError("UICtrlRooBase LoadResource >>>9")
    callback()
end
---@param callback fun()
function UICtrlRooBase:LoadResource( callback )
    --Logger.Log("UICtrlRooBase LoadResource >>>1")
    --- 检查自己的指针
    if not GameObjectExtension.IsNil(self._Panel) then
        --Logger.Log("UICtrlRooBase LoadResource >>>2")
        --Logger.LogError("UICtrlRooBase LoadResource >>>2")
        UICtrlUtility.LogError("UICtrlBase._Panel is not a nil value, so skip LoadResource state.")
        callback()
        return
    end

    self.assetId = Utility.ResourceLoadAsync(self._ResType, self._ResName,function (go)
        --Logger.LogError("LoadResource _ResType is :"..self._ResType.."self._ResName is :"..self._ResName)
        self:OnResLoadFinish(go,callback)
    end)
end
function UICtrlRooBase:ReleaseResource()
    --Logger.LogError("UICtrlRooBase ReleaseResource >>>> ")

    if GameObjectExtension.IsNil(self._Panel) then
        --UICtrlUtility.LogError("Ctrl: " .. self._Keyword .. " Release resource occurred problems, self._Panel is nil, somebody else has been dispose it")
        return
    end
    --Logger.LogError("UICtrlRooBase ReleaseResource >>>> _ResTypeis : "..self._ResType.."self._ResName, is :"..self._ResName.."self._Panel"..self._Panel.name)
    UIPanelCollector.UnregistPanel(self._Keyword,self._LoadOnDontUIRoot)
    --Utility.ResourceDestroy(self._ResType,self._ResName,self._Panel)
    Utility.ResourceAssetById(self.assetId)
    self._Panel = nil
end


---@param callback fun()
---@param playEffect boolean
function UICtrlRooBase:EnterScreen(callback, playEffect)
    if self._Panel ~= nil then
        self._Panel:SetActive(true)
        local script = self:GetScript()
        script:EnterScreen(callback, playEffect)
    else
        InvokeSafely(callback)
    end
end
---@param callback fun()
---@param playEffect boolean
function UICtrlRooBase:ExitScreen(callback, playEffect)
    local script = self:GetScript()
    if script ~= nil then
        script:ExitScreen(function()
            self._Panel:SetActive(false)
            InvokeSafely(callback)
        end, playEffect)
    else
        InvokeSafely(callback)
    end
end

return UICtrlRooBase