UICtrlPolicyQueueOp = {}

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Revoke_Close(callback, uiCtrl, performData, policy)
    if uiCtrl == nil then
        InvokeSafely(callback)
        return
    end

    Assert.True(policy:Peek() == uiCtrl)
    uiCtrl:OnGetBackground()
    policy:Pop()
    UICtrlBaseOp.DestroyUICtrl(uiCtrl, performData._PlayExitEffect, function()
        --uiCtrl:ReleaseResource()
        InvokeSafely(callback)
    end)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform_InitAndOpen(callback, uiCtrl, performData, policy)
    uiCtrl._PanelDepthSeaLevel = policy:GetBaseDepth()
    UICtrlBaseOp.LoadResourceUICtrl(uiCtrl, function()
        NGUITools.PanelDepthAdd(uiCtrl._Panel, uiCtrl._PanelDepthSeaLevel )
        policy:Push(uiCtrl)
        UICtrlBaseOp.PostPrepareUICtrl(uiCtrl, function()
            uiCtrl:OnGetForeground()
            UICtrlBaseOp.EnterScreenUICtrl(uiCtrl, performData._PlayEnterEffect, callback)
        end)
    end,nil,performData)
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
local function Perform(callback, uiCtrl, performData, policy)
    local prevCtrl = policy:Peek()
    if prevCtrl ~= nil then
        Revoke_Close(function()
            Perform_InitAndOpen(callback, uiCtrl, performData, policy)
        end, prevCtrl, performData, policy)
    else
        Perform_InitAndOpen(callback, uiCtrl, performData, policy)
    end
end

---@param callback fun()
---@param uiCtrl UICtrlBase
---@param performData UICtrlPerformData
---@param policy UICtrlPolicyBase
function UICtrlPolicyQueueOp.Perform(callback, uiCtrl, performData, policy)
    Perform(callback, uiCtrl, performData, policy)
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformD
function UICtrlPolicyQueueOp.RevokeTop(callback, performData, policy)
    local prevCtrl = policy:Peek()
    Revoke_Close(callback, prevCtrl, performData, policy)
end