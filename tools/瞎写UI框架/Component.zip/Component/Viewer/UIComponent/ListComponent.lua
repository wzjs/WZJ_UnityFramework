local super = require "Component/Viewer/RmUIBase"

ListComponent =class("ListComponent",super)
---@class ListComponent:RmUIBase
---@field private E_OnClickListUnit fun( number) 点击list单元
function ListComponent.Create(o)
    -- body
    return ListComponent.New(o)
end

function ListComponent:ctor(obj)
    -- body
    ListComponent.super.ctor(self,obj)
    self.E_OnClickListUnit = null
end

function ListComponent:Awake()
    -- body
    self.clipper = BehaviourUtility.GetGameObject(self,"Clipper",false);
    self.drag = BehaviourUtility.GetGameObject(self,"drag",false);


end
function ListComponent:AddUnit(data)


end

function ListComponent:DoPrepare(  )
end

function ListComponent:DoShowOffScreen( )
    -- body
end

function ListComponent:DoShowOnScreen( )
    -- body
end

function ListComponent:PlayEnterEffects( callBack )
    callBack()
end

function ListComponent:PlayExitEffects( callBack )
    -- body
    callBack()
end

function ListComponent:DoDispose(  )
    -- body
end

function ListComponent:DoDestory()
end

return ListComponent