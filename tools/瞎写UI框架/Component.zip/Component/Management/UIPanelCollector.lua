
UIPanelCollector = class("UIPanelCollector")
---@type UnityEngine.GameObject[]
local entries = {}--System.List(System.Object)()
local nameMap = {}

local counter = 0
local combinStringKey = "|"
---@param pName string
---@return number
local function GetViewCountByName(pName)
    return nameMap[pName] ~= nil and nameMap[pName] or 0
end
---@return string
local function CombinViewName(pName,pCount)
    return pName..combinStringKey..pCount
end

---@param name string
---@return UnityEngine.GameObject
local function GetGameObject(name)
    local viewCount = GetViewCountByName(name)
    local viewName = CombinViewName(name,viewCount)
    return entries[viewName]
    --for _,  item in System.each(entries) do
    --    if item == nil then
    --        Logger.LogError("UIPanelCollector::GetPanel find item is nil")
    --        --- This situation cannot be occurred, so quit and return nil.
    --        return nil
    --    end
    --
    --    if item.Name == name then
    --        return item.GameObject
    --    end
    --end
end

---@param name string
---@param type_name string
---@return RmLuaBehaviour
function UIPanelCollector.GetScript(name)
    local go = GetGameObject(name)
    if GameObjectExtension.IsNil(go) then
        return nil
    else
        local behaviour = BehaviourUtility.GetComponentInGameObject(go, "RmLuaBehaviour")
        behaviour:Awake()
        return behaviour.LuaTableIns
    end
end

---@param gameObject UnityEngine.GameObject
local function bindGameObject(gameObject)
    local root = UnityEngine.GameObject.Find(UIConst.HierachyPathUI)
    Assert.GameObjectExist(root)
    GameObjectExtension.SetParent(gameObject, root.transform, true)
    counter = counter + 1
    --local index =  string.find(gameObject.name,"Clone")
    --Logger.LogError("index",index)
    if string.find(gameObject.name,"Clone") then
        local lengh = string.len(gameObject.name)
        local gameObjectName =  string.sub(gameObject.name,0,lengh -7)
        gameObject.name = gameObjectName
    end
    --gameObject.name = string.format("%04d", counter) .. "_" .. gameObject.name
end
---@param gameObject UnityEngine.GameObject
local function bindGameObjectToDestoryRoot(gameObject)
    local root = UnityEngine.GameObject.Find(UIConst.DontDestoryUIRoot)
    Assert.GameObjectExist(root)
    GameObjectExtension.SetParent(gameObject, root.transform, true)
    counter = counter + 1
    --local index =  string.find(gameObject.name,"Clone")
    --Logger.LogError("index",index)
    if string.find(gameObject.name,"Clone") then
        local lengh = string.len(gameObject.name)
        local gameObjectName =  string.sub(gameObject.name,0,lengh -7)
        gameObject.name = gameObjectName
    end
    --gameObject.name = string.format("%04d", counter) .. "_" .. gameObject.name
end
UIPanelCollector.DontCount = 0
---@param name string
---@param gameObject UnityEngine.GameObject
function UIPanelCollector.RegistPanel(name, gameObject,onDontRoot)
    Assert.NotNull(gameObject)
    local viewCount = GetViewCountByName(name)
    local viewName = CombinViewName(name,viewCount + 1)
    if entries[viewName] == nil then
        if onDontRoot then
            UIPanelCollector.DontCount = UIPanelCollector.DontCount + 1
            if UIPanelCollector.DontCount > 0 then
                LuaHelper.SetUIRootMangerEnable(true)
            end
            bindGameObjectToDestoryRoot(gameObject)
        else
            bindGameObject(gameObject)
        end
        entries[viewName] = gameObject
        nameMap[name] = viewCount + 1
    end
end

---@param namme string
---@return boolean
function UIPanelCollector.UnregistPanel(name,onDontRoot)
    local viewCount = GetViewCountByName(name)
    local viewName = CombinViewName(name,viewCount)
    if entries[viewName] ~= nil then
        entries[viewName] = nil
        nameMap[name] = viewCount - 1
    end
    if onDontRoot then
        UIPanelCollector.DontCount = UIPanelCollector.DontCount - 1
    end
    --Logger.LogError("UIPanelCollector.DontCount",UIPanelCollector.DontCount)
    if UIPanelCollector.DontCount < 1 then
        LuaHelper.SetUIRootMangerEnable(false)
    end
    return true
    --for _,  item in System.each(entries) do
    --    if item.Name == name then
    --        if not GameObjectExtension.IsNil(item.GameObject) then
    --            --GameObjectExtension.Destroy(item.GameObject)
    --        end
    --        return entries:Remove(item)
    --    end
    --end
    --Logger.LogError("UIPanelCollector.UnregistPanel failed, name : " .. name)
    --return false
end

---@return UnityEngine.GameObject
---@param name string
function UIPanelCollector.TryGetGameObject(name)
    local viewCount = GetViewCountByName(name)
    local viewName = CombinViewName(name,viewCount)
    return entries[viewName]
    --for _,  item in System.each(entries) do
    --    if item.Name == name then
    --        if not GameObjectExtension.IsNil(item.GameObject) then
    --            return item.GameObject
    --        end
    --    end
    --end
    --return nil
end