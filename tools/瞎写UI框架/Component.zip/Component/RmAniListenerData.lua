---@class RmAniListenerData
RmAniListenerData = class("RmAniListenerData")
RmAniListenerData.Ani_Play = "Play"
RmAniListenerData.Ani_Finish = "Finish"
RmAniListenerData.Ani_ResetAndPlay = "ResetAndPlay"

---@param pMainKey string
---@param pSubKey string
---@param pOriValue number
---@param pNewValue number
---@return RmAniListenerData
RmAniListenerData.Created = function(pMainKey,pSubKey,pOriValue,pNewValue)
    local listenerData = RmAniListenerData.New()
    listenerData._mainKey = pMainKey
    listenerData._subKey = pSubKey
    listenerData._oriValue = pOriValue
    listenerData._newValue = pNewValue
    if type(pOriValue) == "number" then
        listenerData._changeValue = pNewValue - pOriValue
    elseif type(pOriValue) == "string" then
        listenerData._changeValue = pNewValue
    end
    return listenerData
end

function RmAniListenerData:ctor()
    self._mainKey = "Test"
    self._subKey = nil
    self._oriValue = 0
    self._newValue = 1
    self._changeValue = nil

    self._oriProgress = nil
    self._newProgress = nil
    self._changeProgress = nil

    self._aniPlayType = RmAniListenerData.Ani_Play
    self._isprogressBar = false
    self._isNumberLabel = false

    self._finishCb = nil
end
---@param pPlayType string
function RmAniListenerData:SetPlayType(pPlayType)
    self._aniPlayType = pPlayType
end
---@return function
function RmAniListenerData:GetFinishCB()
    return self._finishCb
end

---@param pFinishCB function
function RmAniListenerData:SetFinishCB(pFinishCB)
    self._finishCb = pFinishCB
end

---@param pIsNL boolean
function RmAniListenerData:SetNumberLabel(pIsNL)
    self._isNumberLabel = pIsNL
end
---@return boolean
function RmAniListenerData:IsNumberLabel()
    return self._isNumberLabel
end

function RmAniListenerData:GetOriProgress()
    return self._oriProgress
end

function RmAniListenerData:GetNewProgress()
    return self._newProgress
end

function RmAniListenerData:GetChangProgress()
    return self._changeProgress
end
---@param pOrip number
---@param pNewP number
function RmAniListenerData:SetProgressInfo(pOrip,pNewP)
    self._oriProgress = pOrip
    self._newProgress = pNewP
    self._changeProgress = pNewP - pOrip
end
---@param pIsPB boolean
function RmAniListenerData:SetProgressBar(pIsPB)
    self._isprogressBar = pIsPB
end
---@return boolean
function RmAniListenerData:IsProgressBar()
    return self._isprogressBar
end
---@return string
function RmAniListenerData:GetMainKey()
    return self._mainKey
end
---@return string
function RmAniListenerData:GetPlayType()
    return self._aniPlayType
end
---@return number
function RmAniListenerData:GetChangeValue()
    return self._changeValue
end
---@return number
function RmAniListenerData:GetOriValue()
    return self._oriValue
end
---@return number
function RmAniListenerData:GetNewValue()
    return self._newValue
end
---@return string
function RmAniListenerData:GetSubKey()
    return self._subKey
end

function RmAniListenerData:Send()
    if self._newValue ~= self._oriValue then
        EventManager:BroadEvent(self:GetMainKey(),self,self)
    end
end