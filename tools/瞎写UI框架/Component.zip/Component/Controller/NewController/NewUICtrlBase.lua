---@class NewUICtrlBase
NewUICtrlBase = class("NewUICtrlBase")

function NewUICtrlBase:ctor()
    self._Keyword = ""
    self._ResType = ""
    self._ResName = ""
    self._NextCtrl = nil
    self._PreCtrl = nil
    self._Panel = nil
    self._State = NewUIConst.CtrlState.Create
    self._PrepareSuccesses = false
    self._PanelDepthSeaLevel = 0
end

function NewUICtrlBase:ReleaseResource() end
function NewUICtrlBase:PrePrepare(callback)
    callback(true)
end

function NewUICtrlBase:LoadResource(callback)
    callback()
end

function NewUICtrlBase:SetPanelData()

end

function NewUICtrlBase:ClearPanelData()

end

function NewUICtrlBase:PostPrepare(callback)
    callback()
end

function NewUICtrlBase:OnScreen(callback)
    callback()
end

function NewUICtrlBase:OffScreen(callback)
    callback()
end

function NewUICtrlBase:OnGetForeground()

end

function NewUICtrlBase:OnGetBackground()

end

function NewUICtrlBase:Dispose()
    
end

function NewUICtrlBase:IsActiveState()
    return self._State == NewUIConst.CtrlState.OnScreen
end

function NewUICtrlBase:IsDestroyState()
    return self._State < NewUIConst.CtrlState.LoadResource
end

function NewUICtrlBase:IsDisableState()
    return self._State == NewUIConst.CtrlState.ReadyEnter
end

return NewUICtrlBase
