---@class UIUtility
UIUtility = {}
UIUtility.SubUI = GameObject.Find("UI Root/Camera/Anchor/SubUI")
UIUtility.GetSubUI = function()
    if GameObjectExtension.IsNil(UIUtility.SubUI) then
        UIUtility.SubUI = GameObject.Find("UI Root/Camera/Anchor/SubUI")
    end
    return UIUtility.SubUI
end
---@param pLbTitle UILabel
---@param LanKey string
function UIUtility.SetTopLeftTitle(pLbTitle,LanKey) --全局设置左上角的位置和m锚点
    if pLbTitle ~= nil then
        pLbTitle.text = Language.GetValue(LanKey)
        pLbTitle.pivot = 3
        pLbTitle.gameObject.transform.localPosition  = Vector3.New(140,-29,0)
    end
end
function UIUtility.SetUIBlackEnable(pEnable)
    local baseBackRoot = GameObjectExtension.FindGameObject("UI Root/Camera/Middle")
    if  baseBackRoot ~= nil then
        baseBackRoot:SetActive(pEnable)
    end
end
UIUtility.JsonText = nil
UIUtility.JsonTable = nil
function UIUtility.GetResNameVersion(pResName)
    if UIUtility.JsonTable.Version ~= nil then
        for i = 1,#UIUtility.JsonTable.Version do
            if UIUtility.JsonTable.Version[i].name == pResName then
                return UIUtility.JsonTable.Version[i].version
            end
        end
    end
    return 0
end
function UIUtility.GetResServerJsonInfo(pForce,pCb)
    if UIUtility.JsonTable == nil or pForce then
        local resServerRoot = ConfigOp.GetGlobalValueByKey("ResServerUrl")
        local fullUrl = resServerRoot.."VersionInfo.json"
        LuaHelper.GetServerJson(fullUrl,function (pJson)
            UIUtility.JsonText = pJson
            local table  = JsonStringToLuaTable(pJson)
            --Logger.LogError("table",table)
            UIUtility.JsonTable = table
            InvokeSafely(pCb)
        end)
    else
        InvokeSafely(pCb)
    end
end

function UIUtility.SetTextureMainByFullUrl(pUITexture,pURl,pForce)
    if pURl ~= nil and pURl ~= "" then
        --Logger.Log("pURl"..pURl)
        local name = LuaHelper.GetNameFormFullPath(pURl)
        --Logger.Log("name"..name)
        UIUtility.SetTextureMainTexByName(pUITexture,name,pForce)
    else
        Logger.LogError("SetTextureMainByFullUrl pURl is nil ")
    end
end

UIUtility.Textures = {}
UIUtility.TexturesVersions = {}
---@param pUITexture UITexture
---@param pForce boolean
---@param pName string
function UIUtility.SetTextureMainTexByName(pUITexture,pName,pForce)
    if UIUtility.Textures[pName] ~= nil and pForce == false then
        pUITexture.mainTexture = UIUtility.Textures[pName]
        return
    end
    UIUtility.GetResServerJsonInfo(pForce,function ()
        local saveVersion = UIUtility.TexturesVersions[pName]
        local curVersion =  saveVersion == nil and -1 or saveVersion
        local lineVersion = UIUtility.GetResNameVersion(pName)

        if lineVersion > curVersion or UIUtility.Textures[pName] == nil then
            local resServerRoot = ConfigOp.GetGlobalValueByKey("ResServerUrl")
            local fullUrl = resServerRoot..pName..".png"
            if pUITexture ~= nil then
                LuaHelper.GetServerTexture(pUITexture,fullUrl,function (pTexture)
                    if pUITexture ~= nil and pTexture ~= nil then
                        pUITexture.mainTexture = pTexture
                        UIUtility.TexturesVersions[pName] = lineVersion
                        UIUtility.Textures[pName] = pTexture
                    end
                end)
            end
        else
            pUITexture.mainTexture = UIUtility.Textures[pName]
        end
    end)
end

--- Screen Blocker
---@param isBlock boolean
---@param msg string
function UIUtility.SetScreenBlock(isBlock, msg)
    ScreenBlocker.SetScreenBlock(isBlock, msg)
end

function UIUtility.OpenBlackEx(callback,needDot)
    ---@type UI_BackBlockCtrl
    if UIUtility.BlackOverCtrl == nil then
        UIUtility.BlackOverCtrl = (require("Logic.UI.UICtrls.Battle.Battle_BlackCoverCtrl").Create())
        Logger.LogError("OpenBlackEx needDot",needDot)
        UIUtility.BlackOverCtrl._LoadOnDontUIRoot = needDot
    end
    UICtrlManager.UIBack:Perform(UIUtility.BlackOverCtrl,function ()
        UIUtility.BlackOverCtrl:ShowWalkIn(function() InvokeSafely(callback) end)
    end,UICtrlManager.PerformActionDefault)
end

function UIUtility.CloseBlackEx(callback)
    if UIUtility.BlackOverCtrl ~= nil then
        UIUtility.BlackOverCtrl:ShowWalkOut(function ()
            UICtrlManager.UIBack:RevokeTop(function ()
                UIUtility.BlackOverCtrl = nil
                InvokeSafely(callback)
            end,UICtrlManager.RevokeActionDefault)
        end)
    end
end

function UIUtility.OpenHelpTips(pData)
    local PageTipsCtrl = (require("Logic.UI.UICtrls.Common.UI_Common_PageTipsCtrl").Create())
    PageTipsCtrl:SetData(pData)
    UICtrlManager.UILayer:Perform(PageTipsCtrl,function () end,UICtrlManager.PerformActionDefault)
end

function UIUtility.OpenBuffTip(pData,pPos)
    local buffTipCtrl = (require("Logic.UI.UICtrls.Common.UIBuffTipCtrl").Create())
    buffTipCtrl:SetData(pData,pPos)
    UICtrlManager.UILayer:Perform(buffTipCtrl,function () end,UICtrlManager.PerformActionDefault)
end

function UIUtility.ShowBackTimeEx(pTime,pCallBack)
    UIUtility.OpenBlackEx(nil)
    LuaHelper.DeferSeconds(pTime,function ()
        UIUtility.CloseBlackEx(nil)
        InvokeSafely(pCallBack)
    end)
end
-- 黑屏 打开
function UIUtility.OpenBlack(callback)
    ---@type UI_BackBlockCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.Common.UI_BackBlockCtrl").Create())
    UICtrlManager.UIBack:Perform(uiCtrlBase,callback,UICtrlManager.PerformActionDefault)
end

function UIUtility.OpenLevelUpDialog(pPreLevel,pNowLevel,callback,pNeedCheckBattle)
    if Me.GetDMGuildeManager():IsGuideRuning() then return end
    if pNeedCheckBattle == nil or pNeedCheckBattle == true then
        if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then return end
    end
    ---@type UIPlayerLevelUpCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.Player.UIPlayerLevelUpCtrl").Create())
    uiCtrlBase:SetUIPlayerLevelUpCtrl(pPreLevel,pNowLevel,callback)
    ScreenDialog.LoadDialogView(uiCtrlBase,nil,UICtrlManager.PerformActionDefault)
    --UICtrlManager.UILayer:Perform(uiCtrlBase,callback,UICtrlManager.PerformActionDefault)
end

---@param pNewFunctions DMNewFunction[]
function UIUtility.OpenNewFuncDialog(pNewFunctions,pCallBack)
    ---@type UI_NewFunctionDialogCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.NewFunction.UI_NewFunctionDialogCtrl").Create())
    uiCtrlBase:SetData(pNewFunctions,pCallBack)
    UICtrlManager.UINoticeLayer:Perform(uiCtrlBase,nil,UICtrlManager.PerformActionDefault)
end

---@param pNewFunctions DMNewFunction[]
function UIUtility.OpenNewFuncRewardDialog(pNewFunctions,pCallBack)
    ---@type UI_NewFunctionRewardDialogCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.NewFunction.UI_NewFunctionRewardDialogCtrl").Create())
    uiCtrlBase:SetData(pNewFunctions,pCallBack)
    UICtrlManager.UINoticeLayer:Perform(uiCtrlBase,nil,UICtrlManager.PerformActionDefault)
end

function UIUtility.OpenNewFuncIfExist(pCallBack)
    Me.GetDMNewFunctionManager():OpenFuncDialog(pCallBack)
end
function UIUtility.OpenNewFuncRewardIfExist(pCallBack)
    Me.GetDMNewFunctionManager():OpenFuncRewardDialog(pCallBack)
end
 -- 黑屏关闭
function UIUtility.CloseBlack(callback)
    --Logger.LogError("UIUtility.CloseBlack>>>>")
    UICtrlManager.UIBack:RevokeTop(callback,UICtrlManager.RevokeActionDefault)
end
---@param pTime number
---@param pCallBack fun()
function UIUtility.ShowBackTime(pTime,pCallBack)
    UIUtility.OpenBlack(nil)
    LuaHelper.DeferSeconds(pTime,function ()
        UIUtility.CloseBlack()
        InvokeSafely(pCallBack)
    end)
end

---@param pTime number
---@param pCallBack fun()
function UIUtility.ShowInkTime(pTime,pCallBack)
    ---@type UI_BackBlockCtrl
    local uiCtrlBase = (require("Logic.UI.UICtrls.Common.UI_InkMaskCtrl").Create())
    UICtrlManager.UIBack:Perform(uiCtrlBase,nil,UICtrlManager.PerformActionDefault)
    LuaHelper.DeferSeconds(pTime,function ()
        InvokeSafely(pCallBack)
    end)
end

--- Release Memory
function UIUtility.ReleaseMemory()
    --local isNeedGC = LuaHelper.ClearCache()
    --Logger.LogError("ReleaseMemory isNeedGC",isNeedGC)
    --if isNeedGC then
    --    print(collectgarbage("collect")) --LuaGC
    --    --LuaHelper.ForceClearAllCache(false)
    --end
end

---@param pGORes UnityEngine.GameObject
---@param pResType string
---@param pResName string
function UIUtility.LuaHelperDestoryRes(pGORes,pResType,pResName)
    if pGORes ~= nil then
        LuaHelper.ResourceDestroy(pResType,pResName,pGORes)
    end
    pGORes = nil
end
---@return UnityEngine.GameObject
function UIUtility.GetLayerGameObject(name, panelDepth)
    local root = UnityEngine.GameObject.Find(UIConst.HierachyPathUI)
    Assert.GameObjectExist(root, "Not find root in hierachy: "..UIConst.HierachyPathUI)
    local subRoot = UnityEngine.GameObject.Find(UIConst.HierachyPathUI .. "/" .. name)
    if subRoot ~= nil then
        return subRoot
    else
        local newGo = GameObject.New()
        newGo.name = name
        newGo.layer = 5
        GameObjectExtension.SetParent(newGo, root.transform, true)
        local panel = newGo:AddComponent(typeof(UIPanel))
        panel.depth = panelDepth
        return newGo
    end
end

function GetTimeStringBySecs(pSecs)
    local oneDaySecs = 86400
    local oneHourSecs = 3600
    if pSecs > oneDaySecs then
        return math.floor(pSecs / oneDaySecs)..Language.GetValue("Common_Time_Day")
    elseif pSecs > oneHourSecs then
        return math.floor(pSecs / oneHourSecs)..Language.GetValue("Common_Time_Hour")
    else
        local mins = math.floor(pSecs / 60)
        local Secs = pSecs - mins * 60
        return StringExtension.StringFormat(Language.GetValue("Common_Time_Format"),{0,mins,Secs})
    end
end

function GetTimeFormatBySecs(pSecs)
    local hours = math.floor(pSecs / 3600)
    local minues = math.floor((pSecs % 3600)/60)
    local secs = math.floor(pSecs % 60)
    return string.format("%02d:%02d:%02d",hours,minues,secs)
end

function GetTimeOneDayFormatBySecs(pSecs)
    local oneDaySecs = 86400
    if pSecs > oneDaySecs then
        return GetTimeStringBySecs(pSecs)
    else
        return GetTimeFormatBySecs(pSecs)
    end
end

function UIUtility.GetTimeStringText(pTimeTick)
    local dateTime = ServerTimerUtil.GetLocalServerDateTimeByTimeTick(pTimeTick)
    local serverDateTime = Me.CurServerDateTime()
    local timeSpance = dateTime - serverDateTime
    local secs = math.abs(timeSpance:getTotalSeconds())
    return GetTimeOneDayFormatBySecs(secs)
end

---@param pThingPrefabs ThingPrefab[]
function UIUtility.PlayFlyAnim(pThingPrefabs,targetWorldPos,pScale)
    --Logger.LogError("targetWorldPos",targetWorldPos)
    local rePos = targetWorldPos
    if rePos.x >= 10 then
        rePos = rePos*0.03125
    end
    local haveCount = 0
    local rate = 1
    for i = 1, 10 do
        local perfab = pThingPrefabs[i]
        if perfab ~= nil and GameObjectExtension.IsNil(perfab.gameObject) == false then
            haveCount = haveCount + 1
        end
    end
    local goList = {}
    if haveCount > 0 then
        local panel = UnityEngine.GameObject.New("tempPanel")
        local subUI =  UIUtility.GetSubUI()
        panel.transform.parent = subUI.transform
        panel:AddComponent(typeof(UIPanel))
        panel:GetComponent("UIPanel").depth = 2200
        panel.layer = 5
        panel.transform.localScale = Vector3.one
        panel.transform.localPosition = Vector3.zero
        for i = 1, 10 do
            local perfab = pThingPrefabs[i]
            if perfab ~= nil and GameObjectExtension.IsNil(perfab.gameObject) == false then
                perfab:SetFrameEnable(false)
                local dupCount = 1
                if perfab.lbvItem ~= nil then
                    local dmitem = perfab.lbvItem.dmItem
                    if dmitem ~= nil then
                        if dmitem:IsResource() then
                            dupCount = 6
                        end
                    end
                end
                if perfab.lbvHero ~= nil then
                    dupCount = 0
                end
                for i = 1, dupCount do
                    local newGo = GameObjectExtension.NewGameObject(perfab.gameObject,panel,false)
                    local ve3 = perfab.gameObject.transform.localPosition
                    newGo.gameObject.transform.localScale = Vector3.one
                    ve3.x = ve3.x + math.random(-200,200)
                    ve3.y = ve3.y + math.random(-130,130)
                    newGo.transform.localPosition = ve3
                    newGo:SetActive(false)
                    table.insert(goList,newGo)
                end
            end
        end
        local defer = 0
        for i = 1, #goList do
            LuaHelper.DeferSeconds(defer,function ()

                if goList ~= nil and not GameObjectExtension.IsNil(goList[i]) then
                    goList[i]:SetActive(true)
                    local luaIns = goList[i]:GetComponent("RmLuaBehaviour")

                    if pScale ~= nil then
                        luaIns.transform.localScale = pScale
                    end
                    luaIns:FlyAnim(rePos)
                end
            end)
            defer = defer + 0.8/(i*rate + 4)
        end

        if #goList > 0 then
            MusicOperation.PlayUISound(MusicList.ResourceFly)
        end

        LuaHelper.DeferSeconds(rate * #goList + 1,function ()
            if GameObjectExtension.IsNil(panel) == false then
                GameObjectExtension.Destroy(panel)
            end
        end)
    end
end

---一行居中 多行左对齐
---@param label UILabel
function UIUtility.SetLabelAlignment(label)
    if label ~= nil and label.processedText ~= nil then
        if string.match(label.processedText,"\n") then
            label.alignment =1
        else
            label.alignment =2
        end
    end
end

--anchor = 0 --上中下适配
--anchor = 1 --上
--anchor = 2 --中
--anchor = 3 --下
function UIUtility.FixIphone(obj,anchor)
    if Utility.IsIphoneDevice() then
        --LuaHelper.FixScreenOnIphoneX(obj,anchor)
    end
end
---@param pRpIcon UISprite
function UIUtility.SetRpShowType(pRpIcon,pShowType)
    if pRpIcon ~= nil then
        local isNew = pShowType == 2
        pRpIcon.spriteName = isNew and "tx_new" or "icon_hongdian_02"
        if isNew then
            pRpIcon:MakePixelPerfect()
        else
            pRpIcon.height = 34
            pRpIcon.width = 34
        end
    end
end