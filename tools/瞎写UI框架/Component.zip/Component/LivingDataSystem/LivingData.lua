---@class LivingData
---@field __BindEventKey string
---@field __BindData table

LivingData = class("LivingData")
function LivingData.Created(pEventKey)
    return LivingData.New(pEventKey)
end
function LivingData:ctor(pEventKey)
    Logger.LogError("pEventKey"..pEventKey)
    self.__BindEventKey = pEventKey
    self.__BindData = nil
end
---@return string
function LivingData:GetEventKey()
    return  self.__BindEventKey
end
---@param pData table
function LivingData:SetValue(pData)
    self.__BindData = pData
    EventManager:BroadEvent(self.__BindEventKey,self,self.__BindData)
end
---@return table
function LivingData:GetValue()
    return self.__BindData
end