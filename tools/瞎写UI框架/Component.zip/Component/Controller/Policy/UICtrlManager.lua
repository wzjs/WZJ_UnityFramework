
---@field UILayer UICtrlPolicyIntent
---@field UIBattleLayer UICtrlPolicyIntent
---@field UIBattleAwardLayer UICtrlPolicyIntent
---@field UIDialog UICtrlPolicyQueue
---@field UIAlert UICtrlPolicyQueue
---@field UILoading UICtrlPolicySingle

---@class UICtrlManager
UICtrlManager = {}
local this = UICtrlManager
---@type NewUICtrlPolicyIntent
UICtrlManager.NewUILayer = NewUICtrlPolicyIntent.Create(UIConst.UIDepthMidDialog)

---@type UICtrlPolicyIntent
UICtrlManager.UILayer = UICtrlPolicyIntent.Create(UIConst.UIDepthLayer)
---@type UICtrlPolicyIntent
UICtrlManager.UILayerEx = UICtrlPolicyIntent.Create(UIConst.UIDepthLayer+300)

---@type UICtrlPolicyIntent
UICtrlManager.UIBattleLayer = UICtrlPolicyIntent.Create(UIConst.UIDepthLayer + 1)

UICtrlManager.UIBattleBlockLayer = UICtrlPolicyIntent.Create(UIConst.UIBattleLock) --- UICtrlPolicyIntent.Create(UIConst.UIDepthBossLayer)

UICtrlManager.UIBattleLayerUpBlock = UICtrlManager.UIBattleLayer --- UICtrlPolicyIntent.Create(UIConst.UIDepthUpBattle)

UICtrlManager.UIBattleBossLayer = UICtrlPolicyIntent.Create(UIConst.UIDepthBossLayer)

UICtrlManager.UIBattleAwardLayer = UICtrlPolicyIntent.Create(UIConst.UIDepthBossLayer + 50)

UICtrlManager.BattleTopLayer = UICtrlPolicyQueue.Create(UIConst.UIDepthMidDialog)
---@type UICtrlPolicyIntent
UICtrlManager.UINoticeLayer = UICtrlPolicyIntent.Create(UIConst.UINotice)

---@type UICtrlPolicyIntent
UICtrlManager.UIMideUpLayer = UICtrlPolicyIntent.Create(UIConst.UIMideUp)

---@type UICtrlPolicyQueue
UICtrlManager.UIDialog = UICtrlPolicyQueue.Create(UIConst.UIDepthMidDialog)

---@type UICtrlPolicyIntent
UICtrlManager.UIHorse = UICtrlPolicyIntent.Create(UIConst.UIDepthHorseLayer)
---@type UICtrlPolicyIntent
UICtrlManager.TipLayer = UICtrlPolicyIntent.Create(UIConst.UIDepthTipLayer)

UICtrlManager.UIStory = UICtrlPolicyIntent.Create(UIConst.UIDepthStoryLayer)
---@type UICtrlPolicyIntent
UICtrlManager.UIGuide = UICtrlPolicyIntent.Create(UIConst.UIDepthGuideLayer)

UICtrlManager.UIAlert = UICtrlPolicyQueue.Create(UIConst.UIDepthAlert)

UICtrlManager.UIBack = UICtrlPolicyIntent.Create(UIConst.UIDepthBackLayer)--黑色切UI

UICtrlManager.UILoading = UICtrlPolicySingle.Create(UIConst.UIDepthLoading)--载入界面

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlManager.Restore(callback, performData)
    Logger.LogInfo("UICtrlManager.Restore")
    local ulc = UntilLastCall.Create(function()
        InvokeSafely(callback)
    end, 14,"UICtrlManager.Restore")

    UICtrlManager.UIGuide:Restore(function ()
        Logger.LogInfo("Restore UIGuide")
        ulc:Invoke()
    end,performData)

    Logger.LogInfo("UICtrlManager.Restore_1")
    UICtrlManager.UILayer:Restore(function()
        Logger.LogInfo("Restore UILayer")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UILayerEx:Restore(function()
        Logger.LogInfo("Restore UILayerEx")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIHorse:Restore(function ()
        Logger.LogInfo("Restore UIHorse")
        ulc:Invoke()
    end,performData)
    UICtrlManager.TipLayer:Restore(function ()
        Logger.LogInfo("Restore TipLayer")
        ulc:Invoke()
    end,performData)


    UICtrlManager.UINoticeLayer:Restore(function()
        Logger.LogInfo("Restore UINoticeLayer")
        ulc:Invoke()
    end,performData)
    UICtrlManager.UIMideUpLayer:Restore(function()
        Logger.LogInfo("Restore UIMideUpLayer")
        ulc:Invoke()
    end,performData)
    UICtrlManager.UIBack:Restore(function()
        Logger.LogInfo("Restore UIBack")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIBattleBossLayer:Restore(function()
        Logger.LogInfo("Restore UIBattleBossLayer")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIBattleBlockLayer:Restore(function()
        Logger.LogInfo("Restore UIBattleBlockLayer")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIStory:Restore(function ()
        Logger.LogInfo("Restore UIStory")
        ulc:Invoke()
    end,performData)
    UICtrlManager.UIDialog:Restore(function()
        Logger.LogInfo("Restore UIDialog")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIBattleAwardLayer:Restore(function()
        Logger.LogInfo("Restore UIBattleAwardLayer")
        ulc:Invoke()
    end , performData)
    UICtrlManager.UIBattleLayer:Restore(function()
        Logger.LogInfo("Restore UIBattleLayer")
        ulc:Invoke()
    end , performData)
end

UICtrlManager.PerformCommon = function(ctrl,pCb)
    if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then
        UICtrlManager.UIBattleLayer:Perform(ctrl,pCb,UICtrlManager.PerformActionDefault)
    else
        UICtrlManager.UILayer:Perform(ctrl,pCb,UICtrlManager.PerformActionDefault)
    end
end

UICtrlManager.PerformCommonBoss = function(ctrl,pCb)
    if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then
        UICtrlManager.UIBattleBossLayer:Perform(ctrl,pCb,UICtrlManager.PerformActionDefault)
    else
        UICtrlManager.UILayer:Perform(ctrl,pCb,UICtrlManager.PerformActionDefault)
    end
end

UICtrlManager.RevokeCommon = function(pCb)
    if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then
        UICtrlManager.UIBattleLayer:RevokeTop(pCb,UICtrlManager.RevokeActionDefault)
    else
        UICtrlManager.UILayer:RevokeTop(pCb,UICtrlManager.RevokeActionDefault)
    end
end

UICtrlManager.RevokeCommonBoss = function(pCb)
    if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then
        UICtrlManager.UIBattleBossLayer:RevokeTop(pCb,UICtrlManager.RevokeActionDefault)
    else
        UICtrlManager.UILayer:RevokeTop(pCb,UICtrlManager.RevokeActionDefault)
    end
end

UICtrlManager.GetCurMainLayer = function()
    if SceneManager.GetCurSceneType() == SceneManager.SceneType_Battle then
        return UICtrlManager.UIBattleLayer
    end
    return UICtrlManager.UILayer
end

UICtrlManager.BroadTaskEvent = function(pKeyWord)
    if Me == nil then return end
    ---@param  ctrlBase UICtrlPolicyIntent
    local funcCtrl = function(ctrlBase)
        if Me == nil then return end
        if ctrlBase ~= nil then
            local keyWord = ctrlBase:GetKeyWord()
            if pKeyWord == nil or pKeyWord == keyWord then
                local mainId,subId = DMFuncModelType.GetFuncModelByStringKey(ctrlBase:GetKeyWord())
                Me.BroadTaskEvent(EventConditioner.ConditionType_OnGetForeground,mainId,subId,ctrlBase:CtrlEventKey())
                Me.BroadTaskEvent(EventConditioner.ConditionType_OnOneUIForward)
            end
        end
    end

    if UICtrlManager.UILayer:GetRestoreCtrlsCount() < 1 then
        funcCtrl(UICtrlManager.UILayer:GetTopCtrl())
    end
    if UICtrlManager.UIBattleLayer:GetRestoreCtrlsCount() < 1 then
        funcCtrl(UICtrlManager.UIBattleLayer:GetTopCtrl())
    end
    if UICtrlManager.UIBattleBossLayer:GetRestoreCtrlsCount() < 1 then
        funcCtrl(UICtrlManager.UIBattleBossLayer:GetTopCtrl())
    end
    if UICtrlManager.UIDialog:GetRestoreCtrlsCount() < 1 then
        funcCtrl(UICtrlManager.UIDialog:GetTopCtrl())
    end
end

---@return UICtrlPerformData
UICtrlManager.GetPerformActionBlack = function(pTime)
    local performData = UICtrlPerformData.Create()
    performData._BlackBlockEnable = true
    performData._BlackBlockTime = pTime
    return performData
end

UICtrlManager.PerformActionBlack = UICtrlPerformData.Create()
UICtrlManager.PerformActionBlack._BlackBlockEnable = true
UICtrlManager.PerformActionBlack._BlackBlockTime = 0.5


UICtrlManager.PerformActionDefault = read_only(UICtrlPerformData.Create())

UICtrlManager.PerformActionDisablePrev = UICtrlPerformData.Create()
UICtrlManager.PerformActionDisablePrev._PrevCtrlState = UIConst.PrevState.Disable
UICtrlManager.PerformActionDisablePrev = read_only(UICtrlManager.PerformActionDisablePrev)

UICtrlManager.PerformActionDestroyPrev = UICtrlPerformData.Create()
UICtrlManager.PerformActionDestroyPrev._PrevCtrlState = UIConst.PrevState.Destroy
UICtrlManager.PerformActionDestroyPrev = read_only(UICtrlManager.PerformActionDestroyPrev)

UICtrlManager.RevokeActionDefault = UICtrlPerformData.Create()
UICtrlManager.RevokeActionDefault._PlayEnterEffect = true
UICtrlManager.RevokeActionDefault._PlayExitEffect = true
UICtrlManager.RevokeActionDefault = read_only(UICtrlManager.RevokeActionDefault)

UICtrlManager.RevokeActionNoEffect = UICtrlPerformData.Create()
UICtrlManager.RevokeActionNoEffect._PlayEnterEffect = false
UICtrlManager.RevokeActionNoEffect._PlayExitEffect = false
UICtrlManager.RevokeActionNoEffect = read_only(UICtrlManager.RevokeActionNoEffect)
---Restore -- 面板恢复逻辑
UICtrlManager.RestoreActionDefault = UICtrlPerformData.Create()
UICtrlManager.RestoreActionDefault._PlayEnterEffect = false
UICtrlManager.RestoreActionDefault._PlayExitEffect = false
UICtrlManager.RestoreActionDefault = read_only(UICtrlManager.RestoreActionDefault)

UICtrlManager.RestoreActionDisablePrev = UICtrlPerformData.Create()
UICtrlManager.RestoreActionDisablePrev._PrevCtrlState = UIConst.PrevState.Disable
UICtrlManager.RestoreActionDisablePrev._PlayEnterEffect = false
UICtrlManager.RestoreActionDisablePrev._PlayExitEffect = false
UICtrlManager.RestoreActionDisablePrev = read_only(UICtrlManager.RestoreActionDisablePrev)

UICtrlManager.RestoreActionDestroyPrev = UICtrlPerformData.Create()
UICtrlManager.RestoreActionDestroyPrev._PrevCtrlState = UIConst.PrevState.Destroy
UICtrlManager.RestoreActionDestroyPrev._PlayEnterEffect = false
UICtrlManager.RestoreActionDestroyPrev._PlayExitEffect = false
UICtrlManager.RestoreActionDestroyPrev = read_only(UICtrlManager.RestoreActionDestroyPrev)

---Reduce 深度降低进入
UICtrlManager.PerformActionDepthReduce = UICtrlPerformData.Create()
UICtrlManager.PerformActionDepthReduce._DepthReduce = true
UICtrlManager.PerformActionDisablePrev._PrevCtrlState = UIConst.PrevState.Disable
UICtrlManager.PerformActionDepthReduce = read_only(UICtrlManager.PerformActionDepthReduce)

UICtrlManager.NewPerformActionDefault = read_only(NewPolicyData.New())
