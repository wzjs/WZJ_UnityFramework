local super = require("Component/Controller/Policy/UICtrlPolicyBase")

---@class UICtrlPolicyQueue : UICtrlPolicyBase
UICtrlPolicyQueue = class("UICtrlPolicyQueue", super)

---@field private _CommanderQueue UICtrlBase[]
---@param baseDepth number
---@return UICtrlPolicyIntent
function UICtrlPolicyQueue.Create(baseDepth)
    return UICtrlPolicyQueue.New(baseDepth)
end

---@param baseDepth number
function UICtrlPolicyQueue:ctor(baseDepth)
    UICtrlPolicyQueue.super.ctor(self, baseDepth)
    self._CommanderQueue = System.List(System.Object)()
end

---@param policy UICtrlPolicyQueue
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
local function TryCallCommander (policy, uiCtrl, callback, performData)
    if policy._State ~= UIConst.CtrlManagerState.Active then
        Logger.LogError("TryCallCommander failed, current state is not Active")
        return
    end

    if policy._CommanderQueue:getCount() == 0 then
        return
    end
    local commander = policy._CommanderQueue:get(0)
    policy._CommanderQueue:RemoveAt(0)
    if commander.Type == "Perform" then
        policy:Perform_Internal(commander.UICtrl, commander.Callback, commander.PerformData)
    elseif commander.Type == "RevokeTop" then
        policy:RevokeTop_Internal(commander.Callback, commander.PerformData)
    else
        ThrowException("TryCallCommander failed, Unexpected commander type: " .. commander.Type)
    end
end

---@param type string
---@param policy UICtrlPolicyQueue
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
local function AddToCommander(type, policy, uiCtrl, callback, performData)
    local commander = {}
    commander.Type =  type
    commander.UICtrl = uiCtrl
    commander.Callback = callback
    commander.PerformData = performData
    policy._CommanderQueue:Add(commander)
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:Perform_Internal(uiCtrl, callback, performData)
    self._State = UIConst.CtrlManagerState.Performing
    UICtrlPolicyQueueOp.Perform( function()
        self._State = UIConst.CtrlManagerState.Active
        InvokeSafely(callback)
    end , uiCtrl, performData, self)
end

---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:Perform(uiCtrl, callback, performData)
    --Logger.LogError("self._State"..self._State)
    if self._State ~= UIConst.CtrlManagerState.Active then
        AddToCommander("Perform", self, uiCtrl, callback, performData)
        return
    end
    --Logger.LogError("self:GetCtrlsCount()"..self:GetCtrlsCount())
    if self:GetCtrlsCount() > 0 then
        AddToCommander("Perform", self, uiCtrl, callback, performData)
        return
    end
    --if self:Peek() ~= nil then
    -- AddToCommander("Perform", self, uiCtrl, callback, performData)
    --        return
    --end
    self:Perform_Internal(uiCtrl, callback, performData)
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:RevokeTop_Internal(callback, performData)
    self._State = UIConst.CtrlManagerState.Revoking
    UICtrlPolicyQueueOp.RevokeTop(function()
        self._State = UIConst.CtrlManagerState.Active
        TryCallCommander(self, nil, callback, performData)
        InvokeSafely(callback)
    end , performData, self)
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:RevokeTop(callback, performData)
    if self._State ~= UIConst.CtrlManagerState.Active then
        UICtrlUtility.LogError("RevokeTop failed, Current State is "..self._State)
        AddToCommander("RevokeTop", self, nil, callback, performData)
        return
    end

    if self:Peek() == nil then
        UICtrlUtility.LogError("Current ctrls peek is nil ")
        AddToCommander("RevokeTop", self, nil, callback, performData)
        return
    end

    self:RevokeTop_Internal(callback, performData)
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:SaveAndRelease(callback, performData)
    --TODO. implement.
    self._State = UIConst.CtrlManagerState.DeActive
    InvokeSafely(callback)
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyQueue:Restore(callback, performData)
    --TODO. implement.
    self._State = UIConst.CtrlManagerState.Active
    InvokeSafely(callback)
end

return UICtrlPolicyQueue