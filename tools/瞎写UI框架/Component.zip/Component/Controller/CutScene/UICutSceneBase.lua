---@class UICutSceneBase

UICutSceneBase = class("UICutSceneBase")