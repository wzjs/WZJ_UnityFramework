---@class CommonViewOp
CommonViewOp = {}

CommonViewOp.DMViewModel1 = DMCommonView.Create("xx",xx,xx,xx)
CommonViewOp.DMViewModel2 = DMCommonView.Create("","")
CommonViewOp.DMViewModel3 = DMCommonView.Create("","")
CommonViewOp.DMViewModel4 = DMCommonView.Create("","")
CommonViewOp.DMViewModel5 = DMCommonView.Create("","")
CommonViewOp.DMViewModel6 = DMCommonView.Create("","")

CommonViewOp.OpenViewModel = function(pModel1，pTitle)

end

CommonViewOp.OpenViewModel = function(pDMCommonView)

end


