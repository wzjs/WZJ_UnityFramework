local super = require "Component/Viewer/RmUIBase"

ConfirmPanel=class("ConfirmPanel",super)
---@class ConfirmPanel:RmUIBase
---@field private E_OnClickConfirm fun() 點擊事件

function ConfirmPanel.Create(o)
    -- body
    return ConfirmPanel.New(o)
end

function ConfirmPanel:ctor(obj)
    -- body
    ConfirmPanel.super.ctor(self,obj)
	self.E_OnClickConfirm = nil
end

function ConfirmPanel:Awake()
    -- body
	---@type UISprite
	Logger.Log("ConfirmPanel 11111")
	self.spBG = BehaviourUtility.GetComponent(self, "BG", "UISprite")
	---@type UnityEngine.GameObject
	Logger.Log("ConfirmPanel 222222")
	self.goContent = BehaviourUtility.GetComponent(self, "Content","UICustomLabel")
	---@type UISprite
	Logger.Log("ConfirmPanel 3333333")
	self.spBtn_Confirm = BehaviourUtility.GetComponent(self, "Btn_Confirm", "UIEventListener")
	Logger.Log("ConfirmPanel 444444")
	if self.spBG == nil then
		Logger.Log("spBG is nil")
	else
		Logger.Log("spBG ")
	end
	if self.goContent == nil then
		Logger.Log("goContent is nil")
	else
		Logger.Log("goContent ")
	end
	if self.spBtn_Confirm == nil then
		Logger.Log("spBtn_Confirm is nil")
	else
		Logger.Log("spBtn_Confirm ")
	end
	self.spBtn_Confirm.onClick = function()
		InvokeSafely(self.E_OnClickConfirm)
		Logger.Log("event onClick")
	end
end
function ConfirmPanel:ShowConfirmPanel(content)

	self.goContent.Text = content

end
function ConfirmPanel:DoPrepare(  )
	Logger.Log("DOPrepare")

end

function ConfirmPanel:DoShowOffScreen( )
    -- body
end

function ConfirmPanel:DoShowOnScreen( )
    -- body
end

function ConfirmPanel:PlayEnterEffects( callBack )
    callBack()
end

function ConfirmPanel:PlayExitEffects( callBack )
    -- body
    callBack()
end

function ConfirmPanel:DoDispose(  )
    -- body
end

function ConfirmPanel:DoDestory()
end

return ConfirmPanel