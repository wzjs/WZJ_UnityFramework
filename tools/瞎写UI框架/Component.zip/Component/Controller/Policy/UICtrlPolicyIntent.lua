local super = require("Component/Controller/Policy/UICtrlPolicyBase")

---@class UICtrlPolicyIntent : UICtrlPolicyBase
UICtrlPolicyIntent = class("UICtrlPolicyIntent", super)

---@field private _CommanderQueue UICtrlBase[]
---@field private _Backup UICtrlBase[]

---@param baseDepth number
---@return UICtrlPolicyIntent
function UICtrlPolicyIntent.Create(baseDepth)
    return UICtrlPolicyIntent.New(baseDepth)
end

---@param baseDepth number
function UICtrlPolicyIntent:ctor(baseDepth)
    UICtrlPolicyIntent.super.ctor(self, baseDepth)
    --self._Backup = System.List(System.Object)()
    self._CommanderQueue = System.List(System.Object)()
end

---@param policy UICtrlPolicyIntent
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
local function TryCallCommander (policy, uiCtrl, callback, performData)
    --Logger.Log("TryCallCommander1 : ")
    if policy._State ~= UIConst.CtrlManagerState.Active then
        --Logger.LogError("TryCallCommander failed, current state is not Active")
        --Logger.Log("TryCallCommander2")
        return
    end
    if policy._CommanderQueue:getCount() == 0 then
        --Logger.Log("TryCallCommander3")
        return
    end
    local commander = policy._CommanderQueue:get(0)
    policy._CommanderQueue:RemoveAt(0)
    if commander.Type == "Perform" then
        policy:Perform(commander.UICtrl, commander.Callback, commander.PerformData)
    elseif commander.Type == "RevokeTop" then
        policy:RevokeTop(commander.Callback, commander.PerformData)
    elseif commander.Type == "RevokeToBottom" then
        policy:RevokeToBottom(commander.Callback,commander.PerformData)
    elseif commander.Type == "RevokeAllCtrls" then
        policy:RevokeAllCtrls(commander.Callback,commander.PerformData)
    else
        ThrowException("TryCallCommander failed, Unexpected commander type: " .. commander.Type)
    end
    --Logger.Log("TryCallCommander4")
end

---@param type string
---@param policy UICtrlPolicyIntent
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
local function AddToCommander(type, policy, uiCtrl, callback, performData)
    --Logger.Log("AddToCommander1")
    local commander = {}
    commander.Type =  type
    commander.UICtrl = uiCtrl
    commander.Callback = callback
    commander.PerformData = performData
    --Logger.Log("AddToCommander2")
    policy._CommanderQueue:Add(commander)
    --Logger.Log("AddToCommander3")
end
---@param policy UICtrlPolicyIntent
local function CheckLayerDepth(policy)
    local curDepth = policy:GetCtrlsCount()
    if curDepth >= 2 and Redmoon.Project.Config.GlobalTemplateManager.Template then
        local maxDepth = Redmoon.Project.Config.GlobalTemplateManager.Template.DropInterfaceLimit
        if maxDepth ~= nil and curDepth >= maxDepth then
            ScreenMessage.ShowMessage(Language.GetValue("Common_PanelOpenMax"))
            return false,curDepth
        end
    end
    return true,curDepth
end
---@param uiCtrl UICtrlBase
---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyIntent:Perform(uiCtrl, callback, performData)
    Logger.Log("Perform panel : "..uiCtrl._Keyword)
    --Logger.LogError("UICtrlPolicyIntent Perform self._State is："..self._State)
    local check,depth = CheckLayerDepth(self)
    if check == false then
        Logger.Log("Perform3")
        return
    end

    if self._State == UIConst.CtrlManagerState.Active then
        self._State = UIConst.CtrlManagerState.Performing
        local performFun = function()
            UICtrlPolicyIntentOp.Perform(uiCtrl, function()
                self._State = UIConst.CtrlManagerState.Active
                TryCallCommander(self, uiCtrl, callback, performData)
                if performData._BlackBlockEnable == true then
                    LuaHelper.DeferSeconds(performData._BlackBlockTime ,function ()
                        ScreenLoading.CloseLoadingView(nil)
                    end)
                end
                InvokeSafely(callback)

            end , performData, self)
        end
        if performData._BlackBlockEnable == true then
            ScreenLoading.PreRandomLoading()
            ScreenLoading.OpenLoadingView(function ()
                --Logger.Log("Loading panel finish")
                LuaHelper.DeferFrames(15,function ()
                    performFun()
                end)
                --LuaHelper.DeferFrames(10,function ()
                --    --UIUtility.ReleaseMemory()
                --    LuaHelper.DeferFrames(15,function ()
                --        performFun()
                --    end)
                --end)
            end)
        else
            --Logger.Log("Perform10")
            performFun()
        end
    else
        --Logger.Log("Perform6")
        AddToCommander("Perform", self, uiCtrl, callback, performData)
    end

    if uiCtrl and uiCtrl._Keyword then
        local appTab = {}
        appTab.key = uiCtrl._Keyword
        appTab.value = os.time()
        SDKProxy.sdkAppDump:OnSetAppDumpBind(appTab)
    end
end
---@param callback fun()
function UICtrlPolicyIntent:RevokeAllCtrls(callback)
    if self._State == UIConst.CtrlManagerState.Active then
        self._State = UIConst.CtrlManagerState.Revoking
        UICtrlPolicyIntentOp.RevokeAllCtrls(function ()
            self._State = UIConst.CtrlManagerState.Active
            InvokeSafely(callback)
            TryCallCommander(self, nil, callback, nil)
        end,nil,self)
    else
        AddToCommander("RevokeAllCtrls", self, nil, callback, nil)
    end
end
function UICtrlPolicyIntent:RevokeToBottom(callback,performData)
    if self._State == UIConst.CtrlManagerState.Active then
        self._State = UIConst.CtrlManagerState.Revoking
        local peek = self:Peek()
        if peek ~= nil then
            EventManager:BroadEvent(EventTypeEnum.Event_AppDump_UnBind,self,peek._Keyword)
        end
        UICtrlPolicyIntentOp.RevokeToBottom(function ()
            self._State = UIConst.CtrlManagerState.Active
            InvokeSafely(callback)
            TryCallCommander(self, nil, callback, performData)
        end,performData,self)
    else
        AddToCommander("RevokeToBottom", self, nil, callback, performData)
    end
end
---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyIntent:RevokeTop(callback, performData)
    --Logger.Log("RevokeTop1")
    local peek = self:Peek()
    if peek ~= nil then
        Logger.Log("Revoke top, peek is : "..peek._Keyword)
        EventManager:BroadEvent(EventTypeEnum.Event_AppDump_UnBind,self,peek._Keyword)
    end
    if performData == nil then
        --Logger.Log("RevokeTop2")
        performData = UICtrlManager.RevokeActionDefault
    end
    if self._State == UIConst.CtrlManagerState.Active then
        --Logger.Log("RevokeTop3")
        self._State = UIConst.CtrlManagerState.Revoking
        UICtrlPolicyIntentOp.RevokeTop(self:Peek(), function()
            --Logger.Log("RevokeTop4")
            self._State = UIConst.CtrlManagerState.Active
            InvokeSafely(callback)
            TryCallCommander(self, nil, callback, performData)
        end , performData, self)
    else
        --Logger.Log("RevokeTop5")
        AddToCommander("RevokeTop", self, nil, callback, performData)
        --Logger.Log("RevokeTop6")
    end
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyIntent:PeekForSpecific(keyword, callback, performData)
    if self._State == UIConst.CtrlManagerState.Active then
        self._State = UIConst.CtrlManagerState.Revoking
        UICtrlPolicyIntentOp.RevokeTop(self:PeekForSpecific(keyword), function()
            self._State = UIConst.CtrlManagerState.Active
            InvokeSafely(callback)
            TryCallCommander(self, nil, callback, performData)
        end , performData, self)
    else
        AddToCommander("RevokeTop", self, nil, callback, performData)
    end
end

---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyIntent:SaveAndRelease(callback, performData)
    UICtrlPolicyIntentOp.SaveAndRelease(self,function ()
        self._State = UIConst.CtrlManagerState.DeActive
        InvokeSafely(callback)
    end)
end

---@return string
function UICtrlPolicyIntent:GetTopCtrlKeyWord()
    local topCtrl = self:GetTopCtrl()
    if topCtrl ~= nil then
        return topCtrl:GetKeyWord()
    else
        return nil
    end
end


---@param callback fun()
---@param performData UICtrlPerformData
function UICtrlPolicyIntent:Restore(callback, performData)
    --Logger.LogInfo("UICtrlManager.Restore")
    self._State = UIConst.CtrlManagerState.Restoring
    UICtrlPolicyIntentOp.Restore(self,function ()
        Logger.LogInfo("Intent Depth Restore Finish>>>>>>>>",self._BaseDepth)
        self._State = UIConst.CtrlManagerState.Active
        InvokeSafely(callback)
    end)
end

return UICtrlPolicyIntent