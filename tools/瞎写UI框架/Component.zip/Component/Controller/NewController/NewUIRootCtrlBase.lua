local super = require "Component.Controller.NewController.NewUICtrlBase"
---@class NewUIRootCtrlBase:NewUICtrlBase
NewUIRootCtrlBase = class("NewUIRootCtrlBase",super)

function NewUIRootCtrlBase:ctor()
    NewUIRootCtrlBase.super.ctor(self)
    ---@type NewUIBase
    self._UIScript = nil
    ---@type RmUIEventPackager
    self._RMEventPackager = RmUIEventPackager.Created(self._Keyword)
end

function NewUIRootCtrlBase:AddEvent(pEventName,pAction)
    self._RMEventPackager:AddEvent(pEventName,pAction)
end

function NewUIRootCtrlBase:LoadResource(callback)
    if not GameObjectExtension.IsNil(self._panel) then
        callback(true)
        return
    end

    Utility.ResourceLoadAsync(self._ResType, self._ResName,function (go)
        --Logger.LogError("LoadResource _ResType is :"..self._ResType.."self._ResName is :"..self._ResName)
        self:OnResLoadFinish(go,callback)
    end)
end

function NewUIRootCtrlBase:OnResLoadFinish(go,callback)
    if GameObjectExtension.IsNil(go) then
        Logger.LogError("OnResLoadFinish>>> go is nil,resName>>" .. self._ResName)
        InvokeSafely(callback,false)
        return
    end
    UIPanelCollector.RegistPanel(self._Keyword,go)
    self._Panel = go
    GameObjectExtension.GetOrAddComponent(self._Panel,"UIPanel")
    local script = self:GetScript()
    if script ~= nil then
        script:Prepare()
        script:SetEventPackager(self._RMEventPackager)
        callback(true)
    else
        callback(false)
        Logger.LogError("script is nil , keyword>>" .. self._Keyword)
    end
end

function NewUIRootCtrlBase:ReleaseResource()
    --Logger.LogError("UICtrlRooBase ReleaseResource >>>> ")

    if GameObjectExtension.IsNil(self._Panel) then
        --UICtrlUtility.LogError("Ctrl: " .. self._Keyword .. " Release resource occurred problems, self._Panel is nil, somebody else has been dispose it")
        return
    end
    --Logger.LogError("UICtrlRooBase ReleaseResource >>>> _ResTypeis : "..self._ResType.."self._ResName, is :"..self._ResName.."self._Panel"..self._Panel.name)
    UIPanelCollector.UnregistPanel(self._Keyword)
    Utility.ResourceDestroy(self._ResType,self._ResName,self._Panel)
    self._Panel = nil
end

---@return NewUIBase
function NewUIRootCtrlBase:GetScript()
    if GameObjectExtension.IsNil(self._Panel) then
        return
    end
    if self._UIScript == nil then
        self._UIScript = self._Panel:GetComponent("RmLuaBehaviour"):GetLuaIns()
    end
    return self._UIScript
end

function NewUIRootCtrlBase:OnScreen(callback)
    local script = self:GetScript()
    script:EnterScreen(callback)
end

function NewUIRootCtrlBase:OffScreen(callback)
    local script = self:GetScript()
    script:ExitScreen(callback)
end

return NewUIRootCtrlBase

