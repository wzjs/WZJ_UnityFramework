---@class ScreenTip
ScreenTip = {}

ScreenTip.TipLayer = nil
ScreenTip.ShowTipGO = nil
ScreenTip.ResType = ""
ScreenTip.ResName = ""
local InitTipLayer = function()
    if GameObjectExtension.IsNil(ScreenTip.TipLayer) then
        ScreenTip.TipLayer = UIUtility.GetLayerGameObject(UIConst.TipLayerName, UIConst.UIDepthTipLayer)
    end
end
function ScreenTip.LoadNewTip(pResType,pResName,pCallBack)
    InitTipLayer()
    ScreenTip.RemoveTip()
    ScreenTip.ResType = pResType
    ScreenTip.ResName = pResName
    ScreenTip.ResAdId = Utility.ResourceLoadAsync(pResType,pResName,function (pGO)
        ScreenTip.ShowTipGO = pGO
        GameObjectExtension.SetParent(ScreenTip.ShowTipGO, ScreenTip.TipLayer.transform, true)
        local script = ScreenTip.ShowTipGO:GetComponent("RmLuaBehaviour"):GetLuaIns()
        InvokeSafely(pCallBack,script)
    end)
end

function ScreenTip.RemoveTip()
    if not GameObjectExtension.IsNil(ScreenTip.ShowTipGO) then
        --Utility.ResourceDestroy(ScreenTip.ResType,ScreenTip.ResName,ScreenTip.ShowTipGO)
        Utility.ResourceAssetById(ScreenTip.ResAdId)
        ScreenTip.ShowTipGO = nil
    end
end

function ScreenTip.RemoveBattleTip()
    if not GameObjectExtension.IsNil(ScreenTip.ShowTipGO) then
        --Utility.ResourceDestroy(ScreenTip.ResType,ScreenTip.ResName,ScreenTip.ShowTipGO)
        Utility.ResourceAssetById(ScreenTip.ResAdId)
        ScreenTip.ShowTipGO = nil
    end
    ScreenTip.isReadyTip = false
    ScreenTip.isExistTip = false
end

function ScreenTip.ShowMazeBuffTip(pIndex,pType,pBuffId,pObj)
    local afData = ConfigOp.GetAffixText(pType)
    local desc = ""
    local text1 = afData.Text1
    if text1 ~= nil then
        local buffDat = ConfigOp.GetBuffConfig(pBuffId)
        local pars = buffDat.RoutineTextDynamicParams[pIndex]
        if pars == nil then
            Logger.LogError("pars is nil plz check buffid is:"..pBuffId.."type is :"..pIndex)
        end
        local paroAdd =  DMMazeManagerN.GetDuplicateProAdd()
        local reP1 = math.floor(pars.Param1*paroAdd)
        local params = {reP1}
        if pars.Param2 ~= nil then
            local reP2 = math.floor(pars.Param2*paroAdd)
            params = {reP1,reP2}
        end
        desc = StringExtension.StringFormat(text1,params)
    else
        desc = afData.Description
    end
    ScreenTip.ShowMazeNormalTip(afData.Name,desc,pObj)
end
function ScreenTip.ShowMazeNormalTip(pName,pDesc,pObj)
    ---@param pLuaIns UI_RelicNormalTip
    ScreenTip.LoadNewTip("BattleMaze","UI_RelicNormalTip",function (pLuaIns)

        local offsetPosL = Vector3.New(0.7,0,0)
        local offsetPosR = Vector3.New(-0.9,0,0)
        local offsetPos = Vector3.New(0,0,0)
        if pObj  ~= nil then
            if  pObj.transform.position.x < 0 then
                offsetPos = pObj.transform.position + offsetPosL
            else
                offsetPos = pObj.transform.position + offsetPosR
            end
        end

        pLuaIns:SetRelicNormalTip(pName,pDesc,offsetPos)
    end)
end

---@param pDmThing DMThing
function ScreenTip.ShowDMThingTip(pDmThing)
    local resType = "common_ui"
    local resName = "ThingChangeTipPrefab"
    ---@param pLuaIns ThingChangeTipPrefab
    ScreenTip.LoadNewTip(resType,resName,function (pLuaIns)
        local content = ""
        local language = Language.GetValue("DefaultDialogCostContentEx")
        local dmThingData = nil
        local itemIcon = nil
        local itemCount = nil
        if pDmThing:GetThingType() == DMThing.ThingType_Hero then
            ---@type DMHero
            dmThingData = pDmThing:GetThingData()

        elseif pDmThing:GetThingType() == DMThing.ThingType_Item then
            ---@type DMItem
            dmThingData = pDmThing:GetThingData()
            itemIcon = VMThing.ItemIconName[dmThingData:GetId()]
            itemCount = dmThingData:GetCount()
        end
        local pPreText = Language.GetValue("Common_Lose").." "..VMThing.GetItemName(dmThingData)
        if itemCount ~= nil and itemCount < 0 then
            pPreText = Language.GetValue("Common_Lose").." "..VMThing.GetItemName(dmThingData)
        end
        content = StringExtension.StringFormat (language,{pPreText,itemIcon,itemIcon, itemCount,""})
        pLuaIns:SetThingChangeTipPrefab(content)
        LuaHelper.DeferSeconds(2,function ()
            ScreenTip.RemoveTip()
        end)
    end)
end
ScreenTip.isReadyTip = false
ScreenTip.isExistTip = false
---@param pPressBtn UIEventListener
function ScreenTip.BindEventListenerBtnAndTip(pPressBtn,pDelayTime,pOpenTipFunc,pCloseTipFunc)
    if pPressBtn ~= nil then
        pPressBtn.onPress = function(pObj,pPress)
            if pPress then
                if ScreenTip.deferId ~= nil then
                    LuaHelper.KillCoroutine(ScreenTip.deferId)
                    ScreenTip.isReadyTip = false
                    ScreenTip.deferId = nil
                end
            end
            if pPress == true and  ScreenTip.isReadyTip == false then
                ScreenTip.isReadyTip = true
                ScreenTip.deferId = LuaHelper.DeferSeconds(pDelayTime,function ()
                    if ScreenTip.isExistTip == false and ScreenTip.isReadyTip == true and (not GameObjectExtension.IsNil(pObj)) then
                        ScreenTip.isExistTip = true
                        InvokeSafely(pOpenTipFunc,pObj)
                    end
                end)
            else
                ScreenTip.isReadyTip = false
                if ScreenTip.isExistTip == true then
                    ScreenTip.isExistTip = false
                    InvokeSafely(pCloseTipFunc)
                end
            end
        end
    end
end

ScreenTip.HaveDrag = false
---@param pPressBtn UIEventListener
function ScreenTip.BindEventListenerBtnAndNoDelta(pPressBtn,pDelayTime,pOpenTipFunc,pCloseTipFunc)
    if pPressBtn ~= nil then
        pPressBtn.onPress = function(pObj,pPress)
            if pPress == true and  ScreenTip.isReadyTip == false then
                ScreenTip.isReadyTip = true
                ScreenTip.CorId = LuaHelper.DeferSeconds(pDelayTime,function ()
                    if ScreenTip.isExistTip == false and ScreenTip.isReadyTip == true and (not GameObjectExtension.IsNil(pObj))
                    and (not ScreenTip.HaveDrag) then
                        ScreenTip.isExistTip = true
                        InvokeSafely(pOpenTipFunc,pObj)
                    end
                end)
            else
                if ScreenTip.CorId ~= nil then
                    LuaHelper.KillCoroutine(ScreenTip.CorId)
                end
                ScreenTip.isReadyTip = false
                if ScreenTip.isExistTip == true then
                    ScreenTip.isExistTip = false
                    InvokeSafely(pCloseTipFunc)
                end
            end
        end
        pPressBtn.onDragStart = function(pObj)
            ScreenTip.HaveDrag = true
        end
        pPressBtn.onDragEnd = function(pObj)
            ScreenTip.HaveDrag = false
        end
    end
end

---@param pPressBtn UIEventListener
function ScreenTip.BindEventListenerBtnAndTipUnScaledTime(pPressBtn,pDelayTime,pOpenTipFunc,pCloseTipFunc)
    if pPressBtn ~= nil then
        pPressBtn.onPress = function(pObj,pPress)
            if pPress == true and  ScreenTip.isReadyTip == false then
                ScreenTip.isReadyTip = true
                LuaHelper.DeferFrames(pDelayTime,function ()
                    if ScreenTip.isExistTip == false and ScreenTip.isReadyTip == true and (not GameObjectExtension.IsNil(pObj)) then
                        ScreenTip.isExistTip = true
                        InvokeSafely(pOpenTipFunc,pObj)
                    end
                end)
            else
                ScreenTip.isReadyTip = false
                if ScreenTip.isExistTip == true then
                    ScreenTip.isExistTip = false
                    InvokeSafely(pCloseTipFunc)
                end
            end
        end
    end
end


---@param pPressBtn UIEventListener
function ScreenTip.BindEventListenerBtnAndTipExtention(pPressBtn,pDelayTime,pOpenTipFunc,pCloseTipFunc,pPressFunction)
    if pPressBtn ~= nil then
        pPressBtn.onPress = function(pObj,pPress)
            if pPressFunction~=nil then
                pPressFunction(pPress)
            end
            if pPress == true and  ScreenTip.isReadyTip == false then
                ScreenTip.isReadyTip = true
                ScreenTip.CorId = LuaHelper.DeferSeconds(pDelayTime,function ()
                    if ScreenTip.isExistTip == false and ScreenTip.isReadyTip == true then
                        ScreenTip.isExistTip = true
                        InvokeSafely(pOpenTipFunc,pObj)
                    end
                end)
            else
                if ScreenTip.CorId ~= nil then
                    LuaHelper.KillCoroutine(ScreenTip.CorId)
                end
                ScreenTip.isReadyTip = false
                if ScreenTip.isExistTip == true then
                    ScreenTip.isExistTip = false
                    InvokeSafely(pCloseTipFunc)
                end
            end
        end
    end
end

---@param pPressBtn UIEventListener
function ScreenTip.BindShowTip(pPressBtn,pOpenTipFunc,pCloseTipFunc)
    pPressBtn.onTooltip = function(pObj,pShow)
        if pShow then
            InvokeSafely(pOpenTipFunc,pObj)
        else
            InvokeSafely(pCloseTipFunc,pObj)
        end
    end
end

