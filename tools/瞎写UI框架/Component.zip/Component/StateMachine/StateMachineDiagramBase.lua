StateMachineDiagramBase = class ("StateMachineDiagramBase")
---@class StateMachineDiagramBase
---@field private _RegistCount number

function StateMachineDiagramBase:ctor( obj )
    self._RegistCount = 0
    self._CurStateUniqueId = "0"
    self._InternalTypeList = {}
    self._InternalFuncType = {}
    self._InternalLineData = {}
    self._RuntimeInstance = nil
end

function StateMachineDiagramBase:CreateDiagram()
end

---@return string StateUniqueId
---@param stateMachineStateBase StateMachineStateBase
function StateMachineDiagramBase:RegistStateByType(stateMachineStateBase)
    self._RegistCount = self._RegistCount + 1
    local key = self._RegistCount .. ""
    Assert.True(self._InternalTypeList[key] == nil)
    self._InternalTypeList[key] = stateMachineStateBase
    return key
end

---@param callback fun()
---@return string StateUniqueId
function StateMachineDiagramBase:RegistStateByFunction(callback)
    self._RegistCount = self._RegistCount + 1
    local key = self._RegistCount .. ""
    Assert.True(self._InternalFuncType[key] == nil)
    self._InternalFuncType[key] = callback
    return key
end

---@param stateMachineDiagramBase StateMachineDiagramBase
local function _check_state_id_(stateMachineDiagramBase, stateUniqueId)
    if stateUniqueId == nil then
        return false
    end

    if  stateMachineDiagramBase._InternalTypeList[stateUniqueId] == nil and stateMachineDiagramBase._InternalFuncType[stateUniqueId] == nil then
        return false
    end

    return true
end

---@param stateUniqueId string
---@param eventName string
---@param newStateUniqueId string
function StateMachineDiagramBase:RegistProcessLineStateSwitch(stateUniqueId, eventName, newStateUniqueId)
    Assert.True(_check_state_id_(self, stateUniqueId))
    Assert.True(_check_state_id_(self, newStateUniqueId))

    if self._InternalLineData[stateUniqueId] == nil then
        self._InternalLineData[stateUniqueId] = {}
    end
    local data = self._InternalLineData[stateUniqueId]
    Assert.IsNil(data[eventName])
    data[eventName] = newStateUniqueId
end

---@param eventName string
function StateMachineDiagramBase:Event(eventName)
    --Assert.IsNil(self._InternalLineData[self._CurStateUniqueId])
    if self._InternalLineData[self._CurStateUniqueId] == nil then
        Logger.LogError("StateMachineDiagramBase:Event emitted, StateId not exist. EventName : ".. eventName .. ",  CurStateUniqueId : " .. self._CurStateUniqueId)
        return
    end

    local data = self._InternalLineData[self._CurStateUniqueId]
    if data[eventName] == nil then
        --Logger.LogError("StateMachineDiagramBase:Event emitted, Event not exist. EventName : ".. eventName .. ",  CurStateUniqueId : " .. self._CurStateUniqueId)
        return
    end

    self:_Launch(data[eventName])
end

---@param stateUniqueId string
function StateMachineDiagramBase:_Launch(stateUniqueId)
    -- 前一个流程退出
    if self._RuntimeInstance ~= nil then
        TryCall(function()
            self._RuntimeInstance:OnExit()
        end)
        self._RuntimeInstance = nil
    end

    if  self._CurStateUniqueId == stateUniqueId then
        return
    end

    self._CurStateUniqueId = stateUniqueId
    -- 后一个流程启动
    if self._InternalFuncType[stateUniqueId] ~= nil then
        TryCall(function()
            InvokeSafely(self._InternalFuncType[stateUniqueId])
        end)
        return
    end

    if self._InternalTypeList[stateUniqueId] ~= nil then
        self._RuntimeInstance = self._InternalTypeList[stateUniqueId]
        self._RuntimeInstance:_InitStateMachine(self)
        --TryCall(function()
            self._RuntimeInstance:OnEnter()
        --end)
        return
    end
    ThrowException("Launch state failed. StateUniqueId:" ..stateUniqueId)
end

function StateMachineDiagramBase:Update()
    if self._RuntimeInstance ~= nil then
        self._RuntimeInstance:OnUpdate()
    end
end

function StateMachineDiagramBase:OnDestroy()
    for i = 1,#self._InternalFuncType do
        self._InternalFuncType[i] = nil
    end
    if self._RuntimeInstance ~= nil then
        TryCall(function()
            self._RuntimeInstance:OnExit()
        end)
        self._RuntimeInstance = nil
    end
end

return StateMachineDiagramBase