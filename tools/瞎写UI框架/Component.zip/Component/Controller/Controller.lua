local baseDir = "Component/Controller/"
local function loadfile(filename)
    require (baseDir..filename)
end

loadfile("Base/UICtrlBase")
loadfile("Base/UICtrlRootBase")
loadfile("Base/UICtrlBaseOp")
loadfile("Base/UICtrlPerformData")

loadfile("Utility/UICtrlUtility")

loadfile("CutScene/UICutSceneBase")

loadfile("NewController/NewLuaMonoBehaviour")
loadfile("NewController/NewPolicyData")
loadfile("NewController/NewUIBase")
loadfile("NewController/NewUIConst")
loadfile("NewController/NewUICtrlBase")
loadfile("NewController/NewUICtrlBaseOp")
loadfile("NewController/NewUICtrlPolicyBase")
loadfile("NewController/NewUICtrlPolicyIntent")
loadfile("NewController/NewUICtrlPolicyOp")
loadfile("NewController/NewUIRootCtrlBase")

loadfile("Policy/UICtrlPolicyBase")
loadfile("Policy/UICtrlPolicyIntent")
loadfile("Policy/UICtrlPolicyIntentOp")
loadfile("Policy/UICtrlPolicyQueue")
loadfile("Policy/UICtrlPolicyQueueOp")
loadfile("Policy/UICtrlPolicySingle")
loadfile("Policy/UICtrlPolicySingleOp")
loadfile("Policy/UICtrlManager")



baseDir =  nil
loadfile = nil