---@field __FlowName string
---@field __CurState string
---@field __AllSteps table
---@field __FinishCallBack function
---@field __CurStepId number
---@field __LastAddStep table
---@field __CurRuningStep table

---@class Workflow
Workflow = class("Workflow")
Workflow.State_Init = "Init"
Workflow.State_Start = "Start"
Workflow.State_Runing = "Runing"
Workflow.State_Finish = "Finish"

function Workflow.Created(pFlowName)
    local workflow = Workflow:New(pFlowName)
    workflow.__FlowName = pFlowName
    return workflow
end
function Workflow:ctor()
    self.__FlowName = ""
    self.__CurState = Workflow.State_Init
    ---@type FlowStep[]
    self.__AllSteps = {}
    self.__FinishCallBack = nil
    self.__CurStepId = -1
    self.__FirstStepId = -1
    self.__LastAddStep = nil
    self.__CurRuningStep = nil
end
function Workflow:SetFinishCallBack(pCallBack)
    self.__FinishCallBack = pCallBack
end
function Workflow:Name()
    return  self.__FlowName
end
function Workflow:Reset()
    self.__CurState = Workflow.State_Init
    self.__CurStepId = self.__FirstStepId
    self.__CurRuningStep = nil
end
function Workflow:FinishFlow()
    self:OnFinish()
end
function Workflow:StartWorkFlow()
    --logError("Workflow .StartWorkFlow"..self.__FlowName.."self.__CurStepId"..self.__CurStepId)
    self.__CurState = Workflow.State_Start
    self.__CurRuningStep = self:GetCurFlowStep()
    self.__CurState = Workflow.State_Runing
    self:OnRuning()
end
function Workflow:OnRuning()
    if self.__CurRuningStep ~= nil and self.__CurState == Workflow.State_Runing  then
        self.__CurRuningStep:StartStep(function (pNextStepId)
            if pNextStepId > 0 then
                self.__CurStepId = pNextStepId
                self.__CurRuningStep = self:GetCurFlowStep()
                self:OnRuning()
            else
                self:OnFinish()
            end
        end)
    else
        self:OnFinish()
    end
end
function Workflow:OnFinish()
    if  self.__CurState ~= Workflow.State_Finish then
        self.__CurState = Workflow.State_Finish
        InvokeSafely(self.__FinishCallBack,self.__FlowName)
    end
end
function Workflow:GetCurFlowStep()
    return self:GetStepByStepId(self.__CurStepId)
end
function Workflow:GetStepByStepId(pStepId)
    return self.__AllSteps[pStepId]
end
--[[
    需要按照流程步骤加入 先执行的先添加
--]]
function Workflow:AddStepParmas(pStepId,pActionFunc,pFinishFunc)
    local flowStep = FlowStep.Created(pStepId,pActionFunc,pFinishFunc)
    self:AddStep(flowStep)
end
function Workflow:AddByActionAndStepId(pId,pAction)
    local step = FlowStep.Created(pId,function (pCallBack)
        InvokeSafely(pAction,pCallBack)
    end)
    self:AddStep(step)
end
---@param  pFlowStep FlowStep
function Workflow:AddStep(pFlowStep)
    if pFlowStep ~= nil then
        local stepId = pFlowStep:GetStepId()
        if self.__LastAddStep ~= nil then
            self.__LastAddStep:SetNextStepId(stepId)
        end
        self.__LastAddStep = pFlowStep
        --logError("stepId"..stepId)
        if self.__FirstStepId == -1 then
            self.__FirstStepId = stepId
            self.__CurStepId = stepId

        end
        self.__AllSteps[stepId] = pFlowStep
    end
end