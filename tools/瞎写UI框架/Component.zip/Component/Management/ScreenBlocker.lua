ScreenBlocker = {}
local ScreenLockStack = {}
---@type UnityEngine.GameObject
local blocker = nil
---@type number 计数器
local counter = 0

local function GetScreenBlockInfo()
    local fullMsg = "The block lock stack info : "
    for k,v in pairs(ScreenLockStack) do
        local str = k..v.."    >>>>>>>>>>   "
        fullMsg = fullMsg..str
    end
    return fullMsg
end

local function ScreenBlockerInternal()
    if GameObjectExtension.IsNil(blocker) then
        --local root = UnityEngine.GameObject.Find(UIConst.HierachyPathUI)
        local root = UIUtility.GetLayerGameObject(UIConst.BlockLayerName, UIConst.UIDepthBlocker)
        Assert.GameObjectExist(root, "Not find root in hierachy: "..UIConst.HierachyPathUI)

        blocker = UnityEngine.GameObject.New("ScreenBlocker")
        GameObjectExtension.SetParent(blocker, root.transform, true)

        ---@type UIPanel
        --local panel = blocker:AddComponent(typeof(UIPanel))
        --panel.depth = UIConst.UIDepthBlocker

        ---@type UIWidget
        local widget = blocker:AddComponent(typeof(UIWidget))
        widget.autoResizeBoxCollider = false
        widget.depth = 150
        widget:SetDimensions(100000, 100000)

        ---@type UnityEngine.BoxCollider
        local collider = blocker:AddComponent(typeof(UnityEngine.BoxCollider))
        collider.size = Vector3.New(100000, 100000, 0)

        ---@type UIEventListener
        local listener = blocker:AddComponent(typeof(UIEventListener))
        listener.onClick = function()
            Logger.LogInfo("GetScreenBlockInfo is :"..GetScreenBlockInfo())
        end
    end
    if counter == 0 then
        if blocker ~= nil then
            blocker:SetActive(true)
        end
    end
    counter = counter + 1
    UIScreenManagementUtility.LogInfo("+1 Current ScreenBlock counter = "..counter)
end

local function ScreenUnblockerInternal()
    counter = counter - 1
    if counter < 0 then
        counter = 0
    end
    UIScreenManagementUtility.LogInfo("-1 Current ScreenBlock counter = "..counter)
    --Logger.LogError("ScreenUnblockerInternal counter is :"..counter)
    Assert.InRange(counter, 0, 100000)
    if counter == 0 and not GameObjectExtension.IsNil(blocker) then
        blocker:SetActive(false)
    end
end

function ScreenBlocker.SetScreenBlockerTime(pTime,pLockName)
    if pLockName == nil or pLockName == "" then
        pLockName = "SetScreenBlockerTime"
    end
    ScreenBlocker.SetScreenBlock( true,pLockName )
    LuaHelper.DeferSeconds(pTime,function ()
        ScreenBlocker.SetScreenBlock( false,pLockName )
    end)
end
---SetScreenBlock 开启或关闭ScreenBlock（屏幕遮罩)
---@param pEnabled boolean
function ScreenBlocker.SetScreenBlock( pEnabled,pLockName )
    --Logger.LogError("ScreenBlocker SetScreenBlock pEnabled",pEnabled)
    --Logger.LogError("ScreenBlocker SetScreenBlock pLockName",pLockName)
    --Logger.Log("ScreenBlocker SetScreenBlock pLockName : "..pLockName..". ScreenBlocker enable : "..pEnabled)
    if pEnabled then
        if pLockName ~= nil then
            local count = ScreenLockStack[pLockName]
            count = (count == nil) and 0 or count
            count = count + 1
            ScreenLockStack[pLockName] = count
        end
        ScreenBlockerInternal()
    else
        ScreenUnblockerInternal()
        if pLockName ~= nil then
            local count = ScreenLockStack[pLockName]
            if count == nil then
                Logger.LogWarning("Can't find lockname in the lock stack : "..pLockName)
                count = 0
            else
                count = count - 1
            end
            if count <= 0 then count = nil end
            ScreenLockStack[pLockName] = count
        end
    end
end
---@return boolean
function ScreenBlocker.IsLockByLockName(pLockName)
    return ScreenBlocker.GetLockCountByLockName(pLockName) > 0
end

---@return number
function ScreenBlocker.GetLockCountByLockName(pLockName)
    return ScreenLockStack[pLockName] == nil and 0 or ScreenLockStack[pLockName]
end

function ScreenBlocker.IsScreenBlock()
    return counter ~= nil and counter > 0
end

function ScreenBlocker.GetScreenBlockInfo()
    return ScreenLockStack
end