ScreenMessage = {}

local messgego = nil
local connectgo = nil
local chapterEventgo = nil
---@type UnityEngine.GameObject
local clickEffectgo = nil
---@type UIScreenMessage
local uiScreenMessage = nil
---@type UI_Connect_Loop
local UIConnectLoop = nil
---@type ChapterEventTipPrefab
local UIChapterEventComplete = nil
---@param pLanguageKey string
function ScreenMessage.ShowMessageByLanguageKey(pLanguageKey)
    local message = GlobalConf.GetValueByKey(pLanguageKey)
    if message ~= nil then
        ScreenMessage.ShowMessage(message)
    end
end

---@param message string
function ScreenMessage.ShowNotice(message,pCloseCB)
    ---@type UIScreenNoticeCtrl
    local screenNoticeCtrl = (require("Logic.UI.UICtrls.Common.UIScreenNoticeCtrl").Create())
    screenNoticeCtrl:SetUIScreenNoticeCtrl(message,pCloseCB)
    UICtrlManager.UINoticeLayer:Perform(screenNoticeCtrl,nil,UICtrlManager.PerformActionDefault)
end
ScreenMessage.CurCount = 0
function ScreenMessage.ShowMessageQueue(message)
    DMMazeManagerN.GetMazeOp():OnLordDis(message)
    --ScreenMessage.CurCount = ScreenMessage.CurCount  + 1
    -----@type UIScreenMessageCtrl
    --local ctrl = (require("Logic.UI.UICtrls.Common.UIScreenMessageCtrl").Create())
    --ctrl:SetUIScreenMessage(message)
    --UICtrlManager.UIDialog:Perform(ctrl,nil,UICtrlManager.PerformActionDefault)
end
---@param message string
function ScreenMessage.ShowMessage(message)
    if GameObjectExtension.IsNil(messgego) then
        local root = UIUtility.GetLayerGameObject(UIConst.BlockLayerName, UIConst.UIDepthBlocker)
        ScreenMessage.screenAdId = Utility.ResourceLoadAsync("common_ui","UIScreenMessage",function (pGO)
            local obj = pGO
            GameObjectExtension.SetParent(obj,root.transform,true)
            messgego = obj
            uiScreenMessage = messgego:GetComponent("RmLuaBehaviour"):GetLuaIns()
            if uiScreenMessage ~= nil then
                uiScreenMessage:ShowMessage(message)
            end
        end)
    else
        if uiScreenMessage ~= nil then
            uiScreenMessage:ShowMessage(message)
        end
    end
end
ScreenMessage.IsShowConnect = false
---@param message string
function ScreenMessage.ShowConnectUI(message)
    ScreenMessage.IsShowConnect = true
    if GameObjectExtension.IsNil(connectgo) and ScreenMessage.ConnectAdId == nil then
        local root = UIUtility.GetLayerGameObject(UIConst.BlockLayerName, UIConst.UIDepthBlocker)
        ScreenMessage.ConnectAdId = Utility.ResourceLoadAsync("common_ui","UI_Connect_Loop",function (pGO)
            connectgo = pGO
            connectgo.name = "UIConnectLoop"
            GameObjectExtension.SetParent(connectgo,root.transform,true)
            UIConnectLoop = connectgo:GetComponent("RmLuaBehaviour"):GetLuaIns()
            if UIConnectLoop ~= nil then
                if ScreenMessage.IsShowConnect then
                    UIConnectLoop:Show(message)
                else
                    UIConnectLoop:Close()
                end
            end
        end)
    else
        if UIConnectLoop ~= nil then
            --UIConnectLoop.gameObject:SetActive(true)
            UIConnectLoop:Show(message)
        end
    end
end
function ScreenMessage.ResetClickEffectUI()
    if clickEffectgo ~= nil then
        ---@type UI_ClickEffect
        local luaIns = clickEffectgo:GetComponent("RmLuaBehaviour"):GetLuaIns()
        if luaIns ~= nil then
            luaIns:ResetParent()
        end
    end
end
function ScreenMessage.ShowClickEffectUI()
    if GameObjectExtension.IsNil(clickEffectgo) then
        local root = UIUtility.GetLayerGameObject(UIConst.BlockLayerName, UIConst.UIClickEffet)
        ScreenMessage.ClickAdId = Utility.ResourceLoadAsync("common_ui", "UI_ClickEffect",function(pGO)
            clickEffectgo = pGO
            GameObjectExtension.SetParent(pGO,root.transform,true)
        end)
    end
end

function ScreenMessage.HideConnectUI()
    ScreenMessage.IsShowConnect = false
    if not GameObjectExtension.IsNil(connectgo) then
        if UIConnectLoop ~= nil then
            UIConnectLoop:Close()
        end
    end
end

---@param pEventName string
function ScreenMessage.ShowChapterEventComplete(pEventName)
    if GameObjectExtension.IsNil(chapterEventgo) then
        ScreenMessage.ChapterAdId =  Utility.ResourceLoadAsync("common_ui","ChapterEventTipPrefab",function (pGO)
            local root = UIUtility.GetLayerGameObject(UIConst.BlockLayerName, UIConst.UIDepthBlocker)
            local obj = pGO
            chapterEventgo = obj
            UIChapterEventComplete = chapterEventgo:GetComponent("RmLuaBehaviour"):GetLuaIns()
            if UIChapterEventComplete ~= nil then
                UIChapterEventComplete:ShowMessage(pEventName)
            end
        end)
    else
        if UIChapterEventComplete ~= nil then
            UIChapterEventComplete:ShowMessage(pEventName)
        end
    end
end

function ScreenMessage.ClearChapterEventGo()
    if not GameObjectExtension.IsNil(chapterEventgo) then
        --Utility.ResourceDestroy("common_ui","ChapterEventTipPrefab",chapterEventgo)
        Utility.ResourceAssetById(ScreenMessage.ChapterAdId)
    end
    chapterEventgo = nil
    UIChapterEventComplete = nil
end

function ScreenMessage.ClearConnectGo()
    if not GameObjectExtension.IsNil(connectgo) then
        --Utility.ResourceDestroy("common_ui","UI_Connect_Loop",connectgo)
        Utility.ResourceAssetById(ScreenMessage.ConnectAdId)
        ScreenMessage.ConnectAdId = nil
    end
    connectgo = nil
    UIConnectLoop = nil
end

function ScreenMessage.ClearClickEffectGo()
    if not GameObjectExtension.IsNil(clickEffectgo) then
        --Utility.ResourceDestroy("common_ui", "UI_ClickEffect", clickEffectgo)
        Utility.ResourceAssetById(ScreenMessage.ClickAdId)
    end
    clickEffectgo = nil
end

function ScreenMessage.Clean()
    ScreenMessage.ClearChapterEventGo()
    ScreenMessage.ClearConnectGo()
    ScreenMessage.ClearClickEffectGo()
    if not GameObjectExtension.IsNil(messgego) then
        --Utility.ResourceDestroy("common_ui","UIScreenMessage",messgego)
        Utility.ResourceAssetById(ScreenMessage.screenAdId)
    end
    messgego = nil
    uiScreenMessage = nil
end