---@class UICtrlPerformData
UICtrlPerformData = class ("UICtrlPerformData")

---@field public _PlayEnterEffect boolean 是否播放入场动画
---@field public _PlayExitEffect boolean 是否播放入场动画
---@field public _PrevCtrlState number UIConst.PrevState 是否播放入场动画
---@field public _RestorePrevPanel boolean 是否恢复前一个面板
---@field public _UseBlock boolean 是否使用屏幕遮罩
---@field public _ReleaseMemory boolean 是否清理内存
---@field public _DepthReduce boolean 是否深度降低进场 进场动画播放完后深度恢复正常
---@field public _BlackBlockEnable boolean 是否采用黑屏
---@field public _BlackBlockTime number 黑屏过场的退场时间
function UICtrlPerformData.Create(playEnterEffect, playExitEffect, prevCtrlState, restorePrevPanel, useBlock, releaseMemory,depthReduce)
    return UICtrlPerformData.New(playEnterEffect, playExitEffect, prevCtrlState, restorePrevPanel, useBlock, releaseMemory,depthReduce)
end

function UICtrlPerformData:ctor(playEnterEffect, playExitEffect, prevCtrlState, restorePrevPanel, useBlock, releaseMemory,depthReduce)
    self._PlayEnterEffect = playEnterEffect == nil and true or playEnterEffect
    self._PlayExitEffect = playExitEffect == nil and true or playExitEffect
    self._PrevCtrlState = prevCtrlState == nil and UIConst.PrevState.Active or prevCtrlState  -- Perform state
    self._RestorePrevPanel = restorePrevPanel == nil and true or restorePrevPanel  -- Revoke state
    self._UseBlock = useBlock == nil and true or useBlock
    self._ReleaseMemory = releaseMemory == nil and true or releaseMemory
    self.__DepthReduce = depthReduce == nil and false or depthReduce
    self._BlackBlockEnable = false
    self._BlackBlockTime = 0.5
    self._NeedResload = true
end