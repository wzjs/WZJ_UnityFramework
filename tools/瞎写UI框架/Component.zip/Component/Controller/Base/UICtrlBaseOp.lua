UICtrlBaseOp = {}

local this = UICtrlBaseOp
local logger = Logger.New("UICtrlBase", Logger.DefaultColors["magenta"])
local showLog = false

---@param uiCtrl UICtrlBase
local function _ShowInfo(log, uiCtrl)
    if showLog then
        logger:LogEx(uiCtrl._Keyword ..": " .. log)
    end
end

---@param uiCtrl UICtrlBase
local function _ShowError(log, uiCtrl)
    logger:LogErrorEx(uiCtrl._Keyword ..": " .. log)
end

---@param uiCtrl UICtrlBase
local function _Check_IsValid(uiCtrl)

    if uiCtrl._Locked then
        ThrowException("uiCtrl is locked.")
    end
end

---@param uiCtrl UICtrlBase
---@param state UIConst.CtrlState
local function _Set_UICtrl_State(uiCtrl, state)
    --Logger.LogInfo("_Set_UICtrl_State uiCtrl is :",uiCtrl._Keyword)
    --Logger.LogInfo("_Set_UICtrl_State state is :",state)
    uiCtrl._State = state
    _ShowInfo("Changed State to " .. state, uiCtrl)
end

---@param uiCtrl UICtrlBase
---@param funcSuccess fun()
---@param funcFail fun()
---@param performData UICtrlPerformData
function UICtrlBaseOp.PrePrepareUICtrl(uiCtrl, funcSuccess, funcFail,performData)
    --Logger.LogInfo("UICtrlBaseOp  PrePrepareUICtrl 》》》》")
    --Logger.Log("PrePrepareUICtrl1")
    _Check_IsValid(uiCtrl)
    --Logger.LogInfo("UICtrlBaseOp  PrePrepareUICtrl 》》》》uiCtrl._State is :"..uiCtrl._State)
    if uiCtrl._State == UIConst.CtrlState.PrePrepare then
        _ShowError("Current state is PrePreparing, cannot PrePrepare once more!",uiCtrl)
        return
    elseif uiCtrl._State >= UIConst.CtrlState.PrePrepare_Finish then
        if uiCtrl._IsPrePrepareSuccess then
            funcSuccess()
        else
            InvokeSafely(funcFail)
        end
        return
    end
    _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.PrePrepare)
    uiCtrl._Locked = true
    uiCtrl:PrePrepare(function(isSuccess)
        --Logger.Log("PrePrepareUICtrl2")
        if isSuccess == nil then
            _ShowError("PrePrepare callback is a nil value",uiCtrl)
            -- 监督应用层使用者一定要返回正确的bool类型
            isSuccess = false
        end
        if type(isSuccess) ~= LuaBaseType.Boolean then
            _ShowError("PrePrepare callback is not a boolean value",uiCtrl)
            -- 监督应用层使用者一定要返回正确的bool类型
            isSuccess = false
        end
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.PrePrepare_Finish)
        uiCtrl._Locked = false
        uiCtrl._IsPrePrepareSuccess = isSuccess
        if isSuccess then
            funcSuccess()
        else
            InvokeSafely(funcFail)
        end
    end)
end

---@param uiCtrl UICtrlBase
---@param funcSuccess fun()
---@param funcFail fun()
---@param performData UICtrlPerformData
function UICtrlBaseOp.LoadResourceUICtrl(uiCtrl, funcSuccess, funcFail,performData)
    --Logger.LogInfo("UICtrlBaseOp  LoadResourceUICtrl >>>>")
    --Logger.Log("LoadResourceUICtrl1")

    _Check_IsValid(uiCtrl)
    this.PrePrepareUICtrl(uiCtrl, function()
        --Logger.LogInfo("UICtrlBaseOp  LoadResourceUICtrl >>>> Success")
        --Logger.Log("LoadResourceUICtrl2")
        if uiCtrl._State >= UIConst.CtrlState.LoadResource_Finish then
            --Logger.Log("LoadResourceUICtrl3")
            funcSuccess()
            return
        end
        if performData._NeedResload == false then
            --Logger.Log("LoadResourceUICtrl4")
            _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.LoadResource_Finish)
            funcSuccess()
            return
        end
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.LoadResource)
        uiCtrl._Locked = true
        uiCtrl:LoadResource(function()
            uiCtrl._Locked = false
            _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.LoadResource_Finish)
            funcSuccess()
            --Logger.Log("LoadResourceUICtrl8")
        end)
    end, funcFail)
end

---@param uiCtrl UICtrlBase
---@param funcSuccess fun()
---@param funcFail fun()
function UICtrlBaseOp.PostPrepareUICtrl(uiCtrl, funcSuccess, funcFail)
    --Logger.LogInfo("UICtrlBaseOp  PostPrepareUICtrl >>>>")
    _Check_IsValid(uiCtrl)
    this.LoadResourceUICtrl(uiCtrl, function()
        if uiCtrl._State < UIConst.CtrlState.SetPanelData then
            uiCtrl:SetPanelData(uiCtrl._Data)
            _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.SetPanelData)
        end
        if uiCtrl._State >= UIConst.CtrlState.PostPrepare_Finish then
            InvokeSafely(funcSuccess)
            return
        end
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.PostPrepare)
        uiCtrl._Locked = true
        uiCtrl:PostPrepare(function()
            uiCtrl._Locked = false
            _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.PostPrepare_Finish)
            InvokeSafely(funcSuccess)
        end)
    end, funcFail)
end

---@param uiCtrl UICtrlBase
---@param funcSuccess fun()
---@param funcFail fun()
function UICtrlBaseOp.EnterScreenUICtrl(uiCtrl, playEffect, funcSuccess, funcFail)
    --Logger.LogInfo("UICtrlBaseOp  EnterScreenUICtrl >>>>")
    --Logger.Log("EnterScreenUICtrl1")

    _Check_IsValid(uiCtrl)
    this.PostPrepareUICtrl(uiCtrl, function()
        if uiCtrl._State >= UIConst.CtrlState.OnScreen then
            InvokeSafely(funcSuccess)
            return
        end
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.ReadyEnter)
        uiCtrl._Locked = true
        uiCtrl:EnterScreen(function()
            uiCtrl._Locked = false
            _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.OnScreen)
            InvokeSafely(funcSuccess)
        end, playEffect)
    end, funcFail)
end

---@param uiCtrl UICtrlBase
---@param funcSuccess fun()
---@param funcFail fun()
function UICtrlBaseOp.ExitScreenUICtrl(uiCtrl, playEffect, callback)
    --Logger.LogInfo("UICtrlBaseOp  ExitScreenUICtrl >>>>")
    _Check_IsValid(uiCtrl)
    if uiCtrl._State <= UIConst.CtrlState.ReadyEnter then
        InvokeSafely(callback)
        return
    end

    uiCtrl._Locked = true
    uiCtrl:ExitScreen(function()
        uiCtrl._Locked = false
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.ReadyEnter)
        InvokeSafely(callback)
    end, playEffect)
end
---@param uiCtrl UICtrlBase
---@param playEffect boolean
---@param callback fun()
function UICtrlBaseOp.PlayerExitEffect(uiCtrl,playEffect,callback)
    if playEffect == false or playEffect == nil then
        InvokeSafely(callback)
        return
    end
    local script = uiCtrl:GetScript()
    if script ~= nil then
        script:PlayExitEffects(function ()
            --Logger.LogInfo("script PlayExitEffects >>>>")
            InvokeSafely(callback)
        end)
    else
        InvokeSafely(callback)
    end
end

---@param uiCtrl UICtrlBase
---@param playEffect boolean
---@param callback fun()
function UICtrlBaseOp.ClearPanelDataUICtrl(uiCtrl, playEffect, callback)
    _Check_IsValid(uiCtrl)
    if uiCtrl._State <= UIConst.CtrlState.SetPanelData then
        callback()
        return
    end
    UICtrlBaseOp.ExitScreenUICtrl(uiCtrl, playEffect, function()
        uiCtrl:ClearPanelData()
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.SetPanelData)
        callback()
    end)
end

---@param uiCtrl UICtrlBase
---@param playEffect boolean
---@param callback fun()
function UICtrlBaseOp.HideAndDestroyUICtrl (uiCtrl, playEffect, callback)
    _Check_IsValid(uiCtrl)
    if uiCtrl._State <= UIConst.CtrlState.LoadResource then
        callback()
        return
    end
    UICtrlBaseOp.ClearPanelDataUICtrl(uiCtrl, playEffect, function()
        uiCtrl:ReleaseResource()
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.LoadResource)
        InvokeSafely(callback)
    end)
end

---@param uiCtrl UICtrlBase
---@param playEffect boolean
---@param callback fun()
function UICtrlBaseOp.DestroyUICtrl (uiCtrl, playEffect, callback)
    _Check_IsValid(uiCtrl)
    if uiCtrl._State == UIConst.CtrlState.Created then
        callback()
        return
    end

    UICtrlBaseOp.HideAndDestroyUICtrl (uiCtrl, playEffect, function()
        uiCtrl:DoDispose()
        _Set_UICtrl_State(uiCtrl, UIConst.CtrlState.Created)
        callback()
    end)
end