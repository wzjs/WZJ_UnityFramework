local super = require "Component/Controller/NewController/NewUIBase"
---@class NewUITest : super
NewUITest = class("NewUITest",super)

function NewUITest.Create(go)
    return NewUITest.New(go)
end

function NewUITest:ctor(go)
    NewUITest.super.ctor(self,go)
end

function NewUITest:Awake()

end

function NewUITest:Dispose()

end

