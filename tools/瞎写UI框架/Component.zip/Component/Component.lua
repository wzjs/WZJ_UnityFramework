require("Component/UIConst")
require ("Component.Utility.NGUITools")

require("Component/Viewer/RmUIBase")

require ("Component.Management.ScreenBlocker")
require ("Component.Management.ScreenMessage")
require ("Component.Management.ScreenTip")
require ("Component.Management.ScreenDialog.DMDialogView")
require ("Component.Management.DMSecondView")

require ("Component.Management.ScreenDialog.ScreenDialog")
require ("Component.Management.ScreenAlert.ScreenAlert")
require ("Component.Management.ScreenLoading.ScreenLoading")
require ("Component.Management.ScreenLoading.DMLoadingData")

require ("Component.Management.ScreenDebugMessage")
require("Component/Management/UIPanelCollector")
require("Component.Management.UIScreenManagementUtility")

require("Component/Controller/Controller")
require("Component/UIEventPackager/RmUIEvent")
require("Component/Utility/UIUtility")

require("Component/StateMachine/StateMachineStateBase")
require("Component/StateMachine/StateMachineDiagramBase")

--- Flow System folder.
require("Component/FlowSystem/FlowStep")
require("Component/FlowSystem/Workflow")
require("Component/FlowSystem/WorkFlowManager")

--- Living Data folder
require("Component/LivingDataSystem/LivingData")
require("Component/LivingDataSystem/LivingDataBinder")
require("Component/LivingDataSystem/LivingDataUtility")

--- RMEvent
require("Component/RMEvent/RmEventModel")

--- DMSimpleMap
require("Component/SimpleDataMap/DMSimpleMap")

require("Component/RmAniListenerData")