NewLuaMonoBehaviour = class("NewLuaMonoBehaviour")

function NewLuaMonoBehaviour:ctor()
    self.ScriptValue = {}
    self.ScriptData = {}
end

function NewLuaMonoBehaviour:Awake()

end

function NewLuaMonoBehaviour:Start()

end

function NewLuaMonoBehaviour:Update()
end

function NewLuaMonoBehaviour:Destroy()

end

function NewLuaMonoBehaviour:OnEnable()

end

function NewLuaMonoBehaviour:OnDisable()

end
return NewLuaMonoBehaviour
