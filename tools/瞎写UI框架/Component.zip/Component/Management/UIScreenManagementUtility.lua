UIScreenManagementUtility = {}

local showLog = false
UIScreenManagementUtility.Logger = Logger.Create("UIScreenManagementUtility")

---@param message string
function UIScreenManagementUtility.LogInfo(message)
    if showLog then
        UIScreenManagementUtility.Logger:LogEx(message)
    end
end

---@param message string
function UIScreenManagementUtility.LogError(message)
    UIScreenManagementUtility.Logger:LogErrorEx(message)
end
