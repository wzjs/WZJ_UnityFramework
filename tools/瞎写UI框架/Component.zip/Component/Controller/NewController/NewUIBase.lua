local super = require "Component/Controller/NewController/NewLuaMonoBehaviour"
---@class NewUIBase : super
NewUIBase = class("NewUIBase",super)
NewUIBase.UIState = {}
NewUIBase.UIState.Created = 1
NewUIBase.UIState.Prepared = 2
NewUIBase.UIState.OffScreen = 3
NewUIBase.UIState.EnterAnim = 4
NewUIBase.UIState.OnScreen = 5

function NewUIBase:ctor(go)
    NewUIBase.super.ctor(self)
    self.gameObject = go
    self.transform = self.gameObject.transform
    self._InternalState = NewUIBase.UIState.Created
    ---@type RmUIEventPackager
    self._EventPackager = nil
end

function NewUIBase:Prepare()
    self._InternalState = NewUIBase.UIState.Prepared
    self:DoPrepare()
end

function NewUIBase:EnterScreen(callback)
    if self._InternalState < NewUIBase.UIState.Prepared then
        self:Prepare()
        Logger.LogError("when EnterScreen ,prepare should already finish ")
    end
    if self._InternalState < NewUIBase.UIState.OffScreen then
        self:DoShowOffScreen()
        self._InternalState = NewUIBase.UIState.OffScreen
    end
    self._InternalState = NewUIBase.UIState.EnterAnim
    self:PlayEnterEffects(function()
        self._InternalState = NewUIBase.UIState.OnScreen
        self:DoShowOnScreen()
        callback()
    end)
end

function NewUIBase:SetEventPackager(eventPackager)
    if eventPackager == nil then
        Logger.LogError("eventPackager is nil,ui name>>" .. self.gameObject.name)
        return
    end
    self._EventPackager = eventPackager
end

function NewUIBase:GetEventPackager()
    return self._EventPackager
end

function NewUIBase:SendMessage(pEventName,...)
    if self._EventPackager == nil then
        local eventPackager =  RmUIEventUtility.SendMessage(self.gameObject,pEventName,...)
        self._EventPackager = eventPackager
    end
    self._EventPackager:SendMessage(pEventName,...)
end

function NewUIBase:ExitScreen(callback)
    if self._InternalState < NewUIBase.UIState.EnterAnim then
        Logger.LogError("the ui already exit screen")
        return
    end
    self:PlayExitEffects(function()
        self._InternalState = NewUIBase.UIState.OffScreen
        self:DoShowOffScreen()
        callback()
    end)
end

function NewUIBase:OnDestroy()
    self:DoDispose()
end

function NewUIBase:DoPrepare()

end
function NewUIBase:DoShowOffScreen()

end
function NewUIBase:DoShowOnScreen()

end
function NewUIBase:PlayExitEffects(callback)
    callback()
end
function NewUIBase:PlayEnterEffects(callback)
    callback()
end
function NewUIBase:DoDispose()

end

return NewUIBase