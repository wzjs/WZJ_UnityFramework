---@class RMEventOp
RMEventOp = {}
---@type boolean
RMEventOp.IsBattleStorying = false
RMEventOp.BattleStoryFinish = nil
local rmEventLogger = Logger.Create("RMEventLog")


RMEventOp.SetBattleStoryFinich = function(pFinishCallBack)
    RMEventOp.BattleStoryFinish = pFinishCallBack
end

---@param pRMEvent RMEvent
RMEventOp.OpenStoryDialog = function(pRMEvent)
    if pRMEvent == nil then return end
    local storyId = pRMEvent:GetStoryId()
    local dmStory = Me.GetPlayerAllInfo():GetStoryBook():GetStory(storyId)
    if dmStory == nil then
        if storyId ~= nil and storyId > 0 then
            Logger.LogError("story is nil plz check storysTemplate, storyId is :"..storyId)
        end
        Me.GetPlayerEvent():OnEventFinish(pRMEvent:GetEventId(),0)
        return
    end
    local isBattleEvent = pRMEvent:IsBattleEvent()
    local afterFunc = function()
        if BattleMgr ~= nil then
            BattleMgr:PauseGame()
            RMEventOp.IsBattleStorying = true
        else
            Logger.LogWarning("BattleMgr is nil plz check battle manager")
        end
        StoryOp.OpenStoryUI(dmStory,nil,function (pIndex)
            Me.GetPlayerEvent():OnEventFinish(pRMEvent:GetEventId(),pIndex)
            if RMEventOp.IsBattleStorying == true then
                BattleMgr:ResumeGame()
                RMEventOp.IsBattleStorying = false
            else
                Logger.LogWarning("BattleMgr is nil plz check battle manager")
            end
            InvokeSafely(RMEventOp.BattleStoryFinish)
            RMEventOp.BattleStoryFinish = nil
        end)
    end
    if isBattleEvent then
        LuaHelper.DeferFrames(11,function ()
            afterFunc()
        end)
    else
        afterFunc()
    end
end






